using Fadd.Plugins;

namespace ExampleApplication.Shared
{
    public interface IMyPlugin : IPlugin
    {
        void SayHelloTo(string name);
    }
}