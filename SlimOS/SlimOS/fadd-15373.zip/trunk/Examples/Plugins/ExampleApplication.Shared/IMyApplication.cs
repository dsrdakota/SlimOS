using Fadd.Plugins;

namespace ExampleApplication.Shared
{
    public interface IMyApplication : IApplication
    {
        void AddMenuItem(string name, MenuItemClickedHandler clickHandler);

        /// <summary>
        /// Register a manager that takes care of a business object.
        /// </summary>
        /// <typeparam name="T">Type of service to register</typeparam>
        /// <param name="component">instance of the service</param>
        /// <example>
        /// <code><![CDATA[
        /// components.RegisterComponent<UserManager>(userMgr);
        /// ]]></code>
        /// </example>
        void RegisterComponent<T>(T component) where T : class;

        /// <summary>
        /// Get a component.
        /// </summary>
        /// <typeparam name="T">Requested service</typeparam>
        /// <returns>object if registered; otherwise null</returns>
        /// <example>
        /// <code><![CDATA[
        /// UserManager mgr = modMgr.GetComponent<UserManager>();
        /// if (mgr != null)
        ///   mgr.Add(new User("FirstName", "LastName"));
        /// ]]></code>
        /// </example>
        T GetComponent<T>() where T : class;
    }

    public delegate void MenuItemClickedHandler(string name);
}
