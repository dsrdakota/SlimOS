using System;

namespace ExamplePlugin.Shared
{
    public interface IWorldPeace
    {
        void Initiate();
    }
}
