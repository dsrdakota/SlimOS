using System;
using ExamplePlugin.Shared;

namespace ExamplePlugin
{
    public class WorldPeaceThroughLove : IWorldPeace
    {
        public void Initiate()
        {
            Console.WriteLine("Love is all around!");
        }
    }
}