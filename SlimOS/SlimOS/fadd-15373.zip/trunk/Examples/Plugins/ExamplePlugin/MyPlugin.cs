using System;
using System.Collections.Generic;
using ExampleApplication.Shared;
using ExamplePlugin.Shared;
using Fadd.Plugins;

namespace ExamplePlugin
{
    public class MyPlugin : IMyPlugin
    {
        private const string _pluginName = "MyPlugin";
        private readonly IPluginInfo _pluginInfo = new MyPluginInfo();
        private readonly IEnumerable<string> _dependencies = new List<string>();

        /// <summary>
        /// This name is used to determine dependencies, should always be in english. 
        /// Should not be confused with the human friendly name in <see cref="IPlugin.PluginInfo"/>.
        /// </summary>
        public string PluginName
        {
            get { return _pluginName; }
        }

        /// <summary>
        /// Information about the plugin.
        /// </summary>
        public IPluginInfo PluginInfo
        {
            get { return _pluginInfo; }
        }

        /// <summary>
        /// Other plugins that this one depends on. The list should contain <see cref="PluginName"/>s.
        /// </summary>
        /// <value>Is never null</value>
        public IEnumerable<string> Dependencies
        {
            get { return _dependencies; }
        }

        /// <summary>
        /// Start the plugin
        /// </summary>
        /// <param name="application">Application interface exposed towards the plugins.</param>
        public void Start(IApplication application)
        {
            IMyApplication myApplication = (IMyApplication) application;
            myApplication.RegisterComponent<IWorldPeace>(new WorldPeaceThroughLove());
            myApplication.AddMenuItem("Click me", OnClick);
        }

        /// <summary>
        /// Invoked when the user clicks on our menu item
        /// </summary>
        /// <param name="name"></param>
        private void OnClick(string name)
        {
            Console.WriteLine("Omg! You clicked me!");
        }

        /// <summary>
        /// Function that must be implemented
        /// </summary>
        /// <param name="name"></param>
        public void SayHelloTo(string name)
        {
            Console.WriteLine("Hello " + name);
        }
    }
}
