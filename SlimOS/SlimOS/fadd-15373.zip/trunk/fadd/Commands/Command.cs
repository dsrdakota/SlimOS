using System;

namespace Fadd.Commands
{
    /// <summary>
    /// A command that will be invoked
    /// </summary>
    [Serializable]
    public abstract class Command
    {
        private bool _handled;

        /// <summary>
        /// true if the command have been handled.
        /// </summary>
        /// <remarks>Can be used to determine if another
        /// handler already have processed the command.</remarks>
        public bool IsHandled
        {
            get { return _handled; }
        }

        /// <summary>
        /// Set handled state.
        /// </summary>
        /// <param name="handled"></param>
        internal void SetHandled(bool handled)
        {
            _handled = handled;
        }


    }

}
