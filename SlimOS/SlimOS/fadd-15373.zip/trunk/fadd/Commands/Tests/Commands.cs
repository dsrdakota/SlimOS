#if DEBUG
using System;

namespace Fadd.Commands.Tests
{
    /// <summary>
    /// 
    /// </summary>
    public class MyCommand : Command
    {
        private string _name;

        /// <summary>
        /// Initializes a new instance of the <see cref="MyCommand"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public MyCommand(string name)
        {
            _name = name;
        }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public class MyAttr : Attribute
    {
        
    }

    /// <summary>
    /// 
    /// </summary>
    [MyAttr]
    public class AllTypes : DerivedCmd, myFace
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AllTypes"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public AllTypes(string name) : base(name)
        {
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public class UnknownCommand : Command
{}

    /// <summary>
    /// 
    /// </summary>
    [MyAttr]
    public class MyAttrCommand : Command
    {
        private string _name;

        /// <summary>
        /// Initializes a new instance of the <see cref="MyAttrCommand"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public MyAttrCommand(string name)
        {
            _name = name;
        }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public class DerivedCmd : MyCommand
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DerivedCmd"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
                public DerivedCmd(string name):base(name)
                {
                    
                }

    }

    /// <summary>
    /// 
    /// </summary>
    public interface  myFace
    {
        
    }

    /// <summary>
    /// 
    /// </summary>
    public class MyFaceCmd : Command, myFace
    {
        private string _name;

        /// <summary>
        /// Initializes a new instance of the <see cref="MyFaceCmd"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public MyFaceCmd(string name)
        {
            _name = name;
        }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
    }

}
#endif