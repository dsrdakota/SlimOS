using System.Net.Sockets;

namespace Fadd.Commands.Net
{
    /// <summary>
    /// Arguments for <see cref="DisconnectedHandler"/>
    /// </summary>
    public class DisconnectedEventArgs
    {
        private readonly SocketError _error;

        /// <summary>
        /// Initializes a new instance of the <see cref="DisconnectedEventArgs"/> class.
        /// </summary>
        /// <param name="error">Why we were disconnected.</param>
        /// <remarks>SocketError.Success means that we disconnected due to invalid data/packet from the remote end.</remarks>
        public DisconnectedEventArgs(SocketError error)
        {
            _error = error;
        }

        /// <summary>
        /// Why we were disconnected.
        /// </summary>
        public SocketError Error
        {
            get { return _error; }
        }
    }

    /// <summary>
    /// Called when a connection have been closed.
    /// </summary>
    /// <param name="source">Socket/Tunnel/Channel</param>
    /// <param name="args">Why it was disconnected.</param>
    public delegate void DisconnectedHandler(object source, DisconnectedEventArgs args);
}
