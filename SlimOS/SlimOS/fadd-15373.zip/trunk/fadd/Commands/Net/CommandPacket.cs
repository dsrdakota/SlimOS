using System;

namespace Fadd.Commands.Net
{
    /// <summary>
    /// Packet sent through the channel. Keeps track of a command and its reply.
    /// </summary>
    [Serializable]
    internal class CommandPacket
    {
        private string _commandName;
        private bool _reply;
        private Command _command;
        private int _sequenceNumber;

        /// <summary>
        /// Initializes a new instance of the <see cref="CommandPacket"/> class.
        /// </summary>
        /// <param name="sequenceNumber">The sequence number.</param>
        /// <param name="command">Command .</param>
        public CommandPacket(int sequenceNumber, Command command)
        {
            Check.Min(0, sequenceNumber, "sequenceNumber");
            Check.Require(command, "command");

            _sequenceNumber = sequenceNumber;
            _command = command;
        }

        public bool Reply
        {
            get { return _reply; }
            set { _reply = value; }
        }

        public string CommandName
        {
            get { return _commandName; }
            set { _commandName = value; }
        }

        public Command Command
        {
            get { return _command; }
            set { _command = value; }
        }

        public int SequenceNumber
        {
            get { return _sequenceNumber; }
            set { _sequenceNumber = value; }
        }
    }
}
