using System;

namespace Fadd.Commands.Net
{
    /// <summary>
    /// A object binding. Used to copy properties from one object to another.
    /// </summary>
    public interface Binding
    {
        /// <summary>
        /// Copies the specified from.
        /// </summary>
        /// <param name="from">object to copy from.</param>
        /// <param name="to">objec to copy to.</param>
        /// <exception cref="ArgumentNullException">If either from or to are null</exception>
        /// <exception cref="ArgumentException">If "to" is not assignabled from "from".</exception>
        void Copy(object from, object to);
    }
}
