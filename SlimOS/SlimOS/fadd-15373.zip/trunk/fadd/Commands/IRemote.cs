namespace Fadd.Commands
{
    /// <summary>
    /// Tag commands with this interface to be able to transport them through the 
    /// CommandChannel.
    /// </summary>
    public interface IRemote
    {
        /// <summary>
        /// Copy all stuff that have been modified by the command handler.
        /// </summary>
        /// <param name="from">Command to copy reply from.</param>
        void CopyReply(Command from);
    }
}
