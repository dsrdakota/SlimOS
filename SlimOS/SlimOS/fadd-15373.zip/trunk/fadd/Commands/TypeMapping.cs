using System;
using System.Collections;
using System.Collections.Generic;

namespace Fadd.Commands
{

    /// <summary>
    /// The purpose of this class is to maintain all delegates for
    /// one of following types: attributes, interfaces and classes.
    /// </summary>
    /// <remarks>
    /// These lists are used to map all commands to their subscribers.
    /// </remarks>
    internal class TypeMapping : IEnumerable<KeyValuePair<Type, List<CommandHandler>>>
    {
        private readonly Dictionary<Type, List<CommandHandler>> _mappings = new Dictionary<Type, List<CommandHandler>>();

        public List<CommandHandler> this[Type key]
        {
            get
            {
                if (_mappings.ContainsKey(key))
                    return _mappings[key];
                else
                    return null;
            }
        }

        /// <summary>
        /// Add a handler
        /// </summary>
        /// <param name="key"></param>
        /// <param name="handler"></param>
        /// <exception cref="ArgumentException">If handler have been added already.</exception>
        public void Add(Type key, CommandHandler handler)
        {
            if (!_mappings.ContainsKey(key))
                _mappings.Add(key, new List<CommandHandler>());

            if (_mappings[key].Contains(handler))
                throw new ArgumentException("Handler have already been added to: " + key.Name);

            _mappings[key].Add(handler);
        }

        public bool Remove(Type key, CommandHandler handler)
        {
            if (_mappings.ContainsKey(key))
            {
                bool res = _mappings[key].Remove(handler);
                if (_mappings[key].Count == 0)
                    _mappings.Remove(key);
                return res;
            }
            else
                return false;
        }

        public bool Contains(Type type)
        {
            return _mappings.ContainsKey(type);
        }

        #region IEnumerable<KeyValuePair<Type,CommandHandler>> Members

        ///<summary>
        ///Returns an enumerator that iterates through the collection.
        ///</summary>
        ///
        ///<returns>
        ///A <see cref="T:System.Collections.Generic.IEnumerator`1"></see> that can be used to iterate through the collection.
        ///</returns>
        ///<filterpriority>1</filterpriority>
        IEnumerator<KeyValuePair<Type, List<CommandHandler>>> IEnumerable<KeyValuePair<Type, List<CommandHandler>>>.
            GetEnumerator()
        {
            return _mappings.GetEnumerator();
        }

        #endregion

        #region IEnumerable Members

        ///<summary>
        ///Returns an enumerator that iterates through a collection.
        ///</summary>
        ///
        ///<returns>
        ///An <see cref="T:System.Collections.IEnumerator"></see> object that can be used to iterate through the collection.
        ///</returns>
        ///<filterpriority>2</filterpriority>
        public IEnumerator GetEnumerator()
        {
            return _mappings.GetEnumerator();
        }

        #endregion
    }
}
