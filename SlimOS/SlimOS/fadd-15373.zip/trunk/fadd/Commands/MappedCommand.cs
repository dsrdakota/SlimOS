using System;
using System.Collections.Generic;

namespace Fadd.Commands
{
    /// <summary>
    /// A mapped command have been assigned all subscribers that 
    /// have been mapped to an interface, subclass, or attribute
    /// that the command contains.
    /// </summary>
    internal class MappedCommand
    {
        private readonly List<CommandHandler> _handlers;
        private bool _dirty = false;

        public MappedCommand(List<CommandHandler> handlers)
        {
            if (handlers == null)
                throw new ArgumentNullException("handlers");

            _handlers = handlers;
        }

        /// <summary>
        /// All delegates that will be invoked for this command.
        /// </summary>
        public List<CommandHandler> Handlers
        {
            get { return _handlers; }
        }

        /// <summary>
        /// Dirty means that a new handler have been added since
        /// the command was last invoked.
        /// This means that we need to recheck whether we got all
        /// handlers.
        /// </summary>
        public bool Dirty
        {
            get { return _dirty; }
            set { _dirty = value; }
        }
    }
}
