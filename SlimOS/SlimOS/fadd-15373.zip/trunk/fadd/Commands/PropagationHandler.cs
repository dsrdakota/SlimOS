using System;

namespace Fadd.Commands
{

    /// <summary>
    /// Delegate used to determine if the command propagation can be cancelled.
    /// </summary>
    /// <param name="source">Distlight that the command was going through.</param>
    /// <param name="args">Event information.</param>
    /// <returns>true of command can be cancelled.</returns>
    /// <seealso cref="CommandEventArgs.CancelPropagation"/>
    public delegate bool PropagationHandler(object source, PropagationEventArgs args);

    /// <summary>
    /// Event arguments for <see cref="PropagationHandler"/>.
    /// </summary>
    public class PropagationEventArgs : EventArgs
    {
        private readonly Command _command;
        private readonly CommandHandler _handler;

        /// <summary>
        /// Initializes a new instance of the <see cref="PropagationEventArgs"/> class.
        /// </summary>
        /// <param name="command">Command that was cancelled.</param>
        /// <param name="handler">Handler that cancelled the propagation</param>
        public PropagationEventArgs(Command command, CommandHandler handler)
        {
            if (command == null)
                throw new ArgumentNullException("command");
            if (handler == null)
                throw new ArgumentNullException("handler");

            _command = command;
            _handler = handler;
        }

        /// <summary>
        /// Command that was cancelled by a handler
        /// </summary>
        public Command Command
        {
            get { return _command; }
        }

        /// <summary>
        /// Handler that which to cancel the command.
        /// </summary>
        public CommandHandler Handler
        {
            get { return _handler; }
        }
    }
}
