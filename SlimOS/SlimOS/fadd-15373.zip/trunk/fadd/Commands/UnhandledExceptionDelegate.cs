using System;

namespace Fadd.Commands
{
    /// <summary>
    /// Delegate used when a unhandled exception have been caught.
    /// </summary>
    public delegate void UnhandledExceptionDelegate(object source, UnhandledExceptionEventArgs args);

    /// <summary>
    /// Arguments for <see cref="UnhandledExceptionDelegate"/>
    /// </summary>
    public class UnhandledExceptionEventArgs : EventArgs
    {
        private readonly Exception _err;

        /// <summary>
        /// Initializes a new instance of the <see cref="UnhandledExceptionEventArgs"/> class.
        /// </summary>
        /// <param name="err">caught exception.</param>
        public UnhandledExceptionEventArgs(Exception err)
        {
            _err = err;
        }

        /// <summary>
        /// Caught exception
        /// </summary>
        public Exception Exception
        {
            get { return _err; }
        }
    }
}
