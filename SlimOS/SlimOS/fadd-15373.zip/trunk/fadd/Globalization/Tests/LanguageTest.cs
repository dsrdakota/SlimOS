#if DEBUG
using System.Globalization;
using Xunit;
#pragma warning disable 1591

namespace Fadd.Globalization.Tests
{
    public class LanguageTest
    {
        private readonly LanguageNode _languageNode;

        public LanguageTest()
        {
            _languageNode = new MemLanguageNode(CultureInfo.CurrentCulture.LCID, "root");
        }

        [Fact]
        public void TestNoCategory()
        {
            Assert.Equal<LanguageNode>(LanguageNode.Empty, _languageNode.GetNode("Invalid"));
        }

        [Fact]
        public void TestEmpty()
        {
            Assert.NotNull(_languageNode);
            Assert.Equal("[name]", _languageNode["name"]);
            Assert.Equal("[name]", _languageNode["name", int.MaxValue]);
            Assert.Equal("[name]", _languageNode["name", _languageNode.DefaultLCID]);
        }

        [Fact]
        public void TestNode()
        {
            _languageNode.Add("voodoo", _languageNode.DefaultLCID, "voodooBase");
            LanguageNode language = _languageNode.AddNode("testNode");
            Assert.Equal("voodooBase", language["voodoo"]);

            language.Add("voodoo", _languageNode.DefaultLCID, "voodooSub");
            Assert.Equal("voodooSub", language["voodoo"]);

            Assert.Equal("[voodoMisspelled]", language["voodoMisspelled"]);
        }

        [Fact]
        public void TestLanguages()
        {
            LanguageNode language = _languageNode.AddNode("subNode");
            language.Add("language", _languageNode.DefaultLCID, "swedish");
            language.Add("language", 1052, "�nglish");
            language.Add("language", 1051, "tyskish");

            Assert.Equal("swedish", language["language", _languageNode.DefaultLCID]);
            Assert.Equal("�nglish", language["language", 1052]);
            Assert.Equal("tyskish", language["language", 1051]);
            Assert.Equal("swedish", language["language", int.MaxValue]);

            language = language.AddNode("subSubNode");
            Assert.Equal("swedish", language["language", int.MaxValue]);
        }

        [Fact]
        public void TestNull()
        {
            Assert.Null(_languageNode.GetNodeUnsafe("Undefined"));
        }
    }
}
#endif