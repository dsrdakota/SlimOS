using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Logging
{
    /// <summary>
    /// We need to provide all loggers with debug information such as stacktrace, calling method, threadid etc.
    /// </summary>
    public class TextLogger : ILogger
    {

        /// <summary>
        /// Very detailed log messages, potentially of a high frequency and volume
        /// </summary>
        /// <param name="message">message written to the log.</param>
        public void Trace(string message)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Very detailed log messages, potentially of a high frequency and volume
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        public void Trace(string message, Exception exception)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Less detailed and/or less frequent debugging messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        public void Debug(string message)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Less detailed and/or less frequent debugging messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        public void Debug(string message, Exception exception)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Informational messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        public void Info(string message)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Informational messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        public void Info(string message, Exception exception)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Warnings which don't appear to the user of the application
        /// </summary>
        /// <param name="message">message written to the log.</param>
        public void Warning(string message)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Warnings which don't appear to the user of the application
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        public void Warning(string message, Exception exception)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Error messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        public void Error(string message)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Error messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        public void Error(string message, Exception exception)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Fatal error messages. After a fatal error, the application usually terminates. 
        /// </summary>
        /// <param name="message">message written to the log.</param>
        public void Fatal(string message)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Fatal error messages. After a fatal error, the application usually terminates. 
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        public void Fatal(string message, Exception exception)
        {
            throw new System.NotImplementedException();
        }
    }
}
