namespace Fadd.Logging
{
    /// <summary>
    /// Manager that provides logs to the classes.
    /// </summary>
    public static class LogManager
    {
        /// <summary>
        /// Logger that is logging to nothing.
        /// </summary>
        public static readonly NullLogger NullLogger = new NullLogger();

        /// <summary>
        /// Gets the logger.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns>A <see cref="ILogger"/>.</returns>
        public static ILogger GetLogger(string name)
        {
            return NullLogger;
        }

        /// <summary>
        /// Get logger for the current class.
        /// </summary>
        /// <returns>A <see cref="ILogger"/>.</returns>
        public static ILogger GetCurrentClassLogger()
        {
            return NullLogger;
        }

    }
}
