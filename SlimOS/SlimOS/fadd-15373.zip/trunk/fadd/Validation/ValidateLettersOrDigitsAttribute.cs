using System;

namespace Fadd.Validation
{
    /// <summary>
    /// 
    /// </summary>
    public class ValidateLettersOrDigitsAttribute : Attribute
    {
        private readonly string _extraCharacters;

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateLettersOrDigitsAttribute"/> class.
        /// </summary>
        public ValidateLettersOrDigitsAttribute() : this(null)
        {
            
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateLettersOrDigitsAttribute"/> class.
        /// </summary>
        /// <param name="extraCharacters">The extra characters.</param>
        public ValidateLettersOrDigitsAttribute(string extraCharacters)
        {
            _extraCharacters = extraCharacters;   
        }

        /// <summary>
        /// Gets the extra characters.
        /// </summary>
        /// <value>The extra characters.</value>
        public string ExtraCharacters
        {
            get { return _extraCharacters; }
        }
    }
}
