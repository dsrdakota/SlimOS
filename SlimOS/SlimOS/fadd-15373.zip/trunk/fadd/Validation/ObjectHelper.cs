using System;
using System.Collections.Specialized;

namespace Fadd.Validation
{
    /// <summary>
    /// Example on how a generated object helper can look like.
    /// todo How do the object get the validator?
    /// </summary>
    internal class ObjectHelper : IObjectHelper<TestObject>
    {
        private readonly Fadd.Validator _validator;
        private readonly Type _type = typeof (TestObject);

        public ObjectHelper(Fadd.Validator validator)
        {
            _validator = validator;
        }

        public NameValueCollection Validate(TestObject theObject)
        {
            _validator.Max("MySize", 20, theObject.MySize, true);
            return _validator.Errors;
        }

        public void SetProperty(TestObject theObject, string propertyName, object value)
        {
            switch (propertyName)
            {
                case "MySize":
                    theObject.MySize = Convert.ToInt32(value);
                    break;
                default:
                    throw new MissingPropertyException(_type.FullName, propertyName);
            }
        }


        public object GetProperty(TestObject theObject, string propertyName, object value)
        {
            switch (propertyName)
            {
                case "MySize":
                    return theObject.MySize;
                default:
                    throw new MissingPropertyException(_type.FullName, propertyName);
            }
        }
    }
}
