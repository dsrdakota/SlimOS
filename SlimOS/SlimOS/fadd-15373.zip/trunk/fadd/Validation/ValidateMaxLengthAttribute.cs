using System;

namespace Fadd.Validation
{
    /// <summary>
    /// Specifies a max length.
    /// </summary>
    /// <remarks>
    /// On a string it specified maximum number of letters, while on int it specifies the max number.
    /// </remarks>
    [AttributeUsage(AttributeTargets.Method|AttributeTargets.Property|AttributeTargets.Parameter)]
    public class ValidateMaxLengthAttribute : Attribute
    {
        private readonly int _max;
        private readonly bool _required;

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateMaxLengthAttribute"/> class.
        /// </summary>
        /// <param name="max">max length.</param>
        public ValidateMaxLengthAttribute(int max) : this(max, false)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateMaxLengthAttribute"/> class.
        /// </summary>
        /// <param name="max">max length.</param>
        /// <param name="required">true if the value is required (may not be empty)</param>
        public ValidateMaxLengthAttribute(int max, bool required)
        {
            _max = max;
            _required = required;
        }

        /// <summary>
        /// Max length
        /// </summary>
        public int Max
        {
            get { return _max; }
        }

        /// <summary>
        /// Field is required.
        /// </summary>
        public bool Required
        {
            get { return _required; }
        }
    }
}
