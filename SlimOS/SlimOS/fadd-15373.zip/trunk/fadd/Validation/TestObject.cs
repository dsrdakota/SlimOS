using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Validation
{

    public class TestObject
    {
        private int _mySize;

        [ValidateMaxLength(20, true)]
        public int MySize
        {
            get { return _mySize; }
            set { _mySize = value; }
        }
    }
}
