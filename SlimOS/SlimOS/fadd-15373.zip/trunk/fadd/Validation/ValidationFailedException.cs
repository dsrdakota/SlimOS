using System;
using System.Collections.Specialized;

namespace Fadd.Validation
{
    /// <summary>
    /// Thrown when validation fails.
    /// </summary>
    public class ValidationFailedException : Exception
    {
        private readonly NameValueCollection _errors;

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationFailedException"/> class.
        /// </summary>
        /// <param name="errors">The errors.</param>
        public ValidationFailedException([Required] NameValueCollection errors)
        {
            Check.Require(errors, "errors");

            _errors = errors;
        }

        /// <summary>
        /// Gets a message that describes the current exception.
        /// </summary>
        /// <value></value>
        /// <returns>The error message that explains the reason for the exception, or an empty string("").</returns>
        public override string Message
        {
            get
            {
                string message = string.Empty;
                foreach (string name in Errors)
                    message += Errors[name] + ", ";
                return message;
            }
        }

        /// <summary>
        /// A list of all validation errors.
        /// </summary>
        public NameValueCollection Errors
        {
            get { return _errors; }
        }
    }
}
