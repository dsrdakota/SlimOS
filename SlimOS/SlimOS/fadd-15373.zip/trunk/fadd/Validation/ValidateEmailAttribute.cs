using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Validation
{
    /// <summary>
    /// Validates that a string property is an correct email.
    /// </summary>
    public class ValidateEmailAttribute : Attribute
    {
    }
}
