using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

namespace Fadd.Validation
{
    public interface IObjectHelper<T>
    {
        NameValueCollection Validate(T theObject);

        void SetProperty(T theObject, string propertyName, object value);

        object GetProperty(T theObject, string propertyName, object value);
    }
}
