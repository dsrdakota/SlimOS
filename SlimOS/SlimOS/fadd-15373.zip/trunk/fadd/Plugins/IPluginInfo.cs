namespace Fadd.Plugins
{
    /// <summary>
    /// Contains user information about a plugin.
    /// </summary>
    /// <remarks>
    /// Should be returned in the current language.
    /// </remarks>
    /// <seealso cref="System.Globalization.CultureInfo.CurrentCulture"/>
    public interface IPluginInfo
    {
        /// <summary>
        /// Name of the plugin, it should be in the local language if possible.
        /// </summary>
        string Name
        { get;  }

        /// <summary>
        /// Description of what the plugin does. Shown to the end user.
        /// </summary>
        /// <remarks>
        /// The description may contain links to other pages and images.
        /// Just make sure that your controller can handle them.
        /// Links should be opened in new windows and not leave the market place.
        /// </remarks>
        string Description
        { get;}

        /// <summary>
        /// Author homepage
        /// </summary>
        string Homepage
        { get;}


        /// <summary>
        /// Copyright owner of this plugin.
        /// </summary>
        string Copyright
        { get;}
    }
}