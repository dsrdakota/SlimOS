using System;
using System.Reflection;

namespace Fadd.Plugins
{
    /// <summary>
    /// Arguments for <see cref="PluginLoadedHandler{T}"/>
    /// </summary>
    /// <typeparam name="T">Implementation of IPlugin</typeparam>
    public class PluginLoadedHandlerEventArgs<T> : EventArgs where T : class, IPlugin
    {
        private readonly T _plugin;
        private readonly Assembly _assembly;
        private readonly PluginTypeInfo _typeInfo;

        /// <summary>
        /// Called when a plugin have been loaded.
        /// </summary>
        /// <param name="plugin">Plugin being loaded.</param>
        /// <param name="assembly">Assembly that the plugin exist in.</param>
        /// <param name="typeInfo">information about the plugin</param>
        /// <remarks>Plugin have not been started yet.</remarks>
        public PluginLoadedHandlerEventArgs(T plugin, Assembly assembly, PluginTypeInfo typeInfo)
        {
            _plugin = plugin;
            _assembly = assembly;
            _typeInfo = typeInfo;
        }

        /// <summary>
        /// Plugin being loaded
        /// </summary>
        public T Plugin
        {
            get { return _plugin; }
        }

        /// <summary>
        /// Assembly that the plugin exist in
        /// </summary>
        public Assembly Assembly
        {
            get { return _assembly; }
        }

        /// <summary>
        /// information about the plugin
        /// </summary>
        public PluginTypeInfo TypeInfo
        {
            get { return _typeInfo; }
        }
    }



    /// <summary>
    /// Invoked when a plugin have been loaded into the system.
    /// </summary>
    ///<param name="source">PluginManager that loaded the plugin.</param>
    ///<param name="args">Plugin information.</param>
    public delegate void PluginLoadedHandler<T>(object source, PluginLoadedHandlerEventArgs<T> args) where T : class, IPlugin;
}
