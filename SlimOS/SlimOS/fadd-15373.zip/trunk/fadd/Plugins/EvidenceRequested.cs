using System;
using System.Security.Policy;

namespace Fadd.Plugins
{
    /// <summary>
    /// Arguments for <see cref="EvidenceRequestedHandler"/>
    /// </summary>
    public class EvidenceRequestedEventArgs : EventArgs
    {
        private readonly PluginTypeInfo _typeInformation;
        private Evidence _evidence;

        /// <summary>
        /// Initializes a new instance of the <see cref="EvidenceRequestedEventArgs"/> class.
        /// </summary>
        /// <param name="typeInfo">Plugin assembly information.</param>
        public EvidenceRequestedEventArgs(PluginTypeInfo typeInfo)
        {
            Check.Require(typeInfo, "typeInfo");
            _typeInformation = typeInfo;
        }

        /// <summary>
        /// Evidence that the plugin should be loaded with.
        /// </summary>
        public Evidence Evidence
        {
            get { return _evidence; }
            set { _evidence = value; }
        }

        /// <summary>
        /// Plugin assembly information
        /// </summary>
        public PluginTypeInfo TypeInformation
        {
            get { return _typeInformation; }
        }
    }

    ///<summary>
    /// Called when an assembly is about to be loaded and we need the evidence for it.
    /// Specify the evidence by using <see cref="EvidenceRequestedEventArgs.Evidence"/>
    ///</summary>
    ///<param name="source">PluginManager</param>
    ///<param name="args">Assembly information</param>
    public delegate void EvidenceRequestedHandler(object source, EvidenceRequestedEventArgs args);

}
