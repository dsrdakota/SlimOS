using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Plugins
{
    /// <summary>
    /// Application interface exposed to the clients.
    /// </summary>
    public interface IApplication
    {
    }
}
