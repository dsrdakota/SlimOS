using System.Collections.Generic;

namespace Fadd.Plugins
{
    /// <summary>
    /// All plugins must derive this interface.
    /// </summary>
    public interface IPlugin
    {
        /// <summary>
        /// This name is used to determine dependencies, should always be in english. 
        /// Should not be confused with the human friendly name in <see cref="PluginInfo"/>.
        /// </summary>
        string PluginName
        { get; }


        /// <summary>
        /// Information about the plugin.
        /// </summary>
        IPluginInfo PluginInfo
        { get; }

        /// <summary>
        /// Other plugins that this one depends on. The list should contain <see cref="PluginName"/>s.
        /// </summary>
        /// <value>should never be null.</value>
        IEnumerable<string> Dependencies
        { get; }

        /// <summary>
        /// Start the module
        /// </summary>
        /// <param name="application">Application interface exposed towards the plugins.</param>
        void Start(IApplication application);
    }
}