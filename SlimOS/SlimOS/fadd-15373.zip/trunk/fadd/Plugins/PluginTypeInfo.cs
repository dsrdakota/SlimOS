using System;
using System.Collections.Generic;

namespace Fadd.Plugins
{
    /// <summary>
    /// A found plugin and which of the requested types that it implements.
    /// </summary>
    [Serializable]
    public class PluginTypeInfo
    {
        private readonly string _assembly;
        private readonly List<Type> _types = new List<Type>();
        private readonly string _publicKey;
        private readonly byte[] _publicKeyRaw;

        /// <summary>
        /// Initializes a new instance of the <see cref="PluginTypeInfo"/> class.
        /// </summary>
        /// <param name="assemblyLocation">assembly that the plugin resides in.</param>
        /// <param name="type">plugin type.</param>
        /// <param name="publicKey">assemblies public key. should be used to decide the amount of access for the module.</param>
        public PluginTypeInfo(string assemblyLocation, Type type, byte[] publicKey)
        {
            if (type == null)
                throw new ArgumentNullException("type");
            if (assemblyLocation == null)
                throw new ArgumentNullException("assemblyLocation");

            _assembly = assemblyLocation;
            _types.Add(type);
            _publicKey = string.Empty;
            _publicKeyRaw = publicKey;
            if (publicKey != null)
            {
                for (int i = 0; i < publicKey.Length; ++i)
                    _publicKey += publicKey[i].ToString("x2");
            }
        }

        /// <summary>
        /// Assemblies public key if signed.
        /// </summary>
        public string PublicKey
        {
            get { return _publicKey; }
        }

        /// <summary>
        /// Assembly full path
        /// </summary>
        [Obsolete]
        public string Assembly
        {
            get { return _assembly; }
        }

        /// <summary>
        /// Location of DLL.
        /// </summary>
        public string Location
        {
            get { return _assembly; }
        }

        /// <summary>
        /// Requested types that exists in the assembly
        /// </summary>
        public List<Type> Types
        {
            get { return _types; }
        }

        /// <summary>
        /// Assembly public key in byte format.
        /// </summary>
        public byte[] PublicKeyRaw
        {
            get { return _publicKeyRaw; }
        }

        /// <summary>
        /// Add another type
        /// </summary>
        /// <param name="type"></param>
        public void Add(Type type)
        {
            if (type == null)
                throw new ArgumentNullException("type");

            _types.Add(type);
        }
    }

}
