using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Plugins
{
    /// <summary>
    /// Arguments for <see cref="ApplicationRequestedHandler{T}"/>
    /// </summary>
    /// <typeparam name="T">Plugin type</typeparam>
    public class ApplicationRequestedEventArgs<T> where T : class, IPlugin
    {
        private IApplication _application;
        private T _plugin;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicationRequestedEventArgs&lt;T&gt;"/> class.
        /// </summary>
        /// <param name="plugin">Plugin being started.</param>
        public ApplicationRequestedEventArgs(T plugin)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Plugin being started
        /// </summary>
        public T Plugin
        {
            get { return _plugin; }
        }

        /// <summary>
        /// Application that the plugin should be started with.
        /// </summary>
        public IApplication Application
        {
            get { return _application; }
            set { _application = value; }
        }
    }

    /// <summary>
    /// A plugin is about to be started and it needs a <see cref="IApplication"/> interface to be passed to it.
    /// </summary>
    /// <typeparam name="T">A type that implements <see cref="IPlugin"/>.</typeparam>
    /// <param name="source"><see cref="PluginManager{T}"/></param>
    /// <param name="args">Arguments.</param>
    public delegate void ApplicationRequestedHandler<T>(object source, ApplicationRequestedEventArgs<T> args) where T : class, IPlugin;
}
