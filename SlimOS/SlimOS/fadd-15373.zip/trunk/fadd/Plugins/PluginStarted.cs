using System;

namespace Fadd.Plugins
{
    /// <summary>
    /// Arguments for <see cref="PluginStartedHandler{T}"/>
    /// </summary>
    /// <typeparam name="T">A plugin implementation</typeparam>
    public class PluginStartedEventArgs<T> : EventArgs where T : class, IPlugin
    {
        private readonly T _plugin;

        /// <summary>
        /// Initializes a new instance of the <see cref="PluginStartedEventArgs&lt;T&gt;"/> class.
        /// </summary>
        /// <param name="plugin">Plugin that have been started.</param>
        public PluginStartedEventArgs(T plugin)
        {
            _plugin = plugin;
        }

        /// <summary>
        /// Plugin that have been started.
        /// </summary>
        public T Plugin
        {
            get { return _plugin; }
        }
    }


    ///<summary>
    /// Triggered when a plugin have been started.
    ///</summary>
    ///<param name="source">Plugin manager</param>
    ///<param name="args">Plugin instance</param>
    ///<typeparam name="T">A plugin implementation</typeparam>
    public delegate void PluginStartedHandler<T>(object source, PluginStartedEventArgs<T> args) where T : class, IPlugin;
}
