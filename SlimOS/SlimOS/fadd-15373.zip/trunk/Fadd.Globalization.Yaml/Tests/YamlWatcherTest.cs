#if DEBUG
using System;
using System.IO;
using System.Threading;
using Xunit;

namespace Fadd.Globalization.Yaml.Tests
{
    public class YamlWatcherTest
    {
        /// <summary>Test an incorrect file</summary>
        [Fact]
        public void TestIncorrectFile()
        {
            Assert.Throws(typeof(FileNotFoundException), delegate { new YamlWatcher(null, @"c:\doesnotexist"); });
        }

        [Fact]
        public void MultipleWriteSuccessTest()
        {
            const string filename = "test.yaml";
            File.WriteAllText("test.yaml", @"	1053: Swedish
		TextEntry1: En text.
		TextEntry2: En text2.
		EnSubNod: Subnoden 1
			SubNodTextEntry1: Subnodens textentry1");

            LanguageNode rootNode = new MemLanguageNode(1053, "RootNode");
            using (YamlWatcher watcher = new YamlWatcher(rootNode, filename))
            {
                Assert.Equal("En text.", rootNode["TextEntry1"]);
                Assert.Equal("Subnodens textentry1", rootNode.GetNode("EnSubNod")["SubNodTextEntry1"]);

                File.WriteAllText("test.yaml", @"	1053: Swedish
		TextEntry1: En text2.
		TextEntry2: En text1.
		EnSubNod: Subnoden 1
			SubNodTextEntry1: Subnodens textentry1");
                FileStream file = File.Open("test.yaml", FileMode.Append, FileAccess.Write);
                Thread.Sleep(1000);
                file.Close();
                Thread.Sleep(500);
                Assert.Equal("En text2.", rootNode["TextEntry1"]);
            }
        }

        [Fact]
        public void CorrectProcedureTest()
        {
            const string filename = "test.yaml";
            File.WriteAllText("test.yaml", @"	1053: Swedish
		TextEntry1: En text.
		TextEntry2: En text2.
		EnSubNod: Subnoden 1
			SubNodTextEntry1: Subnodens textentry1");

            LanguageNode rootNode = new MemLanguageNode(1053, "RootNode");
            using (YamlWatcher watcher = new YamlWatcher(rootNode, filename))
            {
                Assert.Equal("En text.", rootNode["TextEntry1"]);
                Assert.Equal("Subnodens textentry1", rootNode.GetNode("EnSubNod")["SubNodTextEntry1"]);

                Assert.Equal("[SubNodTextEntry2]", rootNode.GetNode("EnSubNod")["SubNodTextEntry2"]);
                File.AppendAllText(filename, Environment.NewLine + "			SubNodTextEntry2: Lite subnodtext.");
                Thread.Sleep(200);
                Assert.Equal("Lite subnodtext.", rootNode.GetNode("EnSubNod")["SubNodTextEntry2"]);

                Assert.Equal("[TextEntry3]", rootNode["TextEntry3"]);
                File.AppendAllText(filename, Environment.NewLine + "		TextEntry3: En text3.");
                Thread.Sleep(200);
                Assert.Equal("En text3.", rootNode["TextEntry3"]);
            }
        }

		[Fact]
		public void TestMultipleFiles()
		{
			const string filename = "test.yaml";
			File.WriteAllText("test.yaml", @"	1053: Swedish
		TextEntry1: En text.
		TextEntry1: En text2.
		EnSubNod: Subnoden 1
			SubNodTextEntry1: Subnodens textentry1
		EnSubNod: Subnoden 2
			SubNodTextEntry1: Subnodens textentry2");
			MemLanguageNode language = new MemLanguageNode(1053, "Test");
			YamlWatcher.LoadFile(filename, language);

			Assert.Equal("En text2.", language["TextEntry1"]);
			Assert.Equal("Subnodens textentry2", language.GetNode("EnSubNod")["SubNodTextEntry1"]);
		}

		[Fact]
		public void TestDoubleEntries()
		{
			const string filename = "test.yaml";
			File.WriteAllText("test.yaml", @"	1053: Swedish
		TextEntry1: En text.
		TextEntry1: En text2.
		EnSubNod: Subnoden 1
			SubNodTextEntry1: Subnodens textentry1
		EnSubNod: Subnoden 2
			SubNodTextEntry1: Subnodens textentry2");
			MemLanguageNode language = new MemLanguageNode(1053, "Test");
			YamlWatcher.LoadFile(filename, language);

			Assert.Equal("En text2.", language["TextEntry1"]);
			Assert.Equal("Subnodens textentry2", language.GetNode("EnSubNod")["SubNodTextEntry1"]);
		}
    }
}
#endif