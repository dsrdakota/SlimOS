This is a language loader which loads languages from YAML files.
The Watcher will also reload 