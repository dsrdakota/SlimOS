﻿using System;
using System.Collections.Generic;

namespace Fadd.Components
{
	/// <summary>
	/// Contains information about a component.
	/// </summary>
	public class Component
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="Component"/> class.
		/// </summary>
		public Component()
		{
			Instance = null;
			IsNotSingleton = false;
			Parameters = null;
			KnownParameters = new Dictionary<string, object>();
		}

		/// <summary>
		/// Gets or sets type that will be requested.
		/// </summary>
		public Type InterfaceType { get; set; }

		/// <summary>
		/// Gets or sets type that should be created.
		/// </summary>
		public Type InstanceType { get; set; }

		/// <summary>
		/// Gets or sets created instance (if singleton)
		/// </summary>
		public object Instance { get; set; }

		/// <summary>
		/// Gets or sets all constructor parameters needed to be able to create an instance of the type.
		/// </summary>
		public object[] Parameters { get; set; }

		/// <summary>
		/// Gets or sets if this component is a singleton.
		/// </summary>
		/// <remarks>
		/// <para>
		/// Default true.
		/// </para>
		/// <para>
		/// Singletons are created once and are returned each time
		/// the component is requested.
		/// </para>
		/// </remarks>
		public bool IsNotSingleton { get; set; }

		/// <summary>
		/// Gets or sets version of instance type.
		/// </summary>
		public int Version { get; set; }

		/// <summary>
		/// Gets or sets where the component should be running.
		/// </summary>
		public string RunAt { get; set; }

		/// <summary>
		/// True if component have been used to create another one.
		/// </summary>
		/// <remarks>
		/// Needed when we have different versions of a component to make
		/// sure that no one is using the older version when replacing with the newer version.
		/// </remarks>
		internal bool IsUsed { get; set; }

		/// <summary>
		/// Gets all known parameters (usually parameters configured in a app.config or similar).
		/// </summary>
		public Dictionary<string, object> KnownParameters { get; private set; }

		/// <summary>
		/// Gets or sets whether this component only can get accessed from it's own assembly.
		/// </summary>
		public bool IsInternal { get; set; }
	}
}
