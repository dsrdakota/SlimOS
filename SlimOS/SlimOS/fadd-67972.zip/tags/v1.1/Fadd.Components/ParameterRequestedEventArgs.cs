﻿using System;

namespace Fadd.Components
{
	/// <summary>
	/// A constructor parameter is missing and have been requested for a component.
	/// </summary>
	public class ParameterRequestedEventArgs : EventArgs
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="ParameterRequestedEventArgs"/> class.
		/// </summary>
		/// <param name="interfaceType">Type of the interface.</param>
		/// <param name="instanceType">Type of the instance.</param>
		/// <param name="parameterType">Type of the parameter.</param>
		/// <param name="parameterName">Name of the parameter.</param>
		public ParameterRequestedEventArgs(Type interfaceType, Type instanceType, Type parameterType, string parameterName)
		{
			InterfaceType = interfaceType;
			InstanceType = instanceType;
			ParameterType = parameterType;
			ParameterName = parameterName;
		}

		/// <summary>
		/// Gets type used to access component.
		/// </summary>
		public Type InterfaceType { get; private set; }

		/// <summary>
		/// Gets type being created.
		/// </summary>
		public Type InstanceType { get; private set; }

		/// <summary>
		/// Gets type of requested parameter.
		/// </summary>
		public Type ParameterType { get; private set; }

		/// <summary>
		/// Gets name of requested parameter
		/// </summary>
		public string ParameterName { get; private set; }

		/// <summary>
		/// Gets or sets parameter instance.
		/// </summary>
		public object ParameterValue { get; set; }
	}
}