﻿using System;

namespace Fadd.Components
{
	/// <summary>
	/// Event arguments used when a component have been created.
	/// </summary>
	public class ComponentCreatedEventArgs : EventArgs
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="ComponentCreatedEventArgs"/> class.
		/// </summary>
		/// <param name="interfaceType">Type that will be requested by users.</param>
		/// <param name="instance">Created component instance..</param>
		/// <param name="isNotSingleton">if set to <c>true</c> component is not a singleton.</param>
		public ComponentCreatedEventArgs(Type interfaceType, object instance, bool isNotSingleton)
		{
			InterfaceType = interfaceType;
			Instance = instance;
			IsNotSingleton = isNotSingleton;
		}

		/// <summary>
		/// Gets interface type.
		/// </summary>
		public Type InterfaceType { get; set; }

		/// <summary>
		/// Gets created instance.
		/// </summary>
		public object Instance { get; internal set; }

		/// <summary>
		/// Gets if component is not a singleton.
		/// </summary>
		/// <remarks>
		/// <para>
		/// If true, a new instance is created each time the component is requested.
		/// </para>
		/// </remarks>
		public bool IsNotSingleton { get; internal set; }
	}
}