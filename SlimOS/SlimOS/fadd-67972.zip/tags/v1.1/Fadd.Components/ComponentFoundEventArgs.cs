﻿using System;

namespace Fadd.Components
{
	/// <summary>
	/// Arguments used when <see cref="ComponentFinder"/> found a new component by watching 
	/// a directory.
	/// </summary>
	public class ComponentFoundEventArgs : EventArgs
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="ComponentFoundEventArgs"/> class.
		/// </summary>
		/// <param name="component">Discovered component.</param>
		public ComponentFoundEventArgs(Component component)
		{
			Component = component;
		}

		/// <summary>
		/// Gets discovered component.
		/// </summary>
		public Component Component { get; private set; }
	}
}