﻿using System;
namespace Fadd.Components.Remoting
{
	/// <summary>
	/// Response to a request
	/// </summary>
	[Serializable]
	public class Response
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="Response"/> class.
		/// </summary>
		/// <param name="requestId">The request id.</param>
		public Response(int requestId)
		{
			RequestId = requestId;
		}
		/// <summary>
		/// Gets or sets request identifier.
		/// </summary>
		public int RequestId { get; private set; }
	}
}
