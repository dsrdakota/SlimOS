﻿using System;

namespace Fadd.Components.Remoting
{
	/// <summary>
	/// Information about which method to invoke at the remote end.
	/// </summary>
	[Serializable]
	public class MethodCall
	{
		/// <summary>
		/// Gets or sets class that the call was invoked in.
		/// </summary>
		public Type InterfaceType { get; set; }

		/// <summary>
		/// Gets or sets method to invoke.
		/// </summary>
		public string MethodName { get; set; }

		/// <summary>
		/// Gets or sets method call arguments.
		/// </summary>
		public object[] Arguments { get; set; }

        /// <summary>
        /// Gets or sets types if method is generic.
        /// </summary>
        public Type[] GenericArgumentTypes { get; set;}

		/// <summary>
		/// Gets or sets identifier of this request.
		/// </summary>
		public int RequestId { get; set; }

	}
}
