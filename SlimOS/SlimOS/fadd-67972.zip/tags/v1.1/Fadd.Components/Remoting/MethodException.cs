﻿using System;

namespace Fadd.Components.Remoting
{
	/// <summary>
	/// Method call resulted in an exception.
	/// </summary>
	[Serializable]
	public class MethodException : Response
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="MethodException"/> class.
		/// </summary>
		public MethodException() : base(0)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MethodException"/> class.
		/// </summary>
		/// <param name="error">The error.</param>
		public MethodException(int requestId, Exception error) : base(requestId)
		{
			Error = error;
		}

		/// <summary>
		/// Gets thrown exception
		/// </summary>
		public Exception Error { get; private set; }
	}
}