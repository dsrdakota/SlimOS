﻿using System.Threading;

namespace Fadd.Components.Remoting
{
	/// <summary>
	/// Request sent from client to server.
	/// </summary>
	public class Request
	{
		/// <summary>
		/// Gets or sets id of transaction.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets event triggered when reply arrives.
		/// </summary>
		public ManualResetEvent Event { get; set; }

		/// <summary>
		/// Gets or sets result sent back by the server end.
		/// </summary>
		public object Response { get; set; }
	}
}
