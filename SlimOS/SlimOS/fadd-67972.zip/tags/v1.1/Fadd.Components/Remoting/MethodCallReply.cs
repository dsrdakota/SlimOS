﻿using System;

namespace Fadd.Components.Remoting
{
	/// <summary>
	/// Reply to a <see cref="MethodCall"/>
	/// </summary>
	[Serializable]
	public class MethodCallReply : Response
	{
		public MethodCallReply(int requestId) : base(requestId)
		{}

		/// <summary>
		/// Gets or sets result by method call.
		/// </summary>
		public object Result { get; set; }

	}
}
