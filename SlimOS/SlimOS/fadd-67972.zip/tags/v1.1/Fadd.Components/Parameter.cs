﻿namespace Fadd.Components
{
	/// <summary>
	/// A parameter to a constructor.
	/// </summary>
	public class Parameter
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="Parameter"/> class.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <param name="value">The value.</param>
		public Parameter(string name, object value)
		{
			Name = name;
			Value = value;
		}
		/// <summary>
		/// Gets or sets name.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets value.
		/// </summary>
		public object Value { get; set; }
	}
}
