﻿using System;

namespace Fadd.Components
{
	class RequestParameterArgs : EventArgs
	{
	}
}
