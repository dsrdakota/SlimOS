﻿using System;
using System.Collections.Generic;

namespace Fadd.Components
{
	/// <summary>
	/// Two components are dependent of each other and can therefore not be created.
	/// </summary>
	public class CircularDependenciesException : Exception
	{
		private readonly List<Component> _components;

		/// <summary>
		/// Initializes a new instance of the <see cref="CircularDependenciesException"/> class.
		/// </summary>
		/// <param name="components">The components.</param>
		public CircularDependenciesException(List<Component> components)
		{
			_components = components;
		}

		/// <summary>
		/// Gets dependency tree
		/// </summary>
		public IList<Component> Components
		{
			get { return _components; }
		}
	}
}
