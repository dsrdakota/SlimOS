﻿using System;

namespace Fadd.Components
{
	/// <summary>
	/// Used for the <see cref="ComponentManager.Missing"/> event.
	/// </summary>
	public class ComponentMissingEventArgs : EventArgs
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="ComponentCreatedEventArgs"/> class.
		/// </summary>
		/// <param name="interfaceType">Type that will be requested by users.</param>
		public ComponentMissingEventArgs(Type interfaceType)
		{
			InterfaceType = interfaceType;
		}

		/// <summary>
		/// Gets interface type.
		/// </summary>
		public Type InterfaceType { get; private set; }

		/// <summary>
		/// Gets or set created instance.
		/// </summary>
		public object Instance { get; set; }

		/// <summary>
		/// Gets or sets if a new instance should be created each time the component is requested.
		/// </summary>
		public bool IsNotSingleton { get; set; }
	}
}
