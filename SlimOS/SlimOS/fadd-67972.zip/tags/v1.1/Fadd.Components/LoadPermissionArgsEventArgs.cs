﻿using System;

namespace Fadd.Components
{
	/// <summary>
	/// Used to determine if a component can be loaded.
	/// </summary>
	public class LoadPermissionArgsEventArgs : EventArgs
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="LoadPermissionArgsEventArgs"/> class.
		/// </summary>
		/// <param name="component">The component.</param>
		public LoadPermissionArgsEventArgs(Component component)
		{
			Component = component;
		}

		/// <summary>
		/// Gets Component that wants to be loaded.
		/// </summary>
		public Component Component { get; private set; }

		/// <summary>
		/// Gets or sets if the component can be loaded.
		/// </summary>
		public bool CanLoad { get; set; }
	}
}
