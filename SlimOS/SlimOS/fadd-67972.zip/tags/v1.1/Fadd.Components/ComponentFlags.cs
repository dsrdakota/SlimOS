﻿using System;

namespace Fadd.Components
{
	/// <summary>
	/// 
	/// </summary>
	[Flags]
	public enum ComponentFlags
	{
		/// <summary>
		/// No flags was specified
		/// </summary>
		None,

		/// <summary>
		/// Component is a not a singleton.
		/// </summary>
		/// <remarks>
		/// Means that a new instance is returned each time the interface is requested.
		/// </remarks>
		NotSingleton = 1,

		/// <summary>
		/// Can only be accessed from the same assembly that is was created from.
		/// </summary>
		Internal = 2
	}
}
