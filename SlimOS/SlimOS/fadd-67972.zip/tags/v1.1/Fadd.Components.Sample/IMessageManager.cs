﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fadd.Components.Sample
{
	/// <summary>
	/// Used to send messages.
	/// </summary>
	public interface IMessageManager
	{
		/// <summary>
		/// Send a message.
		/// </summary>
		/// <param name="receiver"></param>
		/// <param name="message"></param>
		void Send(string receiver, string message);

		/// <summary>
		/// Check for new messages.
		/// </summary>
		/// <returns></returns>
		string GetMessages();
	}
}
