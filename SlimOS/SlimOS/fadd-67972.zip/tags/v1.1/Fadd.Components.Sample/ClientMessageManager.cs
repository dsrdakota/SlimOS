﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fadd.Components.Remoting;

namespace Fadd.Components.Sample
{
	[Component(typeof(IMessageManager), "Client")]
	class ClientMessageManager : IMessageManager
	{
		private readonly RemotingChannel _bridge;

		public ClientMessageManager(RemotingChannel bridge)
		{
			_bridge = bridge;
		}

		/// <summary>
		/// Send a message.
		/// </summary>
		/// <param name="receiver"></param>
		/// <param name="message"></param>
		public void Send(string receiver, string message)
		{
			_bridge.Invoke(typeof(IMessageManager), "Send", receiver, message);
		}

		/// <summary>
		/// Check for new messages.
		/// </summary>
		/// <returns></returns>
		public string GetMessages()
		{
			return (string)_bridge.Invoke(typeof (IMessageManager), "GetMessages");
		}
	}
}
