﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fadd.Components.Sample
{
	[Component(typeof(ComponentThatNeedsStarting))]
	public class ComponentThatNeedsStarting : IStartable
	{
		public void Start()
		{
			Console.WriteLine("Started!");
		}
	}
}
