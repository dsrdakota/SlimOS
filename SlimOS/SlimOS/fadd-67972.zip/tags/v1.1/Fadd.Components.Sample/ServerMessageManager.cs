﻿namespace Fadd.Components.Sample
{
	/// <summary>
	/// 
	/// </summary>
	[Component(typeof(IMessageManager), "Server")]
	class ServerMessageManager : IMessageManager
	{
		/// <summary>
		/// Send a message.
		/// </summary>
		/// <param name="receiver"></param>
		/// <param name="message"></param>
		public void Send(string receiver, string message)
		{
			// Send a message using SMTP or something
		}

		/// <summary>
		/// Check for new messages.
		/// </summary>
		/// <returns></returns>
		public string GetMessages()
		{
			return "Hello World! ;)";
		}
	}
}
