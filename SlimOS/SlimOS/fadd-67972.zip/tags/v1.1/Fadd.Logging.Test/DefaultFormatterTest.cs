﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Xunit;

namespace Fadd.Logging.Test
{
	public class DefaultFormatterTest
	{
		DefaultFormatter _formatter = new DefaultFormatter();


		[Fact]
		private void TestParse()
		{
			_formatter.FormatString = "{DateTime:hh:mm:ss.fff} {LogLevel} {ThreadId} [{StackTrace:3,120}] {Message}";
			string formatted = _formatter.Format(new LogEntry
			                                     	{
			                                     		CreatedAt = DateTime.Now,
			                                     		Level = LogLevel.Info,
			                                     		Message = "OMG! Hellooooo WORLD!",
			                                     		StackFrames = GetDeepFrames(),
			                                     		ThreadId = 10
			                                     	});
			

		}

		private StackFrame[] GetDeepFrames()
		{
			return GetDeeperFrames();
		}

		private StackFrame[] GetDeeperFrames()
		{
			return new StackTrace(0).GetFrames();
		}

	}
}
