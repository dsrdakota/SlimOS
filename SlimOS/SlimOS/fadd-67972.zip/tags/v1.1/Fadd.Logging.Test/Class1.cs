﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fadd.Logging.Test
{
	public class Class1
	{
	}
}
