﻿namespace Fadd.JSON.Tokens
{
	public interface IContainerToken : IToken
	{
		void Add(IToken token);
	}
}