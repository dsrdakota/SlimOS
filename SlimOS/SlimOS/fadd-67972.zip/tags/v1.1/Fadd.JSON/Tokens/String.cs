﻿namespace Fadd.JSON.Tokens
{
	/// <summary>
	/// String token
	/// </summary>
	public class String : IToken
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="String"/> class.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <param name="value">The value.</param>
		public String(string name, string value)
		{
			Value = value;
			Name = name;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="String"/> class.
		/// </summary>
		/// <param name="value">The value.</param>
		public String(string value)
		{
			Value = value;
		}

		public string Value { get; private set; }

		#region IToken Members

		/// <summary>
		/// Gets or sets parent element.
		/// </summary>
		public IContainerToken Parent { get; set; }

		/// <summary>
		/// Gets or sets name of element.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets kind of token.
		/// </summary>
		public TokenId TokenId
		{
			get { return TokenId.String; }
		}

		#endregion

		/// <summary>
		/// Gets string representation.
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			return Value;
		}
	}
}