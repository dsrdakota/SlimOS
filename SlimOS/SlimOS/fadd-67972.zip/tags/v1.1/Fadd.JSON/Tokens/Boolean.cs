﻿namespace Fadd.JSON.Tokens
{
	internal class Boolean : IToken
	{
		public Boolean(string name, bool value)
		{
			Name = name;
			Value = value;
		}

		public bool Value { get; private set; }

		#region IToken Members

		/// <summary>
		/// Gets or sets parent element.
		/// </summary>
		public IContainerToken Parent { get; set; }

		/// <summary>
		/// Gets or sets name of element.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets kind of token.
		/// </summary>
		public TokenId TokenId
		{
			get { return TokenId.Boolean; }
		}

		#endregion
	}
}