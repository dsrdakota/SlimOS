﻿namespace Fadd.JSON.Tokens
{
	/// <summary>
	/// JSON Number.
	/// </summary>
	public class Number : IToken
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="Number"/> class.
		/// </summary>
		/// <param name="value">Value as string.</param>
		public Number(string value)
		{
			Value = value;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="Number"/> class.
		/// </summary>
		/// <param name="name">Name of property.</param>
		/// <param name="value">Value.</param>
		public Number(string name, string value)
		{
			Name = name;
			Value = value;
		}

		/// <summary>
		/// Gets the value.
		/// </summary>
		/// <value>The value.</value>
		public string Value { get; private set; }

		#region IToken Members

		/// <summary>
		/// Gets or sets parent element.
		/// </summary>
		public IContainerToken Parent { get; set; }

		/// <summary>
		/// Gets or sets name of element.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets kind of token.
		/// </summary>
		public TokenId TokenId
		{
			get { return TokenId.Number; }
		}

		#endregion
	}
}