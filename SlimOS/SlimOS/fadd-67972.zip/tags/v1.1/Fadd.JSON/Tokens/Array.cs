﻿using System.Collections;
using System.Collections.Generic;

namespace Fadd.JSON.Tokens
{
	/// <summary>
	/// Array 
	/// </summary>
	public class Array : IContainerToken, IEnumerable<IToken>
	{
		private List<IToken> _items = new List<IToken>();


		public IToken this[int index]
		{
			get { return _items[0]; }
		}

		/// <summary>
		/// Gets or sets items in the array.
		/// </summary>
		public List<IToken> Items
		{
			get { return _items; }
			set { _items = value; }
		}

		#region IContainerToken Members

		/// <summary>
		/// Gets or sets parent.
		/// </summary>
		public IContainerToken Parent { get; set; }

		public void Add(IToken child)
		{
			_items.Add(child);
			child.Parent = this;
		}

		/// <summary>
		/// Gets or sets name of array element.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets kind of token.
		/// </summary>
		/// <value></value>
		public TokenId TokenId
		{
			get { return TokenId.Array; }
		}

		#endregion

		#region IEnumerable<IToken> Members

		/// <summary>
		/// Returns an enumerator that iterates through the collection.
		/// </summary>
		/// <returns>
		/// A <see cref="T:System.Collections.Generic.IEnumerator`1"/> that can be used to iterate through the collection.
		/// </returns>
		/// <filterpriority>1</filterpriority>
		public IEnumerator<IToken> GetEnumerator()
		{
			return _items.GetEnumerator();
		}

		/// <summary>
		/// Returns an enumerator that iterates through a collection.
		/// </summary>
		/// <returns>
		/// An <see cref="T:System.Collections.IEnumerator"/> object that can be used to iterate through the collection.
		/// </returns>
		/// <filterpriority>2</filterpriority>
		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}

		#endregion
	}
}