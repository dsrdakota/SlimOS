﻿namespace Fadd.JSON.Tokens
{
	/// <summary>
	/// A JSON token
	/// </summary>
	public interface IToken
	{
		/// <summary>
		/// Gets or sets parent element.
		/// </summary>
		IContainerToken Parent { get; set; }

		/// <summary>
		/// Gets or sets name of element.
		/// </summary>
		string Name { get; set; }

		/// <summary>
		/// Gets kind of token.
		/// </summary>
		TokenId TokenId { get; }
	}

	public enum TokenId
	{
		Container,
		Array,
		String,
		Number,
		Object,
		Boolean,
		EndOfObject,
		EndOfArray
	}

	public enum ValueType
	{
		String,
		Boolean,
		Number
	}
}