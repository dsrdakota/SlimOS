﻿using System;
using System.Collections.Generic;
using System.IO;
using Fadd.Components.Remoting;

namespace Fadd.Components.Test
{
	class RemoteTestChannel : RemotingChannel
	{
		private List<byte[]> _sentPackets = new List<byte[]>();

		/// <summary>
		/// Initializes a new instance of the <see cref="RemotingChannel"/> class.
		/// </summary>
		/// <param name="manager">Manager used to invoke commands (if server side).</param>
		/// <param name="actAsServer">channel is acting as a server if set to <c>true</c>.</param>
		public RemoteTestChannel(ComponentManager manager) : base(manager)
		{
		}

		public List<byte[]> SentPackets
		{
			get { return _sentPackets; }
		}

		public void ToggleReceive(byte[] buffer, int offset, int count)
		{
			//AddToStream(buffer, offset, count);
            ProcessPacket();
		}

		protected override void Send(int functionId, byte[] buffer)
		{
			Stream stream = new MemoryStream();
			BinaryWriter writer = new BinaryWriter(stream);
			writer.Write(BitConverter.GetBytes(functionId));
			writer.Write(BitConverter.GetBytes(buffer.Length));
			writer.Write(buffer);

			stream.Seek(0, SeekOrigin.Begin);
			byte[] msg = new byte[stream.Length];
			stream.Write(msg, 0, (int)stream.Length);
			_sentPackets.Add(msg);
		}
	}
}
