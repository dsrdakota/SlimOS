﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fadd.Components.Remoting;

namespace Fadd.Components.Test
{
    public interface IRemotingGenerics
    {
        void Hello<T>(IEnumerable<T> shit);
    }

    [Component(typeof(IRemotingGenerics), "Client")]
    public class ClientRemotingGenerics:  IRemotingGenerics
    {
        private RemotingChannel _channel;

        public ClientRemotingGenerics(RemotingChannel channel)
        {
            _channel = channel;
        }

        public void Hello<T>(IEnumerable<T> shit)
        {
            _channel.InvokeGeneric(typeof (IRemotingGenerics), "Hello", new [] {typeof (T)}, new object[] {shit});
        }
    }

    [Component(typeof(IRemotingGenerics), "Server")]
    public class ServerRemotingGenerics : IRemotingGenerics
    {
        /// <summary>
        /// Gets or sets description
        /// </summary>
        public bool IsInvoked { get; set; }
        public void Hello<T>(IEnumerable<T> shit)
        {
            IsInvoked = true;
        }
    }
}
