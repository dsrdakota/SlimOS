﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using Fadd.Components.Remoting;
using Xunit;

namespace Fadd.Components.Test
{
	public class RemotingTest
	{
		private RemotingServer _serverChannel;
	    private ComponentManager _serverComponents;
        private RemotingChannel _clientChannel;
        private ComponentManager _clientComponents;

        public RemotingTest()
        {
            _serverComponents = new ComponentManager {Location = "Server"};
			_serverChannel = new RemotingServer(_serverComponents);
            _serverChannel.Start(new IPEndPoint(IPAddress.Loopback, 1243));
            _clientComponents = new ComponentManager {Location = "Client"};
            _clientChannel = new RemotingChannel(_clientComponents);
            _clientChannel.Start(new IPEndPoint(IPAddress.Loopback, 1243));

            ComponentFinder finder = new ComponentFinder();
            finder.Find(new List<Assembly>() {GetType().Assembly});
            _serverComponents.Add(finder.Components);
            _clientComponents.Add(finder.Components);
        }
        [Fact]
		private void TestReadOnePacket()
		{
            _clientComponents.Get<IRemotingGenerics>().Hello<int>(new List<int>() {5, 10});

            ServerRemotingGenerics server = (ServerRemotingGenerics) _serverComponents.Get<IRemotingGenerics>();
            Assert.True(server.IsInvoked);
		}
	}
}
