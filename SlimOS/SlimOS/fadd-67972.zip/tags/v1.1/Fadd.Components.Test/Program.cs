﻿
using System.Collections.Generic;
using System.Configuration;
using Fadd.Components.Tests;

namespace Fadd.Components
{
	class Program
	{
		public static void Main()
		{
			/*
			Assembly asm = Assembly.LoadFile(@"C:\projects\c#\libs\webserver\trunk\HttpServer\bin\Debug\HttpServer.dll");
			byte[] pk = asm.GetName().GetPublicKey();
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < pk.Length; ++i)
				sb.AppendFormat("{0:x}", pk[i]);
			sb.Append("<br>");
			sb.Append("<br>Public Key Token: ");
			byte[] pt = asm.GetName().GetPublicKeyToken();
			for (int i = 0; i < pt.Length - 1; ++i)
				sb.AppendFormat("{0:x}", pt[i]);*/


			//MissingArgument arg = manager.Get<MissingArgument>();

			ComponentFinder finder = new ComponentFinder();
			finder.Find("plugins\\*.dll");

		}
	}
}
