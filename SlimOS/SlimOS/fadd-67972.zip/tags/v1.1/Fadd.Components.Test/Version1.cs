﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fadd.Components;

namespace Fadd.Components.Tests
{
	[Component(typeof(IVersionComponent), 1)]
	class Version1 : IVersionComponent
	{
	}
}
