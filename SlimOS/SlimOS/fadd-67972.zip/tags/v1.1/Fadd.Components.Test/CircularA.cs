﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fadd.Components.Tests
{
	public class CircularA
	{
		public CircularA(CircularB test)
		{
			
		}
	}
}
