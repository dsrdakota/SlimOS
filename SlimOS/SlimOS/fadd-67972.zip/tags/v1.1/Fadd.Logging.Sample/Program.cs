﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fadd.Logging.Sample
{
	class Program
	{
		public static void Main()
		{
			LogProvider provider = new LogProvider();
			provider.LoadConfiguration();

			LogManager.SetProvider(provider);
			ILogger logger = LogManager.GetCurrentClassLogger();
			logger.Warning("Hello world, here I come!");
			Console.ReadLine();
		}
	}
}
