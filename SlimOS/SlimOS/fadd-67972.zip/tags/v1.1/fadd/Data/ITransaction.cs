﻿using System;
using System.Collections.Generic;

namespace Fadd.Data
{
    /// <summary>
    /// Database transaction.
    /// </summary>
    /// <remarks>
    /// Makes it possible to save a lot of changes only
    /// if all changes can succeed.
    /// </remarks>
    public interface ITransaction : IDataLayer, IDisposable
    {
        /// <summary>
        /// Cancel all changes made with the transaction.
        /// </summary>
        /// <remarks>
        /// Cancel will be called by Dispose if commit have
        /// not been called before the transaction is disposed.
        /// </remarks>
        void Cancel();

        /// <summary>
        /// Write all changes to the database.
        /// </summary>
        void Commit();
    }
}
