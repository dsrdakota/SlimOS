﻿using System.Diagnostics;

namespace Fadd.Data
{
    internal class TransactionWrapper : Transaction
    {
        private bool _isHandled;

        public TransactionWrapper(Transaction transaction) : base(transaction)
        {
            
        }
        /// <summary>
        /// Don't do anything since someone have already created a transaction.
        /// Let the initial creator commit.
        /// </summary>
        public override void Commit()
        {
            _isHandled = true;
        }

        /// <summary>
        /// Don't do anything since someone have already created a transaction.
        /// Let the initial creator commit or rollback.
        /// </summary>
        /// <exception cref="DataLayerException">To abort the transaction.</exception>
        public override void Cancel()
        {
#if DEBUG
            StackTrace trace = new StackTrace();
            StackFrame frame = trace.GetFrame(1);
            throw new DataLayerException(frame.GetFileName() + ":" + frame.GetFileLineNumber() + " do not own the transaction, but called Cancel."); 
#else
            throw new DataLayerException("Someone other than the transaction owner called cancel.");
#endif
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        /// <filterpriority>2</filterpriority>
        public override void Dispose()
        {
            if (_isHandled) return;
            
            base.Dispose();
        }
    }
}
