﻿namespace Fadd.Data.Migration
{
    /// <summary>
    /// Inteface for a handler of database updating
    /// </summary>
    public interface IMigrator
    {
        /// <summary>If changes has been made the migrator should update the database accordingly</summary>
        /// <param name="dataLayer">Used for saving migration data to the database</param>
        void Migrate(DataLayer dataLayer);
    }
}
