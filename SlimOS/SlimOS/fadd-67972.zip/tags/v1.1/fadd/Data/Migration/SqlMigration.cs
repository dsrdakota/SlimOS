﻿using System.Collections.Generic;

namespace Fadd.Data.Migration
{
    /// <summary>Holds information about a specific migration</summary>
    internal class SqlMigration
    {
        /// <summary>Sql for migration keyed by driver name (or default)</summary>
        private readonly Dictionary<string, string> _sql = new Dictionary<string, string>();

        public string Name { get; set;}

        public string Description { get; set; }

        public int Version { get; set; }

        public Dictionary<string, string> Sql { get { return _sql; } }
    }
}
