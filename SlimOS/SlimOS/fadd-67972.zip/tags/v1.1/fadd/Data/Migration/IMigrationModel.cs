﻿using System;

namespace Fadd.Data.Migration
{
    /// <summary>
    /// Provides a general view of the model needed for saving migration data in the database
    /// </summary>
    /// <remarks>
    /// The model and mapping must be specified explicitly by the migration user since tables most oftenly
    /// should match a certain coding convention. Explicitly declaring the model also allows for saving 
    /// extra version data.
    /// </remarks>
    public interface IMigrationModel
    {
        /// <summary>Gets or sets the version number of the migration</summary>
        int VersionNumber { get; set; }

        /// <summary>Gets or sets the date and time for when the database was updated to the migration version</summary>
        DateTime UpdateTime { get; set; }
    }
}