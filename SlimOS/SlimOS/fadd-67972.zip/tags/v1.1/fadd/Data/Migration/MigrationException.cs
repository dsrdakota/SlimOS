﻿using System;

namespace Fadd.Data.Migration
{
    /// <summary>Describes an exception occured during migration of database</summary>
    public class MigrationException : Exception
    {
        /// <summary>Initializes the exception with a message</summary>
        /// <param name="message">The exception message describing the error occured</param>
        public MigrationException(string message) : base(message)
        {
        }

        /// <summary>Initializes the exception with a message</summary>
        /// <param name="message">The exception message describing the error occured</param>
        /// <param name="innerException">The exception triggering the throwing of this exception</param>
        public MigrationException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
