﻿using System;

namespace Fadd.Data.Migration
{
    /// <summary>Specific exception for errors occured during xml handling</summary>
    public class MigrationXmlException : MigrationException
    {
        /// <summary>Initializes the <see cref="MigrationXmlException"/></summary>
        /// <param name="message">Error message to display</param>
        public MigrationXmlException(string message) : base(message)
        {
        }

        /// <summary>Initializes the <see cref="MigrationXmlException"/></summary>
        /// <param name="message">Error message to display</param>
        /// <param name="innerException">Exception that brought the throwing of the xml exception</param>
        public MigrationXmlException(string message, Exception innerException) : base(message, innerException)
        {
        }

        /// <summary>Initializes the <see cref="MigrationXmlException"/></summary>
        /// <param name="messages">Error messages to display</param>
        public MigrationXmlException(string[] messages) : base(string.Join(Environment.NewLine, messages))
        {
        }

        /// <summary>Retrieves the error messages not prepended with readable error string</summary>
        public string OriginalMessage
        {
            get { return base.Message; }
        }

        public override string Message
        {
            get
            {
                return "Error occured while parsing migration xml: " + base.Message;
            }
        }
    }
}
