using System;
using System.Collections.Generic;
#if TEST
using Xunit;
#endif

namespace Fadd.Globalization.Localizations
{
    /// <summary>
    /// Used to parse Swedish dates and times.
    /// </summary>
    public class DateTimeHelper1053 : IDateTimeHelper
    {
		private static readonly Dictionary<string, string> _singular = new Dictionary<string, string>();

		/// <summary>
		/// Static constructor setting up helping maps
		/// </summary>
		static DateTimeHelper1053()
		{
			_singular.Add("m�nader", "m�nad");
			_singular.Add("dagar", "dag");
			_singular.Add("timmar", "timme");
			_singular.Add("minuter", "minut");
			_singular.Add("sekunder", "sekund");
		}

        /// <summary>
        /// Will try to parse the date/time using the local parser.
		/// Will also try the default <see cref="DateTime.Parse(string)"/> method if date is in an unknown format.
        /// </summary>
        /// <param name="value">date/time string</param>
        /// <returns>A <see cref="DateTime"/> if parsed successfully; otherwise <see cref="DateTime.MinValue"/>.</returns>
        /// <exception cref="FormatException">If the date/time format is invalid.</exception>
        /// <exception cref="ArgumentOutOfRangeException">If month/day/hour/minute/second are not within their ranges.</exception>
        /// <remarks>
        /// Can parse one of the following formats:<br />
        /// YYYY-MM-DD HH:MM:SS <br />
        /// YYYY-MM-DD HH:MM<br />
        /// YYYYMMDDHHMM<br />
        /// YYYYMMDDHHMMSS<br />
        /// YYMMDDHHMM
        /// </remarks>
        public DateTime ParseDateTime(string value)
        {
            Check.NotEmpty(value, "value");

            int[] values = new int[6];
            string date, time;
            if (value.IndexOf(' ') != -1)
            {
                string[] parts = value.Split(' ');
                if (parts.Length != 2)
                    throw new FormatException("Felaktig datum/tid: " + value);

                date = parts[0];
                time = parts[1];
            }
            else
                switch (value.Length)
                {
                    case 12:
                        date = value.Substring(0, 8);
                        time = value.Substring(8, 4);
                        break;
                    case 14:
                        date = value.Substring(0, 8);
                        time = value.Substring(8, 6);
                        break;
                    case 10:
                        date = value.Substring(0, 6);
                        time = value.Substring(6, 4);
                        break;
                    default:
                        return DateTime.Parse(value);
                }

            ParseDate(date, values, 0);
            ParseTime(time, values, 3);
            return new DateTime(values[0], values[1], values[2], values[3], values[4], values[5]);
        }

        /// <summary>
        /// Will try to parse the date/time using the local parser.
		/// Will also try the default <see cref="DateTime.Parse(string)"/> method if date is in an unknown format.
        /// </summary>
        /// <param name="date">date string. Date will be set to current if value is not specified.</param>
        /// <param name="time">time string. Time will be set to current if not specified.</param>
        /// <returns>A <see cref="DateTime"/></returns>
        /// <exception cref="FormatException">If the date/time format is invalid.</exception>
        /// <exception cref="ArgumentOutOfRangeException">If month/day/hour/minute/second are not within their ranges.</exception>
        public DateTime ParseDateTime(string date, string time)
        {
            int[] values = new int[6];
            if (!string.IsNullOrEmpty(date))
                ParseDate(date, values, 0);
            if (!string.IsNullOrEmpty(time))
                ParseDate(time, values, 3);
            return new DateTime(values[0], values[1], values[2], values[3], values[4], values[5]);
        }

#if TEST
        [Fact]
        private void TestParseDateTime()
        {
            // YYYY-MM-DD HH:MM:SS <br />
            // YYYY-MM-DD HH:MM<br />
            // YYYYMMDDHHMM<br />
            // YYYYMMDDHHMMSS<br />
            // YYMMDDHHMM            
            DateTime dt = ParseDateTime("2008-01-20 12:01:03");
            AssertDate(dt, 2008, 1, 20);
            AssertTime(dt, 12, 1, 3);
            dt = ParseDateTime("2008-11-03 21:10");
            AssertDate(dt, 2008, 11, 3);
            AssertTime(dt, 21, 10, 0);
            dt = ParseDateTime("200811032110");
            AssertDate(dt, 2008, 11, 3);
            AssertTime(dt, 21, 10, 0);
            dt = ParseDateTime("20081103211013");
            AssertDate(dt, 2008, 11, 3);
            AssertTime(dt, 21, 10, 13);
            dt = ParseDateTime("0811032110");
            AssertDate(dt, 2008, 11, 3);
            AssertTime(dt, 21, 10, 0);

            Assert.Throws(typeof(FormatException), delegate { ParseDateTime("0811032110243"); });
            Assert.Throws(typeof(FormatException), delegate { ParseDateTime("2008--01-10 12:00"); });
            Assert.Throws(typeof(FormatException), delegate { ParseDateTime("2008-01/10 12:00"); });
            // Assert.Throws(typeof(FormatException), delegate { ParseDateTime("2008-01-10-12:00"); }); //- handled by DateTime.Parse
            Assert.Throws(typeof(FormatException), delegate { ParseDateTime("2008-01-10:12:00"); });
            Assert.Throws(typeof(FormatException), delegate { ParseDateTime("2008-01-10a12:00"); });
            Assert.Throws(typeof(FormatException), delegate { ParseDateTime("2008-01-10 12/00"); });
        }

        private static void AssertDate(DateTime dateTime, int year, int month, int day)
        {
            Assert.Equal(year, dateTime.Year);
            Assert.Equal(month, dateTime.Month);
            Assert.Equal(day, dateTime.Day);
        }
        private static void AssertTime(DateTime dateTime, int hour, int minute, int second)
        {
            Assert.Equal(hour, dateTime.Hour);
            Assert.Equal(minute, dateTime.Minute);
            Assert.Equal(second, dateTime.Second);
        }
#endif

        /// <summary>
        /// Tries to parse a date string.
        /// </summary>
        /// <param name="value">Can contain a complete date or parts of it (which parts depends on the country).</param>
        /// <returns>
        /// A <see cref="DateTime"/> containing the date (time is 0) if parsed successfully; otherwise <see cref="DateTime.MinValue"/>.
        /// </returns>
        /// <remarks>
        /// YYYY-MM-DD
        /// YYYYMMDD
        /// YYMMDD
        /// MMDD
        /// </remarks>
        public DateTime ParseDate(string value)
        {
            int[] values = new int[3];
            ParseDate(value, values, 0);
            return new DateTime(values[0], values[1], values[2], 0, 0, 0);
        }

#if TEST
        [Fact]
        private void TestParseDate()
        {
            // YYYY-MM-DD
            // YYYYMMDD
            // YYMMDD
            // MMDD
            DateTime dt = ParseDate("2008-01-20");
            AssertDate(dt, 2008, 1, 20);
            dt = ParseDate("20081103");
            AssertDate(dt, 2008, 11, 3);
            dt = ParseDate("081104");
            AssertDate(dt, 2008, 11, 4);

            DateTime verifyDate = DateTime.Now.AddMonths(-1);
            dt = ParseDate(string.Format("{0:00}20", verifyDate.Month));
            AssertDate(dt, verifyDate.Year + 1, verifyDate.Month, 20);

            verifyDate = DateTime.Now.AddMonths(1);
            dt = ParseDate(string.Format("{0:00}20", verifyDate.Month));
            AssertDate(dt, verifyDate.Year, verifyDate.Month, 20);

            Assert.Throws(typeof(FormatException), delegate { ParseDate("0811032110243"); });
            Assert.Throws(typeof(FormatException), delegate { ParseDate("2008--01-10"); });
            Assert.Throws(typeof(FormatException), delegate { ParseDate("2008-01/10"); });
            Assert.Throws(typeof(FormatException), delegate { ParseDate("200801234"); });
            Assert.Throws(typeof(FormatException), delegate { ParseDate("2008-40-20"); });
            Assert.Throws(typeof(FormatException), delegate { ParseDate("2008-01-10 12/00"); });
        }
#endif
        /// <summary>
        /// Can parse one of the following formats:
        /// YYYY-MM-DD
        /// YYYYMMDD
        /// YYMMDD
        /// MMDD
        /// </summary>
        /// <param name="value">contains a date string.</param>
        /// <param name="values">array that parsed values are written to.</param>
        /// <param name="offset">where in array to start write values</param>
        /// <exception cref="FormatException">If value contains an unknown format.</exception>
        /// <exception cref="ArgumentException">If month/day are not within their ranges.</exception>
        /// <exception cref="ArgumentOutOfRangeException"><c>offset</c> is out of range.</exception>
        public void ParseDate(string value, int[] values, int offset)
        {
            Check.NotEmpty(value, "value");
            Check.Require(values, "values");
            if (values.Length < offset + 3)
                throw new ArgumentOutOfRangeException("offset");

            if (value.IndexOf('-') != -1)
            {
                string[] parts = value.Split('-');

                if (parts.Length != 3)
                    throw new FormatException("Felaktigt datumformat.");

                values[offset] = int.Parse(parts[0]);
                values[offset + 1] = int.Parse(parts[1]);
                values[offset + 2] = int.Parse(parts[2]);
            }
            
            else
                switch (value.Length)
                {
                    case 8://YYYYMMDD
                        values[offset + 0] = int.Parse(value.Substring(0, 4));
                        values[offset + 1] = int.Parse(value.Substring(4, 2));
                        values[offset + 2] = int.Parse(value.Substring(6, 2));
                        break;
                    case 6://yymmdd
                        values[offset + 0] = int.Parse(value.Substring(0, 2)) + 2000; // won't work 21xx (buho)
                        values[offset + 1] = int.Parse(value.Substring(2, 2));
                        values[offset + 2] = int.Parse(value.Substring(4, 2));
                        break;
                    case 4://mmdd
                        values[offset + 1] = int.Parse(value.Substring(0, 2));
                        values[offset + 2] = int.Parse(value.Substring(2, 2));
                        if ((values[offset + 1] == DateTime.Now.Month && values[2] < DateTime.Now.Day) ||
                            values[offset + 1] < DateTime.Now.Month)
                            values[offset + 0] = DateTime.Now.Year + 1;
                        else
                            values[offset + 0] = DateTime.Now.Year;
                        break;
                    default:
                        throw new FormatException("Ogiltigt datumformat: " + value);
                }

            ValidateDate(values[offset + 0], values[offset + 1], values[offset + 2], true);
        }

        /// <summary>
        /// Tries to parse a time string.
        /// </summary>
        /// <param name="value">Can contain a complete time or parts of it (which parts depends on the country).</param>
        /// <returns>A <see cref="DateTime"/> containing the time (date is 0) if parsed successfully; otherwise <see cref="DateTime.MinValue"/>.</returns>
        public DateTime ParseTime(string value)
        {
            int[] values = new int[3];
            ParseTime(value, values, 0);
            return new DateTime(0, 0, 0, values[0], values[1], values[2]);
        }


        /// <summary>
        /// Can parse one of the following formats:
        /// HH:MM:SS
        /// HH:MM
        /// HHMM
        /// HHMMSS
        /// </summary>
        /// <param name="value">a time value</param>
        /// <param name="values">array that will be filled. Must contain three slots.</param>
        /// <param name="offset">Where in the array to start write values</param>
        /// <returns>true if parsed successfully; otherwise false.</returns>
        /// <exception cref="ArgumentOutOfRangeException"><c>offset</c> is out of range.</exception>
        /// <exception cref="FormatException">Invalid time format.</exception>
        public void ParseTime(string value, int[] values, int offset)
        {
            if (values.Length < offset + 3)
                throw new ArgumentOutOfRangeException("offset");

            if (value.IndexOf(':') != -1)
            {
                string[] parts = value.Split(':');
                if (parts.Length < 2 || parts.Length > 3)
                    throw new FormatException("Ogiltligt tidsformat.");

                values[offset] = int.Parse(parts[0]);
                values[offset + 1] = int.Parse(parts[1]);
                if (parts.Length == 3)
                    values[offset + 2] = int.Parse(parts[2]);
            }
            else
                switch (value.Length)
                {
                    case 4:
                        values[offset + 0] = int.Parse(value.Substring(0, 2));
                        values[offset + 1] = int.Parse(value.Substring(2, 2));
                        break;
                    case 6:
                        values[offset + 0] = int.Parse(value.Substring(0, 2));
                        values[offset + 1] = int.Parse(value.Substring(2, 2));
                        values[offset + 2] = int.Parse(value.Substring(4, 2));
                        break;
                    default:
                        throw new FormatException("Ogiltligt tidsformat.");
                }

            ValidateTime(values[offset + 0], values[offset + 1], values[offset + 2], true);
        }

        /// <summary>
        /// Validate a date
        /// </summary>
        /// <param name="year">year value</param>
        /// <param name="month">month value</param>
        /// <param name="day">day value</param>
        /// <param name="throwException">throw exceptions</param>
        /// <returns>true if specified values are a correct date; otherwise false.</returns>
        /// <exception cref="ArgumentException">If any of the values are not in the allowed ranges.</exception>
        /// <exception cref="FormatException">Month must be between 1 and 12.</exception>
        public bool ValidateDate(int year, int month, int day, bool throwException)
        {
            if (month < 1 || month > 12)
                throw new FormatException("M�nad m�ste vara mellan 1 och 12.");

            int days = DateTime.DaysInMonth(year, month);
            if (month <= 0 || month > 12)
            {
                if (throwException)
                    throw new ArgumentException("Felaktigt m�nads-v�rde.", "month");
                return false;
            }

            if (day <= 0 || day > days)
            {
                if (throwException)
                    throw new ArgumentException("Felaktigt dag-v�rde.", "day");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Validate a time value.
        /// </summary>
        /// <param name="hour">hour</param>
        /// <param name="minute">minute</param>
        /// <param name="throwException">throw exceptions</param>
        /// <exception cref="ArgumentException">If any of the values are not in the allowed ranges.</exception>
        public bool ValidateTime(int hour, int minute, bool throwException)
        {
            return ValidateTime(hour, minute, 0, throwException);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="hour"></param>
        /// <param name="minute"></param>
        /// <param name="second"></param>
        /// <param name="throwException"></param>
        /// <exception cref="ArgumentException">If any of the values are not in the allowed ranges.</exception>
        public bool ValidateTime(int hour, int minute, int second, bool throwException)
        {
            if (hour < 0 || hour > 23)
            {
                if (throwException)
                    throw new ArgumentException("Angiven timme �r inte korrekt.", "hour");
                return false;
            }

            if (minute < 0 || minute > 59)
            {
                if (throwException)
                    throw new ArgumentException("Felaktigt minut-v�rde.", "minute");
                return false;
            }
            if (second < 0 || second > 59)
            {
                if (throwException)
                    throw new ArgumentException("Felaktigt sekund-v�rde", "second");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Format a date as a string.
        /// </summary>
        /// <param name="dateTime">A date/time</param>
        /// <returns>Examples: "Yesterday", "On monday"</returns>
        public string FormatDate(DateTime dateTime)
        {
            string formatted;
            DateTime now = DateTime.Now;

            if (dateTime.DayOfYear == now.DayOfYear)
                formatted = "Idag ";
            else if (dateTime == now.AddDays(-1))
                formatted = "Ig�r ";
            else if (dateTime == now.AddDays(1))
                formatted = "Imorgon ";
            else if (dateTime > now && dateTime < now.AddDays(7))
                formatted = dateTime.ToString("dddd") + " ";//this week
            else
            {
            	formatted = dateTime.ToString("dddd") + "en den ";
				formatted += dateTime.ToString("d MMMM");
                if (dateTime.Year != now.Year)
                    formatted += " " + dateTime.Year;
            }
            return formatted;
        }

#if TEST
		/// <summary>
		/// Test function for the <see cref="FormatDate"/> method
		/// </summary>
		[Fact]
		private static void TestFormatDate()
		{
			DateTime now = DateTime.Now;
			DateTimeHelper1053 helper = new DateTimeHelper1053();
			string result = helper.FormatDate(new DateTime(2008, 8, 4, 17, 30, 0));
			Assert.Equal("m�ndag, 4 augusti 17:30", result);
		}
#endif

        /// <summary>
        /// Format a date as a string.
        /// </summary>
        /// <param name="dateTime">A date/time</param>
        /// <returns>Examples: "Yesterday at 12:20pm", "On Monday at 11:38am"</returns>
        public string FormatDateTime(DateTime dateTime)
        {
			string formatted;
			DateTime now = DateTime.Now;

			if (dateTime.DayOfYear == now.DayOfYear)
				formatted = "Idag ";
			else if (dateTime == now.AddDays(-1))
				formatted = "Ig�r ";
			else if (dateTime == now.AddDays(1))
				formatted = "Imorgon ";
			else if (dateTime > now && dateTime < now.AddDays(7))
				formatted = dateTime.ToString("dddd") + " ";//this week
			else
			{
				formatted = dateTime.ToString("dddd") + "en den ";
				formatted += dateTime.ToString("d MMMM");
				if (dateTime.Year != now.Year)
					formatted += " " + dateTime.Year;
			}

			formatted += " klockan " + dateTime.ToString("HH:mm");

			return formatted;
        }

        /// <summary>
        /// Get duration as a human friendly string.
        /// </summary>
        /// <param name="from">Start time of duration</param>
        /// <param name="to">End time of duration</param>
        /// <param name="durationDetail">The detail in which to display the duration</param>
        /// <param name="measures">Number of time units to display</param>
        /// <returns>
        /// A string like: 1 month, 2 weeks, and 3 days.
        /// </returns>
        public string GetDuration(DateTime from, DateTime to, DurationDetail durationDetail, int measures)
        {
			Check.Min(0, to.CompareTo(from), "DateTime 'from' must be earlier than 'to' date");
    		MonthSpan monthSpan = MonthSpan.Create(from, to);
    		TimeSpan span = to.Subtract(from);

			return GetDuration(span, monthSpan, durationDetail, measures);
		}

        /// <summary>
        /// Get duration as a human friendly string. Displays all time unit durations.
        /// </summary>
        /// <param name="from">Start time of duration</param>
        /// <param name="to">End time of duration</param>
        /// <returns></returns>
        public string GetDuration(DateTime from, DateTime to)
        {
            return GetDuration(from, to, DurationDetail.Seconds, 0);
        }

        /// <summary>
        /// Get duration as a human friendly string.
        /// </summary>
        /// <param name="span">The timespan for which to output the duration</param>
        /// <param name="durationDetail">The detail in which to display the duration</param>
        /// <param name="measures">Number of time measures to display</param>
        /// <returns>
        /// A string like: 1 month, 2 weeks, and 3 days.
        /// </returns>
        /// <remarks><see cref="DurationDetail.Months"/> cannot be used when using this method since counting of months
        /// requires both to and from date time information, in such a case user <see cref="GetDuration(TimeSpan)"/></remarks>
        /// <exception cref="InvalidOperationException">Since <see cref="TimeSpan"/> is given as duration months cannot be calculated, try GetDuration(DateTime, DateTime, DurationDetail) instead.</exception>
		public string GetDuration(TimeSpan span, DurationDetail durationDetail, int measures)
		{
			if(durationDetail == DurationDetail.Months)
				throw new InvalidOperationException("Since TimeSpan is given as duration months cannot be calculated, try GetDuration(DateTime, DateTime, DurationDetail) instead.");

			MonthSpan monthSpan = new MonthSpan {Days = span.Days, Months = 0};
        	return GetDuration(span, monthSpan, durationDetail, measures);
		}

        /// <summary>
        /// Get duration as a human friendly string. Displays all time unit durations.
        /// </summary>
        /// <param name="span">The timespan for which to output the duration</param>
        /// <returns></returns>
        public string GetDuration(TimeSpan span)
        {
            return GetDuration(span, DurationDetail.Seconds, 0);
        }

        private static string GetDuration(TimeSpan span, MonthSpan monthSpan, DurationDetail minDetail, int measures)
        {
            if (measures < 1)
                measures = 5;


            string result = string.Empty;
            for (int i = (int)DurationDetail.Months; i >= (int)minDetail && measures > 0; i--)
            {
                string amount = GetAmount(monthSpan, span, (DurationDetail) i, measures == 1);
                if (amount == string.Empty) 
                    continue;

                result += amount;
                measures--;
            }

            return result.TrimEnd(',', ' ');
        }

		#region GetDuration helpers

		/// <summary>
		/// Displays a value defined by the <see cref="DurationDetail"/> either as a part or as a total
		/// </summary>
		/// <param name="monthSpan">Number of months and days</param>
		/// <param name="timeSpan">TimeSpan containing detailed times</param>
		/// <param name="getDetail">The time unit to retrieve</param>
		/// <param name="showTotal">True if the total amount of the time unit should be returned or just a portion of it</param>
		/// <returns>A string in the form 'amount timunitname, '</returns>
		private static string GetAmount(MonthSpan monthSpan, TimeSpan timeSpan, DurationDetail getDetail, bool showTotal)
		{
			// Return full string in the form (X m�nader, )
			switch (getDetail)
			{
				case DurationDetail.Months:
			        return GetName("m�nader", showTotal ? GetAmount(monthSpan, timeSpan, getDetail) : monthSpan.Months);
				case DurationDetail.Days:
                    return GetName("dagar", showTotal ? GetAmount(monthSpan, timeSpan, getDetail) : monthSpan.Days);
				case DurationDetail.Hours:
                    return GetName("timmar", showTotal ? GetAmount(monthSpan, timeSpan, getDetail) : timeSpan.Hours);
				case DurationDetail.Minutes:
                    return GetName("minuter", showTotal ? GetAmount(monthSpan, timeSpan, getDetail) : timeSpan.Minutes);
				case DurationDetail.Seconds:
					return GetName("sekunder", timeSpan.Seconds);
			}

			throw new InvalidOperationException("Incorrect DurationDetail given!");
		}

        private static int GetAmount(MonthSpan monthSpan, TimeSpan timeSpan, DurationDetail detail)
        {
            switch (detail)
            {
                case DurationDetail.Months:
                    return monthSpan.Months + monthSpan.Days/30;
                case DurationDetail.Days:
                    return (monthSpan.Days + GetAmount(monthSpan, timeSpan, DurationDetail.Hours) / 24);
                case DurationDetail.Hours:
                    return (timeSpan.Hours + GetAmount(monthSpan, timeSpan, DurationDetail.Minutes) / 60);
                case DurationDetail.Minutes:
                    return (timeSpan.Minutes + GetAmount(monthSpan, timeSpan, DurationDetail.Seconds) / 60);
                case DurationDetail.Seconds:
                    return timeSpan.Seconds;
            }

            throw new InvalidOperationException("Unsupported DurationDetail given");
        }

		/// <summary>
		/// Retrieves a singular or plural name with amount and comma padded, ie '3 m�nader, ' or '1 m�nad, '
		/// </summary>
		/// <param name="pluralName">The name in plural (used to map for singular name)</param>
		/// <param name="amount">The amount to display</param>
		private static string GetName(string pluralName, int amount)
		{
            if (amount == 0)
                return string.Empty;

			string name = pluralName;
			if (amount == 1)
				name = _singular[pluralName];

			return string.Format("{0} {1}, ", amount, name);
		}

		#endregion

		#region GetDurationTest method
#if TEST
		[Fact]
		private static void GetDurationTest()
		{
			DateTimeHelper1053 helper = new DateTimeHelper1053();
			string result = helper.GetDuration(new DateTime(2008, 09, 08, 02, 30, 15), new DateTime(2008, 10, 03, 03, 0, 0), DurationDetail.Seconds, 3);
			Assert.Equal("25 dagar, 29 minuter, 45 sekunder", result);

			result = helper.GetDuration(new DateTime(2008, 09, 08, 02, 30, 15), new DateTime(2008, 09, 08, 06, 31, 16), DurationDetail.Hours, 5);
			Assert.Equal("4 timmar", result);

			result = helper.GetDuration(new DateTime(2008, 09, 08, 02, 30, 15), new DateTime(2008, 10, 09, 03, 0, 0), DurationDetail.Seconds, 2);
			Assert.Equal("1 m�nad, 1 dag", result);

			// Test so that 2 measures can be only 1 measure
            result = helper.GetDuration(new DateTime(2008, 09, 08, 02, 30, 15), new DateTime(2008, 09, 08, 02, 30, 18), DurationDetail.Seconds, 0);
			Assert.Equal("3 sekunder", result);

			// Test 1 measure
			result = helper.GetDuration(new DateTime(2008, 09, 08, 02, 30, 15), new DateTime(2008, 09, 12, 02, 30, 18), DurationDetail.Seconds, 1);
			Assert.Equal("4 dagar", result);

            // Test 1 measure
            result = helper.GetDuration(new DateTime(2008, 09, 08, 02, 30, 15), new DateTime(2008, 09, 12, 02, 30, 18), DurationDetail.Seconds, 1);
            Assert.Equal("4 dagar", result);
		}
#endif
		#endregion
	}
}