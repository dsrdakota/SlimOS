﻿namespace Fadd.Logging
{
    /// <summary>
    /// Importance of a log entry.
    /// </summary>
    public enum LogLevel
    {
        /// <summary>
        /// Used to be able to trace program execution.
        /// </summary>
        Trace,

        /// <summary>
        /// Entries that are helpful when debugging.
        /// </summary>
        Debug,

        /// <summary>
        /// Information that can be helpful during normal program execution.
        /// </summary>
        Info,

        /// <summary>
        /// Something unexpected happened, but program execution can continue as expected.
        /// </summary>
        Warning,

        /// <summary>
        /// Something went really wrong. Program execution cannot continue as expected,
        /// but there is no need to shutdown the program.
        /// </summary>
        Error,

        /// <summary>
        /// Major disaster, program ought to be shut down and restarted.
        /// </summary>
        Fatal
    }
}
