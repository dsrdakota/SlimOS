﻿using System;
using System.Diagnostics;

namespace Fadd.Logging
{
	/// <summary>
	/// A queued log entry.
	/// </summary>
	public class LogEntry
	{
		/// <summary>
		/// Gets or sets log level
		/// </summary>
		public LogLevel Level { get; set; }

		/// <summary>
		/// Gets or sets message.
		/// </summary>
		public string Message { get; set; }

		/// <summary>
		/// Gets or sets when entry was created
		/// </summary>
		public DateTime CreatedAt { get; set; }

		/// <summary>
		/// Gets or sets thread that the entry was written from.
		/// </summary>
		public int ThreadId { get; set; }

		/// <summary>
		/// Gets or sets stack frames
		/// </summary>
		public StackFrame[] StackFrames { get; set; }

		/// <summary>
		/// Gets or sets exception thrown in application.
		/// </summary>
		public Exception Exception { get; set; }

		/// <summary>
		/// Gets or sets logger that got this entry.
		/// </summary>
		public ILogger Logger { get; set; }
	}
}