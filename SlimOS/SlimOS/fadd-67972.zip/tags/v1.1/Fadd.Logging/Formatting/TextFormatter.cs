﻿namespace Fadd.Logging.Formatting
{
	/// <summary>
	/// Prints text that do not contain any formatting
	/// </summary>
	public class TextFormatter : IPartFormatter
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="TextFormatter"/> class.
		/// </summary>
		/// <param name="text">Text to display.</param>
		public TextFormatter(string text)
		{
			Text = text;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="TextFormatter"/> class.
		/// </summary>
		public TextFormatter()
		{

		}
		/// <summary>
		/// Gets or sets text to display.
		/// </summary>
		public string Text { get; set; }


		/// <summary>
		/// Format a part of the log entry
		/// </summary>
		/// <param name="entry">Part to format</param>
		/// <returns>formatted part</returns>
		public string Format(LogEntry entry)
		{
			return Text;
		}
	}
}
