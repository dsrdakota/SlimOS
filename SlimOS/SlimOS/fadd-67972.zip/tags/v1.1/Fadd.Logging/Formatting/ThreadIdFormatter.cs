﻿namespace Fadd.Logging.Formatting
{
	/// <summary>
	/// Format thread id to be three characters wide.
	/// </summary>
	public class ThreadIdFormatter : IPartFormatter
	{
		/// <summary>
		/// Format a part of the log entry
		/// </summary>
		/// <param name="entry">Part to format</param>
		/// <returns>formatted part</returns>
		public string Format(LogEntry entry)
		{
			return entry.ThreadId.ToString("000");
		}
	}
}
