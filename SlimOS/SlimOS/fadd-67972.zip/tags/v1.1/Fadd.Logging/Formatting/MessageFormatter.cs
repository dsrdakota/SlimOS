﻿namespace Fadd.Logging.Formatting
{
	/// <summary>
	/// Will only add the log message, no formatting is made.
	/// </summary>
	public class MessageFormatter : IPartFormatter
	{
		/// <summary>
		/// Format a part of the log entry
		/// </summary>
		/// <param name="entry">Part to format</param>
		/// <returns>formatted part</returns>
		public string Format(LogEntry entry)
		{
			return entry.Message;
		}
	}
}
