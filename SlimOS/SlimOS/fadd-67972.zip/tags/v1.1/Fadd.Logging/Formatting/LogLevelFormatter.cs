﻿namespace Fadd.Logging.Formatting
{
	/// <summary>
	/// Pad log level with spaces to be 7 characters.
	/// </summary>
	public class LogLevelFormatter : IPartFormatter
	{
		/// <summary>
		/// Format a part of the log entry
		/// </summary>
		/// <param name="entry">Part to format</param>
		/// <returns>formatted part</returns>
		public string Format(LogEntry entry)
		{
			return entry.Level.ToString().PadLeft(7, ' ');
		}
	}
}
