﻿namespace Fadd.Logging.Formatting
{
	/// <summary>
	/// Prints the exception
	/// </summary>
	public class ExceptionFormatter : IPartFormatter
	{
		/// <summary>
		/// Format a part of the log entry
		/// </summary>
		/// <param name="entry">Part to format</param>
		/// <returns>formatted part</returns>
		public string Format(LogEntry entry)
		{
			return entry.Exception.ToString();
		}
	}
}
