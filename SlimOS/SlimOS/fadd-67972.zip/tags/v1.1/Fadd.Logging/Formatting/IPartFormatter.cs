﻿namespace Fadd.Logging.Formatting
{
	/// <summary>
	/// Used to format a part in a log entry.
	/// </summary>
	public interface IPartFormatter
	{
		/// <summary>
		/// Format a part of the log entry
		/// </summary>
		/// <param name="entry">Part to format</param>
		/// <returns>formatted part</returns>
		string Format(LogEntry entry);
	}
}
