﻿using System;

namespace Fadd.Logging.Formatting
{
	/// <summary>
	/// Formats date and time.
	/// </summary>
	public class DateTimeFormatter : IPartFormatter
	{
		/// <summary>
		/// Gets or sets date time format.
		/// </summary>
		public string FormatString { get; set; }

		/// <summary>
		/// Format a part of the log entry
		/// </summary>
		/// <param name="entry">Part to format</param>
		/// <returns>formatted part</returns>
		public string Format(LogEntry entry)
		{
			return entry.CreatedAt.ToString(FormatString);
		}

		/// <summary>
		/// format the date time.
		/// </summary>
		/// <param name="dateTime"></param>
		/// <returns></returns>
		public string Format(DateTime dateTime)
		{
			return dateTime.ToString(FormatString);
		}
	}
}
