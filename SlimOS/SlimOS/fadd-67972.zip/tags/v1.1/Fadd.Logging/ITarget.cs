﻿using System;
using System.Configuration;

namespace Fadd.Logging
{
	/// <summary>
	/// Logger target.
	/// </summary>
	/// <remarks>
	/// All targets <c>MUST</c> have a constructor which takes a <see cref="IFormatter"/> object.
	/// </remarks>
	public interface ITarget
	{
		/// <summary>
		/// Load configuration.
		/// </summary>
		/// <param name="configuration">Configuration to load.</param>
		/// <exception cref="InvalidOperationException">If configuration has already been loaded.</exception>
		/// <exception cref="ArgumentNullException"><c>configuration</c> is <c>null</c>.</exception>
		/// <exception cref="ConfigurationErrorsException">Configuration could not be loaded properly.</exception>
		void LoadConfiguration(TargetConfiguration configuration);

		/// <summary>
		/// Gets or sets target name.
		/// </summary>
		string Name { get; }

		/// <summary>
		/// Gets log entry formatter
		/// </summary>
		IFormatter Formatter { get; }


		/// <summary>
		/// Write a log entry in the target.
		/// </summary>
		/// <param name="logEntry">entry to write</param>
		/// <exception cref="ArgumentNullException"><c>logEntry</c> is <c>null</c>.</exception>
		void Write(LogEntry logEntry);
	}
}