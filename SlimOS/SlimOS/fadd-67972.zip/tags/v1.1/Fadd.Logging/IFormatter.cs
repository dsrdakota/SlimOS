﻿using System;

namespace Fadd.Logging
{
    /// <summary>
    /// A formatter is used to format a log entry.
    /// </summary>
    public interface IFormatter
    {
		/// <summary>
		/// Load configuration.
		/// </summary>
		/// <param name="configuration">Configuration to load.</param>
		/// <exception cref="InvalidOperationException">If configuration has already been loaded.</exception>
		/// <exception cref="ArgumentNullException"><c>configuration</c> is null.</exception>
		void LoadConfiguration(FormatterConfiguration configuration);

        /// <summary>
        /// Gets or sets formatter name.
        /// </summary>
        string Name { get; }

        /// <summary>
        /// Gets or sets log entry format string.
        /// </summary>
        string FormatString { get; }

        /// <summary>
        /// Format a log entry
        /// </summary>
        /// <param name="entry">Entry to format</param>
        /// <returns>String with formatted entry.</returns>
		/// <exception cref="ArgumentNullException"><c>entry</c> is null.</exception>
		string Format(LogEntry entry);

        /// <summary>
        /// Format a date/time entry.
        /// </summary>
        /// <param name="dateTime">Date time to format</param>
        /// <returns>Standardized date format</returns>
		/// <exception cref="ArgumentNullException"><c>dateTime</c> is null.</exception>
		string FormatDateTime(DateTime dateTime);

		/// <summary>
		/// Format a date entry.
		/// </summary>
		/// <param name="dateTime">Date time to format</param>
		/// <returns>Standardized date format</returns>
		/// <exception cref="ArgumentNullException"><c>dateTime</c> is null.</exception>
		string FormatDate(DateTime dateTime);

    }
}
