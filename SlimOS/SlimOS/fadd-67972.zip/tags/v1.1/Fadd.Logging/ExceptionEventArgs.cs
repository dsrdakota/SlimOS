﻿using System;

namespace Fadd.Logging
{
    /// <summary>
    /// Used when logging framework throws an exception.
    /// </summary>
    public class ExceptionEventArgs : EventArgs
    {
        /// <summary>
        /// Gets or sets thrown exception
        /// </summary>
        public Exception Exception { get; set; }
    }
}
