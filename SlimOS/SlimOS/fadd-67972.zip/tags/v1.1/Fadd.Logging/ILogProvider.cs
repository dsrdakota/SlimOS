﻿namespace Fadd.Logging
{
	/// <summary>
	/// Provides loggers.
	/// </summary>
	public interface ILogProvider
	{
		/// <summary>
		/// Get a logger with the specified name.
		/// </summary>
		/// <param name="name">Configured name</param>
		/// <returns><c>null</c> will never be returned, you can always safely use the
		/// returned logger.
		/// </returns>
		ILogger GetLogger(string name);

		/// <summary>
		/// Get logger for current class.
		/// </summary>
		/// <returns><c>null</c> will never be returned, you can always safely use the
		/// returned logger.
		/// </returns>
		ILogger GetCurrentClassLogger();
	}
}