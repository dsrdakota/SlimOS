﻿using System.Collections.Generic;

namespace Fadd.Logging
{
	/// <summary>
	/// Used when namespace matched several loggers.
	/// </summary>
	/// <remarks>
	/// Will scan through all loggers to make sure that each
	/// target only gets one entry.
	/// </remarks>
    class MultiLogger : Logger
    {
		private readonly Dictionary<ITarget, ILogger> _loggerMapping = new Dictionary<ITarget, ILogger>();

		/// <summary>
		/// Initializes a new instance of the <see cref="MultiLogger"/> class.
		/// </summary>
		/// <param name="loggers">All matched loggers.</param>
        public MultiLogger(IEnumerable<ILogger> loggers)
        {
        	foreach (var logger in loggers)
        	{
        		foreach (var target in logger.Targets)
        		{
        			if (ContainsTarget(target)) continue;
        			_loggerMapping.Add(target, logger);
        			AddTarget(target);
        		}
        	}
        }

		/// <summary>
		/// Write entry to all targets
		/// </summary>
		/// <param name="entry">log entry</param>
		/// <param name="targets">targets</param>
		protected override void WriteToTargets(LogEntry entry, IEnumerable<ITarget> targets)
		{
			foreach (var target in targets)
			{
				entry.Logger = _loggerMapping[target];
				target.Write(entry);
			}
		}

        protected override int SkipCount
        {
            get
            {
                return 3;
            }
        }
    }
}
