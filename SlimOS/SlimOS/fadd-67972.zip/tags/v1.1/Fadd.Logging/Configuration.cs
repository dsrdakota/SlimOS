﻿using System;
using System.Collections.Generic;
using System.Xml;

namespace Fadd.Logging
{
	/// <summary>
	/// Complete logging configuration.
	/// </summary>
	public class Configuration
	{
		private readonly List<FormatterConfiguration> _formatters = new List<FormatterConfiguration>();
		private readonly List<LoggerConfiguration> _loggers = new List<LoggerConfiguration>();
		private readonly List<TargetConfiguration> _targets = new List<TargetConfiguration>();

		/// <summary>
		/// Gets a list of all targets
		/// </summary>
		public List<TargetConfiguration> Targets
		{
			get { return _targets; }
		}

		/// <summary>
		/// Gets a list of all loggers
		/// </summary>
		public List<LoggerConfiguration> Loggers
		{
			get { return _loggers; }
		}

		/// <summary>
		/// Gets a list of all formatters.
		/// </summary>
		public List<FormatterConfiguration> Formatters
		{
			get { return _formatters; }
		}
	}

	/// <summary>
	/// Configuration for a <see cref="ITarget"/>.
	/// </summary>
	public class TargetConfiguration
	{
		/// <summary>
		/// Gets or sets name of target type.
		/// </summary>
		public Type TargetType { get; set; }

		/// <summary>
		/// Gets or sets target name.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets name of the <see cref="IFormatter"/> to use.
		/// </summary>
		public string FormatterName { get; set; }

		/// <summary>
		/// Gets or sets child configuration.
		/// </summary>
		/// <remarks>
		/// <para>
		/// Child configuration contains specialized information for 
		/// each implementation of <see cref="ITarget"/>.
		/// </para>
		/// </remarks>
		public XmlNodeList ChildConfiguration { get; set; }
	}

	/// <summary>
	/// Configuration for <see cref="IFormatter"/>.
	/// </summary>
	public class FormatterConfiguration
	{
		/// <summary>
		/// Gets or sets formatter configuration name.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets format.
		/// </summary>
		public string Format { get; set; }

		/// <summary>
		/// Gets or sets formatter type.
		/// </summary>
		public Type Type { get; set; }


		/// <summary>
		/// Gets or sets child configuration.
		/// </summary>
		/// <remarks>
		/// <para>
		/// Child configuration contains specialized information for 
		/// each implementation of <see cref="IFormatter"/>.
		/// </para>
		/// </remarks>
		public XmlNodeList ChildConfiguration { get; set; }
	}
}