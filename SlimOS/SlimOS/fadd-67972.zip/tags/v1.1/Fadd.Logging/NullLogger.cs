﻿using System;
using System.Collections.Generic;

namespace Fadd.Logging
{
    /// <summary>
    /// Used to ignore all log entries.
    /// </summary>
    public class NullLogger : ILogger
    {
    	private string _name = "NullLogger";
    	private string _nameSpace = string.Empty;
    	private readonly IEnumerable<ITarget> _targets = new List<ITarget>();

    	/// <summary>
    	/// Gets minimum log level that can be logged.
    	/// </summary>
    	public LogLevel MinLevel
    	{
			get { return LogLevel.Fatal; }
    	}

    	/// <summary>
    	/// Gets or sets logger name.
    	/// </summary>
    	public string Name
    	{
    		get { return _name; }
    		set { _name = value; }
    	}

    	/// <summary>
    	/// Gets or sets name space to log.
    	/// </summary>
    	public string NameSpace
    	{
    		get { return _nameSpace; }
    		set { _nameSpace = value; }
    	}

    	/// <summary>
    	/// Targets that this logger writes to.
    	/// </summary>
    	public IEnumerable<ITarget> Targets
    	{
    		get { return _targets; }
    	}

    	/// <summary>
        /// Used to be able to trace program execution.
        /// </summary>
        /// <remarks>
        /// Very detailed log messages, potentially of a high frequency and volume
        /// </remarks>
        /// <param name="message">Log message.</param>
        public void Trace(string message)
        {
            
        }

        /// <summary>
        /// Used to be able to trace program execution.
        /// </summary>
        /// <remarks>
        /// Very detailed log messages, potentially of a high frequency and volume
        /// </remarks>
        /// <param name="message">Log message.</param>
        /// <param name="exception">Exception thrown in application.</param>
        public void Trace(string message, Exception exception)
        {
            
        }

        /// <summary>
        /// Entries that are helpful when debugging.
        /// </summary>
        /// <param name="message">Log message.</param>
        public void Debug(string message)
        {
            
        }

        /// <summary>
        /// Entries that are helpful when debugging.
        /// </summary>
        /// <param name="message">Log message.</param>
        /// <param name="exception">Exception thrown in application.</param>
        public void Debug(string message, Exception exception)
        {
            
        }

        /// <summary>
        /// Information that can be helpful during normal program execution.
        /// </summary>
        /// <param name="message">Log message.</param>
        public void Info(string message)
        {
            
        }

        /// <summary>
        /// Information that can be helpful during normal program execution.
        /// </summary>
        /// <param name="message">Log message.</param>
        /// <param name="exception">Exception thrown in application.</param>
        public void Info(string message, Exception exception)
        {
            
        }

        /// <summary>
        /// Something unexpected happened, but program execution can continue as expected.
        /// </summary>
        /// <param name="message">Log message.</param>
        public void Warning(string message)
        {
            
        }

        /// <summary>
        /// Something unexpected happened, but program execution can continue as expected.
        /// </summary>
        /// <param name="message">Log message.</param>
        /// <param name="exception">Exception thrown in application.</param>
        public void Warning(string message, Exception exception)
        {
            
        }

        /// <summary>
        /// Something went really wrong. Program execution cannot continue as expected,
        /// but there is no need to shutdown the program.
        /// </summary>
        /// <param name="message">Log message.</param>
        public void Error(string message)
        {
            
        }

        /// <summary>
        /// Something went really wrong. Program execution cannot continue as expected,
        /// but there is no need to shutdown the program.
        /// </summary>
        /// <param name="message">Log message.</param>
        /// <param name="exception">Exception thrown in application.</param>
        public void Error(string message, Exception exception)
        {
            
        }

        /// <summary>
        /// Major disaster, program ought to be shut down and restarted.
        /// </summary>
        /// <param name="message">Log message.</param>
        public void Fatal(string message)
        {
            
        }

        /// <summary>
        /// Major disaster, program ought to be shut down and restarted.
        /// </summary>
        /// <param name="message">Log message.</param>
        /// <param name="exception">Exception thrown in application.</param>
        public void Fatal(string message, Exception exception)
        {
            
        }

    	/// <summary>
    	/// Load configuration
    	/// </summary>
    	/// <param name="configuration">Configuration to load</param>
    	/// <remarks>
    	/// Can only be invoked during startup.
    	/// </remarks>
    	/// <exception cref="InvalidOperationException">Configuration have already been specified.</exception>
    	/// <exception cref="NotSupportedException"><see cref="NullLogger"/> cannot read a configuration file.</exception>
    	public void LoadConfiguration(LoggerConfiguration configuration)
    	{
    		throw new NotSupportedException("NullLogger cannot read a configuration file.");
    	}

    	/// <summary>
    	/// Determines if this logger can log the specified name space.
    	/// </summary>
    	/// <param name="value">Name space to check</param>
    	/// <returns>true if name space can be logged; otherwise false.</returns>
    	/// <exception cref="NotSupportedException"><see cref="NullLogger"/> should not get a CanLog request.</exception>
    	public bool CanLog(string value)
    	{
    		throw new NotSupportedException("NullLogger should not get a CanLog request.");
    	}
    }
}
