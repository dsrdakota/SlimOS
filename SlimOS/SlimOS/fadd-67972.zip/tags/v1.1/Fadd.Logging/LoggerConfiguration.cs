﻿using System.Collections.Generic;
using System.Xml;

namespace Fadd.Logging
{
    /// <summary>
    /// Configuration for a <see cref="ILogger"/>.
    /// </summary>
    public class LoggerConfiguration
    {
        private string _namespace;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoggerConfiguration"/> class.
        /// </summary>
        public LoggerConfiguration()
        {
            TargetNames = new List<string>();
        }

        /// <summary>
        /// Gets or sets name space for this configuration.
        /// </summary>
        public string Namespace
        {
            get { return _namespace; }
            set
            {
				if (value == "*")
				{
					IsWildCard = true;
					_namespace = string.Empty;
				}
                else if (value.EndsWith(".*"))
                {
                    IsWildCard = true;
					_namespace = value.Remove(value.Length - 2);
                }
                else
                    _namespace = value;
            }
        }

        /// <summary>
        /// Gets or sets whether the name space specification contained a wild card.
        /// </summary>
        public bool IsWildCard { get; private set; }

        /// <summary>
        /// Gets or sets configuration name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets target names.
        /// </summary>
        public ICollection<string> TargetNames { get; private set; }

        /// <summary>
        /// Gets or sets configuration specified for targets etc
        /// </summary>
        public XmlNodeList ChildConfiguration { get; internal set; }

        /// <summary>
        /// Gets or sets minimum log level that can be written
        /// </summary>
        public LogLevel MinLevel { get; set; }

		/// <summary>
		/// All targets for this logger.
		/// </summary>
        public IList<ITarget> Targets
        {
            get; internal set;
        }
    }
}
