﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Xunit;

namespace Fadd.JSON.Test
{
	public class TestObject
	{
		private readonly List<string> _phoneNumbers;

		public TestObject()
		{
			_phoneNumbers = new List<string>();
		}

		public DateTime DOB { get; set; }
		/// <summary>
		/// Gets or sets description.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets Description.
		/// </summary>
		public Address Address { get; set; }

		/// <summary>
		/// Gets or sets whether the object is cool.
		/// </summary>
		public bool IsCool { get; set; }

		/// <summary>
		/// Gets or sets sub items
		/// </summary>
		public int[] Items { get; set; }

		public Address[] Addresses { get; set; }

		/// <summary>
		/// Gets or sets Description.
		/// </summary>
		public object ObjTest { get; set; }

		/// <summary>
		/// Gets or sets Description.
		/// </summary>
		public IEnumerable<string> PhoneNumbers
		{
			get { return _phoneNumbers; }
		}

		public void Add(string phoneNumber)
		{
			_phoneNumbers.Add(phoneNumber);
		}

		[Fact]
		private void Test()
		{
			PropertyInfo prop = GetType().GetProperty("PhoneNumbers");

			Type type = Type.GetType("System.Collections.Generic.ICollection`1[System.String]");
			MethodInfo mi = type.GetMethod("Add");
			MethodInfo[] methodInfos = prop.PropertyType.GetMethods();
		}
	}

	public class Address
	{
		/// <summary>
		/// Gets or sets firstName.
		/// </summary>
		public string Street { get; set; }

		/// <summary>
		/// Gets or sets zip code.
		/// </summary>
		public int ZipCode { get; set; }

		/// <summary>
		/// Gets or sets city.
		/// </summary>
		public string City { get; set; }
	}

	public class PhoneNumber
	{
		/// <summary>
		/// Gets or sets description.
		/// </summary>
		public string Value { get; set; }
	}

}