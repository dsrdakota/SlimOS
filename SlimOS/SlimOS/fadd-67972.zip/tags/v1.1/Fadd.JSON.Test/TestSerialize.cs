﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Xunit;

namespace Fadd.JSON.Test
{

	public class TestSerialize
	{
		[Fact]
		private void Test2()
		{
			Cyclic1 cyclic1 = new Cyclic1 {Cyclic = new Cyclic2(), Value = "hej"};
			cyclic1.Cyclic.Cyclic = cyclic1;
			cyclic1.Cyclic.Value2 = "jeh";
			object cyc2 = SerDeser<Cyclic1>(cyclic1);
		}

		[Fact]
		private void Test()
		{
			var obj = new TestObject
			{
				Name = "Testings",
				IsCool = true,
				Items = new[] { 1, 2, 3, 4 },
				DOB = new DateTime(1976, 8, 27),
				ObjTest = new Address
				{
					City = "hello"
				},
				Addresses = new[]
			          		            	{
			          		            		new Address
			          		            			{
			          		            				City = "Falun1",
			          		            				Street = "HelloStreet",
			          		            				ZipCode = 12435
			          		            			},
			          		            		new Address
			          		            			{
			          		            				City = "Falun2",
			          		            				Street = "HelloStreet",
			          		            				ZipCode = 12435
			          		            			}
			          		            	},
				Address = new Address
				{
					City = "Falun",
					Street = "HelloStreet",
					ZipCode = 12435
				}
			};
			obj.Add("+46-23-12345");
			obj.Add("+46-23-54332");

			object obj2 = SerDeser<TestObject>(obj);
		}

		private object SerDeser<T>(object obj)
		{
			var stream = new MemoryStream();

			var serializer = new Serializer();
			serializer.Serialize(stream, obj);

			stream.Flush();
			stream.Seek(0, SeekOrigin.Begin);
			var reader = new StreamReader(stream);
			string test = reader.ReadToEnd();
			stream.Seek(0, SeekOrigin.Begin);

			var deserializer = new Deserializer();
			return deserializer.Deserialize(stream, typeof(T));
		}
	}
}
