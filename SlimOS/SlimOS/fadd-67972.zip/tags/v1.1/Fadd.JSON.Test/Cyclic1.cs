﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.JSON.Test
{
	public class Cyclic1
	{
		public Cyclic2 Cyclic { get; set; }

		public string Value { get; set; }
	}

	public class Cyclic2
	{
		public Cyclic1 Cyclic { get; set; }
		public string Value2 { get; set; }
	}
}
