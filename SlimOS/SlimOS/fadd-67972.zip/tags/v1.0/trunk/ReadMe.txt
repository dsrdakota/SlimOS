2008-12-28
We've switched from Visual studio 2005 to 2008, although we will still support .Net 2.0.


