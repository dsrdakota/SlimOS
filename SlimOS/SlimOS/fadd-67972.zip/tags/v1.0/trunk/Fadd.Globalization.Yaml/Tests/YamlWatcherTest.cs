#if DEBUG
using System;
using System.IO;
using System.Threading;
using Xunit;

namespace Fadd.Globalization.Yaml.Tests
{
    public class YamlWatcherTest
    {
        /// <summary>Test an incorrect file</summary>
        [Fact]
        public void TestIncorrectFile()
        {
            Assert.Throws(typeof(FileNotFoundException), delegate { using(new YamlWatcher(null, @"c:\doesnotexist")){} });
        }

        [Fact]
        public void MultipleWriteSuccessTest()
        {
            const string filename = "test.yaml";
			File.WriteAllText(filename, @"	1053: Swedish
		TextEntry1: En text.
		TextEntry2: En text2.
		EnSubNod: Subnoden 1
			SubNodTextEntry1: Subnodens textentry1
			EnBuntSubEntriesTill:
				Another: Sub subentry
				And: yet another sub subentry
					And: what do you guess, another one
					Two: More and thats all there is
					Three: More and you'll get yet more
					No: you dont.. really, i mean it");

            LanguageNode rootNode = new MemLanguageNode(1053, "RootNode");
            using (YamlWatcher watcher = new YamlWatcher(rootNode, filename))
            {
                Assert.Equal("En text.", rootNode["TextEntry1"]);
                Assert.Equal("Subnodens textentry1", rootNode.GetChild("EnSubNod")["SubNodTextEntry1"]);

                File.WriteAllText("test.yaml", @"	1053: Swedish
		TextEntry1: En text2.
		TextEntry2: En text1.
		EnSubNod: Subnoden 1
			SubNodTextEntry1: Subnodens textentry1");
                FileStream file = File.Open("test.yaml", FileMode.Append, FileAccess.Write);
                Thread.Sleep(1000);
                file.Close();
                Thread.Sleep(500);
                Assert.Equal("En text2.", rootNode["TextEntry1"]);
            }

			File.Delete(filename);
        }

        [Fact]
        public void CorrectProcedureTest()
        {
            const string filename = "test.yaml";
			File.WriteAllText(filename, @"	1053: Swedish
		TextEntry1: En text.
		TextEntry2: En text2.
		EnSubNod: Subnoden 1
			SubNodTextEntry1: Subnodens textentry1");

            LanguageNode rootNode = new MemLanguageNode(1053, "RootNode");
            using (YamlWatcher watcher = new YamlWatcher(rootNode, filename))
            {
                Assert.Equal("En text.", rootNode["TextEntry1"]);
                Assert.Equal("Subnodens textentry1", rootNode.GetChild("EnSubNod")["SubNodTextEntry1"]);

                Assert.Equal("[SubNodTextEntry2]", rootNode.GetChild("EnSubNod")["SubNodTextEntry2"]);
                File.AppendAllText(filename, Environment.NewLine + "			SubNodTextEntry2: Lite subnodtext.");
                Thread.Sleep(200);
                Assert.Equal("Lite subnodtext.", rootNode.GetChild("EnSubNod")["SubNodTextEntry2"]);

                Assert.Equal("[TextEntry3]", rootNode["TextEntry3"]);
                File.AppendAllText(filename, Environment.NewLine + "		TextEntry3: En text3.");
                Thread.Sleep(200);
                Assert.Equal("En text3.", rootNode["TextEntry3"]);
            }

			File.Delete(filename);
        }

		[Fact]
		public void TestMultipleFiles()
		{
			const string filename = "test.yaml";
			const string filename2 = "test2.yaml";
			const string filename3 = "test3.yaml";
			File.WriteAllText(filename, @"	1053: Swedish
		TextEntry1: En text.
		TextEntry1: En text2.
		EnSubNod: Subnoden 1
			SubNodTextEntry1: Subnodens textentry1
		EnSubNod: Subnoden 2
			SubNodTextEntry1: Subnodens textentry2");
			YamlWatcher watcher1 = new YamlWatcher(new MemLanguageNode(1053, "Test"), filename);

			Assert.Equal("En text2.", watcher1.RootNode["TextEntry1"]);
            Assert.Equal("Subnodens textentry2", watcher1.RootNode.GetChild("EnSubNod")["SubNodTextEntry1"]);

			File.WriteAllText(filename2, @"	1053: Swedish
		TextEntry3: Bit of text
		TextNode: Node1
			TextNodeEntry1: Entry1");
            YamlWatcher watcher2 = new YamlWatcher(watcher1.RootNode, filename2);

            Assert.Equal("Bit of text", watcher1.RootNode["TextEntry3"]);
            Assert.Equal("En text2.", watcher2.RootNode["TextEntry1"]);

			File.WriteAllText(filename2, @"	1053: Swedish
		TextEntry3: Bit of updated text");

			// Give the YamlWatcher some time to notice the updates
			Thread.Sleep(500);

            Assert.Equal("Bit of updated text", watcher1.RootNode["TextEntry3"]);
            Assert.Equal("En text2.", watcher2.RootNode["TextEntry1"]);

			File.WriteAllText(filename3, @"	1053: Swedish		
		Example3: Test");
			Thread.Sleep(250);
            YamlWatcher watcher3 = new YamlWatcher((LanguageNode)watcher1.RootNode.AddChild("SubNodeTest"), filename3);

            Assert.Equal("Test", watcher1.RootNode.GetChild("SubNodeTest")["Example3"]);
            Assert.Equal("Bit of updated text", watcher2.RootNode.GetChild("SubNodeTest")["TextEntry3"]);
			
			File.WriteAllText(filename3, @"	1053: Swedish		
		TextEntry3: Overridden text");

			// Give the YamlWatcher time to update
			Thread.Sleep(500);

            Assert.Equal("Overridden text", watcher1.RootNode.GetChild("SubNodeTest")["TextEntry3"]);
            Assert.Equal("Bit of updated text", watcher2.RootNode["TextEntry3"]);

			watcher1.Dispose();
			watcher2.Dispose();
			watcher3.Dispose();
			File.Delete(filename);
			File.Delete(filename2);
			File.Delete(filename3);
		}

		[Fact]
		public void TestDoubleEntries()
		{
			const string filename = "test.yaml";
			File.WriteAllText(filename, @"	1053: Swedish
		TextEntry1: En text.
		TextEntry1: En text2.
		EnSubNod: Subnoden 1
			SubNodTextEntry1: Subnodens textentry1
		EnSubNod: Subnoden 2
			SubNodTextEntry1: Subnodens textentry2");
			MemLanguageNode language = new MemLanguageNode(1053, "Test");
			YamlWatcher.LoadFile(filename, language);

			Assert.Equal("En text2.", language["TextEntry1"]);
			Assert.Equal("Subnodens textentry2", language.GetChild("EnSubNod")["SubNodTextEntry1"]);

			File.Delete(filename);
		}
    }
}
#endif