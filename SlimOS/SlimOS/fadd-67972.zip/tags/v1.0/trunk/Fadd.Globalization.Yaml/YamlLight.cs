using System.Collections;
using System.Collections.Generic;
using System.IO;
using Xunit;

namespace Fadd.Globalization.Yaml
{
    /// <summary>
    /// An implementation of YAML that only support those things that is needed by the Language loader.
    /// </summary>
    public class YamlLight : IEnumerable<YamlLight>
    {
        private string _name = string.Empty;
        private string _value = string.Empty;
        private readonly LinkedList<YamlLight> _children = new LinkedList<YamlLight>();
        private readonly YamlLight _parent = null;
        private readonly int _intendation = 0;

        public YamlLight(YamlLight parent, int intendation)
        {
            _parent = parent;
            _intendation = intendation;
            if (_parent != null)
                _parent._children.AddLast(this);
        }

        public YamlLight(YamlLight parent, string key, string value)
        {
            _parent = parent;
            _intendation = parent.Intendation+2;
            _name = key;
            _value = value;
            if (_parent != null)
                _parent._children.AddLast(this);
        }

        public int Count
        {
            get { return _children.Count; }
        }
        public int Intendation
        {
            get { return _intendation; }
        }

        public YamlLight Parent
        {
            get { return _parent; }
        }

        public void Add(string key, string value)
        {
            new YamlLight(this, key, value);
        }

        public YamlLight this[string name]
        {
            get
            {
                foreach (YamlLight node in _children)
                {
                    if (node.Name.Equals(name))
                        return node;
                }

                return null;
            }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Value
        {
            get { return _value; }
            set { _value = value; }
        }

        public static YamlLight Parse(TextReader reader)
        {
            YamlLight mother = new YamlLight(null, -1);

            int lineNumber = 0;
            string line = reader.ReadLine();
            YamlLight curNode = mother;
            while (line != null)
            {
                ++lineNumber;
                YamlLight node = HandlePlacement(curNode, line, lineNumber);
                if (node != null)
                {
                    curNode = node;
                    curNode.ParseData(line, curNode.Intendation, ref lineNumber, reader);
                }

                line = reader.ReadLine();
            }

            return mother;
        }

        private static YamlLight HandlePlacement(YamlLight curNode, string line, int lineNumber)
        {
            if (line.Trim() == string.Empty)
                return null;
            int intend = GetIntend(line);
            if (intend == -1)
                throw new InvalidDataException("Invalid intendation on line " + lineNumber);

            YamlLight node;

            // new node is a child to current node
            if (curNode.Intendation < intend)
                node = new YamlLight(curNode, intend);
                // both are chilren to the parent
            else if (curNode.Intendation == intend)
                node = new YamlLight(curNode.Parent, intend);
                // same level as parent or less
            else
            {
                YamlLight parent = curNode.Parent;
                while (parent != null && parent.Intendation > intend)
                    parent = parent.Parent;
                if (parent == null)
                    throw new InvalidDataException("Failed to find parent node on line " + lineNumber);
                node = new YamlLight(parent.Parent, intend);
            }

            return node;
        }

        ///<summary>
        /// Parses a line
        ///</summary>
        ///<param name="line">row in text file</param>
        ///<param name="offset">where to start the parsing (initial white spaces are excluded)</param>
        ///<param name="lineNumber">line number in file</param>
        ///<param name="reader">used if more lines should be read</param>
        ///<exception cref="InvalidDataException"></exception>
        protected void ParseData(string line, int offset, ref int lineNumber, TextReader reader)
        {
            int pos;

            // key is wrapped by quotes
            if (line[offset] == '"')
            {
                ++offset;
                pos = line.IndexOf('"', offset);
                if (pos == -1)
                    throw new InvalidDataException("Failed to find end of qoute for key on line " + lineNumber);
                Name = line.Substring(offset, pos - offset);
                ++pos;
                if (line[pos] !=':')
                    throw new InvalidDataException("Expected ':' after key on line " + lineNumber);
                ++pos;
            }
            else
            {
                pos = line.IndexOf(':', offset);
                if (pos == -1)
                    throw new InvalidDataException("Failed to find value on line " + lineNumber);

                Name = line.Substring(offset, pos - offset);
            }

            if (pos < line.Length - 1)
                Value = ConvertLineBreaks(line.Substring(pos + 1).Trim());

            if (!Value.EndsWith("|")) return;

            Value = ConvertLineBreaks(Value.TrimEnd('|'));

            while((line = reader.ReadLine()) != null)
            {
                lineNumber++;
                Value += ConvertLineBreaks(line.TrimStart('\t').Trim().TrimEnd('|'));

                if(!line.EndsWith("|"))
                    break;
            }
        }
#if TEST
        [Fact]
        private static void TestParseData()
        {
            YamlLight light = new YamlLight(null, 0);
            int lineNumber = 5;
            Stream stream = new MemoryStream();
            TextReader reader = new StreamReader(stream);
            light.ParseData("\t\t\"welcome to\": My place", 2, ref lineNumber, reader);
            light.ParseData("\t\tWelcomeTo: My place", 2, ref lineNumber, reader);
        }
#endif
        private static string ConvertLineBreaks(string line)
        {
            int pos = line.IndexOf("\\n");
            while (pos != -1)
            {
                if (pos < 2)
                    continue;

                // skip \\n (double slashed n)
                line = line[pos - 1] == '\\' 
                    ? line.Remove(pos, 1) 
                    : line.Remove(pos, 2).Insert(pos, "\n");

                pos = line.IndexOf("\\n", pos + 1);
            }

            return line;
        }

        [Fact]
        private static void TestConvertLineBreaks()
        {
            string temp = "Hejsan\\\\nHur m�r du?\\nBra!";
            Assert.Equal("Hejsan\\nHur m�r du?\nBra!", ConvertLineBreaks(temp));
        }

        static int GetIntend(string line)
        {
            for (int i = 0; i < line.Length; ++i)
            {
                if (!char.IsWhiteSpace(line[i]))
                    return i;
            }

            return -1;
        }

        IEnumerator<YamlLight> IEnumerable<YamlLight>.GetEnumerator()
        {
            return _children.GetEnumerator();
        }

        public IEnumerator GetEnumerator()
        {
            return _children.GetEnumerator();
        }
    }
}