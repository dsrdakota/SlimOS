using System;
using System.Collections.Generic;
using System.Text;
using Fadd.Plugins;

namespace ExamplePlugin
{
    class MyPluginInfo : IPluginInfo
    {
        private const string _name = "My Plugin";
        private const string _description = "Demonstrates how to create a plugin system";
        private const string _homepage = "http://www.codeplex.com/fadd";
        private const string _copyright = "(c) Jonas Gauffin";

        /// <summary>
        /// Name of the module, if possible, it should be in the local language.
        /// </summary>
        public string Name
        {
            get { return _name; }
        }

        /// <summary>
        /// Description of what the module does. Shown to the end user.
        /// </summary>
        /// <remarks>
        /// The description may contain links to other pages and images.
        /// Just make sure that your controller can handle them.
        /// Links should be opened in new windows and not leave the market place.
        /// </remarks>
        public string Description
        {
            get { return _description; }
        }

        /// <summary>
        /// Author homepage
        /// </summary>
        public string Homepage
        {
            get { return _homepage; }
        }

        /// <summary>
        /// Copyright owner of this module.
        /// </summary>
        public string Copyright
        {
            get { return _copyright; }
        }
    }
}
