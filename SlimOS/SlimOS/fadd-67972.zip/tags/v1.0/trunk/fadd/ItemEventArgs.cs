using System;

namespace Fadd
{
    /// <summary>
    /// General purpose arguments class for events containing only one item.
    /// </summary>
    /// <typeparam name="T">Type of item</typeparam>
    public class ItemEventArgs<T> : EventArgs
    {
        private T _item;

        /// <summary>
        /// Initializes a new instance of the <see cref="ItemEventArgs&lt;T&gt;"/> class.
        /// </summary>
        /// <param name="item">The item.</param>
        public ItemEventArgs(T item)
        {
            Item = item;
        }

        /// <summary>
        /// Gets or sets the item.
        /// </summary>
        /// <value>The item.</value>
        public T Item
        {
            get { return _item; }
            set { _item = value; }
        }
    }
}
