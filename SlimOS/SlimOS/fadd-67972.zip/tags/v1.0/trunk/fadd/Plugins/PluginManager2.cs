using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Plugins
{
    class PluginManager2<Application>
    {

    }
}
