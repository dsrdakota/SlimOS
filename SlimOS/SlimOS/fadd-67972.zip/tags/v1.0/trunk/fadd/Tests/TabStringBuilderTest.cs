#if TEST
using Xunit;

namespace Fadd.Tests
{
	/// <summary>
	/// Test fixture for testing the <see cref="TabStringBuilder"/>
	/// </summary>
	public class TabStringBuilderTest
	{
		private static void TestAppend()
		{
			string result = @"<div>
	<a href=""#test"">
		<img src=""test.png""/>
	</a>
</div>";

			TabStringBuilder sb = new TabStringBuilder();

			sb.AppendLineInc("<div>");
			sb.Append("<a href=\"");
			sb.Append("#test");
			sb.Append("/>");
			sb.AppendLineInc();
			sb.Append("<img src=\"");
			sb.Append("test.png");
			sb.AppendLine("\"/>");
			sb.AppendLineDec("</a>");
			sb.AppendLineDec("</div>");

			Assert.Equal(result, sb.ToString());
		}

		/// <summary>
		/// Function testing general behaviour
		/// </summary>
		[Fact]
		public void TestAppending()
        {
			TabStringBuilder sb = new TabStringBuilder();

			sb.AppendLineInc("<html>");
			sb.AppendLineInc("<div>");
			sb.AppendLineInc(@"<div id=""another div"">");
			sb.AppendLine("<MyTag/>");
			sb.AppendLineDec("</div>");
			sb.AppendLineDec("</div>");

			Assert.Equal(@"<html>
	<div>
		<div id=""another div"">
			<MyTag/>
		</div>
	</div>
", sb.ToString());

			sb = new TabStringBuilder(sb.StringBuilder, 1);
			sb.AppendLineInc(@"<div id=""continuing div"">");
			sb.AppendLineDec("</div>");
			sb.AppendLineDec("</html>");

			Assert.Equal(@"<html>
	<div>
		<div id=""another div"">
			<MyTag/>
		</div>
	</div>
	<div id=""continuing div"">
	</div>
</html>
", sb.ToString());


			sb = new TabStringBuilder();
			sb.AppendLineInc("<div>");
			sb.Append("<img src=\"");
			sb.Append("myimage.png");
			sb.Append("\"/>");
			sb.AppendLine();
			sb.AppendLineDec("</div>");

			Assert.Equal(@"<div>
	<img src=""myimage.png""/>
</div>
", sb.ToString());
        }
	}
}

#endif
