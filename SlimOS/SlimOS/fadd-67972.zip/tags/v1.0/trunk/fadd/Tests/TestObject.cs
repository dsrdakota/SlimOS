#if TEST
using System.Collections.Generic;
using Fadd.Validation;
using Xunit;

namespace Fadd.Tests
{
    /// <summary>
    /// 
    /// </summary>
    public class TestObject
    {
        private int _mySize;
        private string _password;

        /// <summary>
        /// Gets or sets my size.
        /// </summary>
        /// <value>My size.</value>
        [ValidateMax(20)]
        public int MySize
        {
            get { return _mySize; }
            set { _mySize = value; }
        }

        /// <summary>
        /// Password
        /// </summary>
        [ValidateRequired]
        [ValidateBetween(4, 20)]
        [ValidateLettersAndDigits]
        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }

        [Fact]
        private void TestValidation()
        {
            TestObject obj = new TestObject();

            ObjectValidator validator = ObjectValidator.Create(typeof(TestObject));

            obj.Password = "aba";
            IList<ValidationError> errors = validator.Validate(obj);
            Assert.Equal(2, errors.Count);

            obj.Password = "12345";
            errors = validator.Validate(obj);
            Assert.Equal(1, errors.Count);

            obj.MySize = 1;
            errors = validator.Validate(obj);
            Assert.Equal(0, errors.Count);

            obj.MySize = 40;
            errors = validator.Validate(obj);
            Assert.Equal(1, errors.Count);

        }
    }
}

#endif