#if TEST
using System;

namespace Fadd.Tests
{
    /// <summary>
    /// 
    /// </summary>
    public class PropertyTestObj1
    {
		/// <summary>
		/// Test enumeration to make sure the property setter can handle enums
		/// </summary>
		public enum TestEnumeration
		{
			/// <summary> Test value 1 </summary>
			Value1 = 3,

			/// <summary> Test value 1 </summary>
			Value2 = 4,

			/// <summary> Test value 1 </summary>
			Value3 = 1
		}

    	private bool _boolValue;
        private string _firstName;
        private string _lastName;
        private int _age;
    	private double _ratio;
        private DateTime _createdAt;
        private PropertyTestObj2 _obj2;
    	private TestEnumeration _enumerationValue;

        /// <summary>
        /// Gets or sets the name of the first.
        /// </summary>
        /// <value>The name of the first.</value>
        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }

        /// <summary>
        /// Gets or sets the name of the last.
        /// </summary>
        /// <value>The name of the last.</value>
        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }

		/// <summary>
		/// Set or get a test boolean value
		/// </summary>
    	public bool BoolValue
    	{
			get { return _boolValue; }
			set { _boolValue = value; }
    	}

        /// <summary>
        /// Gets or sets the age.
        /// </summary>
        /// <value>The age.</value>
        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }

    	/// <summary>
    	/// Sets or gets the ratio
    	/// </summary>
    	public double Ratio
    	{
			get { return _ratio; }
			set { _ratio = value; }
    	}

        /// <summary>
        /// Gets or sets the created at.
        /// </summary>
        /// <value>The created at.</value>
        public DateTime CreatedAt
        {
            get { return _createdAt; }
            set { _createdAt = value; }
        }

        /// <summary>
        /// Gets or sets the obj2.
        /// </summary>
        /// <value>The obj2.</value>
        public PropertyTestObj2 Obj2
        {
            get { return _obj2; }
            set { _obj2 = value; }
        }

		/// <summary>
		/// Gets or sets an enumeration value
		/// </summary>
    	public TestEnumeration EnumerationValue
    	{
			get { return _enumerationValue; }
			set { _enumerationValue = value; }
    	}
    }
}
#endif