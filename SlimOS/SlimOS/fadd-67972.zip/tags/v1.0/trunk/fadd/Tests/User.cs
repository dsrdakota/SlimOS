#if TEST
using System;

namespace Fadd.Tests
{
    /// <summary>
    /// User for testing purposes
    /// </summary>
    public class User
    {
        private string _userName;
        private int _id;
        private string _firstName;
        private DateTime _createdAt;

        /// <summary>
        /// User NAME
        /// </summary>
        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        /// <summary>
        /// Database ID
        /// </summary>
        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        /// <summary>
        /// First, and not last, Name
        /// </summary>
        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }

        /// <summary>
        /// When the user was created.
        /// </summary>
        public DateTime CreatedAt
        {
            get { return _createdAt; }
            set { _createdAt = value; }
        }
    }
}
#endif