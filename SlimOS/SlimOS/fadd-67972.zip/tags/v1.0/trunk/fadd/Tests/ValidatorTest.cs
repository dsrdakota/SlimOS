#if TEST
using System;
using System.Collections.Specialized;
using System.Globalization;
using System.Threading;
using Xunit;
#pragma warning disable 1591

namespace Fadd.Tests
{
    public class ValidatorTest
    {
        private readonly NameValueCollection _errors;
        private readonly Validator _v;


        public ValidatorTest()
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            _errors = new NameValueCollection();
            _v = new Validator(_errors);
        }

        [Fact]
        public void TestDouble()
        {
            Assert.Equal<double>(0, _v.Double("Test", "bajs", true));
            Assert.Equal(1, _errors.Count);
            _errors.Clear();

            Assert.Equal(1.1d, _v.Double("Test", "1.1", true));
            Assert.Equal(0, _errors.Count);
            _errors.Clear();

            Assert.Equal(0.0d, _v.Double("Test", "0.0", true));
            Assert.Equal(0, _errors.Count);
            _errors.Clear();

            Assert.Equal(0d, _v.Double("Test", "", true));
            Assert.Equal(1, _errors.Count);
            _errors.Clear();

            Assert.Equal<double>(0, _v.Double("Test", "", false));
            Assert.Equal(0, _errors.Count);
            _errors.Clear();

            Assert.Equal<double>(0, _v.Double("Test", "474.22.444", false));
            Assert.Equal(1, _errors.Count);
            _errors.Clear();
        }

        [Fact]
        public void TestInteger()
        {
            Assert.Equal(0, _v.Integer("Test", "bajs", true));
            Assert.Equal(1, _errors.Count);
            _errors.Clear();

            Assert.Equal(1, _v.Integer("Test", "1", true));
            Assert.Equal(0, _errors.Count);
            _errors.Clear();

            Assert.Equal(0, _v.Integer("Test", "0", true));
            Assert.Equal(0, _errors.Count);
            _errors.Clear();

            Assert.Equal(0, _v.Integer("Test", "", true));
            Assert.Equal(1, _errors.Count);
            _errors.Clear();

            Assert.Equal(0, _v.Integer("Test", "", false));
            Assert.Equal(0, _errors.Count);
            _errors.Clear();

            Assert.Equal(0, _v.Integer("Test", "474.22", false));
            Assert.Equal(1, _errors.Count);
            _errors.Clear();
        }

        [Fact]
        public void TestEmail()
        {
            Assert.Equal("something@a.domain.somwhere.se", _v.Email("Test", "something@a.domain.somwhere.se", true));
            Assert.Equal(0, _errors.Count);
            _errors.Clear();

            Assert.Equal(string.Empty, _v.Email("Test", "arne�21@ddj.se", true));
            Assert.Equal(1, _errors.Count);
            _errors.Clear();

            Assert.Equal("ddjd.ddd@ddj.se", _v.Email("Test", "ddjd.ddd@ddj.se", true));
            Assert.Equal(0, _errors.Count);
            _errors.Clear();

        }

		[Fact]
		public void TestBetween()
		{
			Assert.Equal(15.3, _v.Between("Test", "15.3", 12.0, 16.0, true));
			Assert.Equal(15, _v.Between("Test", "15", 12, 16, true));
			Assert.Equal(14.3, _v.Between("Test", "14,3", 13.0, 15.0, true));
			Assert.Equal(0, _errors.Count);

			Assert.Throws<ArgumentException>(delegate { _v.Between("Test", "14.3", 15.0, 13.0, true); });

			Assert.Equal(0.0, _v.Between("Test", "15.3", 12.0, 13.0, true));
			Assert.Equal(0.0, _v.Between("Test2", "15.3", 16.0, 18.0, true));
			Assert.Equal(2, _errors.Count);
			_errors.Clear();
		}
    }
}
#endif