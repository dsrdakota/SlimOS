#if TEST
using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Tests
{
    /// <summary>
    /// used for testing
    /// </summary>
    public interface IPropertyTestObj2
    {
        /// <summary>
        /// Gets or sets something.
        /// </summary>
        /// <value>Something.</value>
        int Something { get; set; }

        /// <summary>
        /// Gets the generic property.
        /// </summary>
        /// <value>The generic property.</value>
        IList<string> GenericProperty { get; }

        /// <summary>
        /// Gets an indexed string
        /// </summary>
        /// <param name="indexedParameter">Index</param>
        string this[int indexedParameter] { get;}
    }

    /// <summary>
    /// 
    /// </summary>
    public class PropertyTestObj2 : IPropertyTestObj2
    {
        private int _something;
        private Queue _queue;

        /// <summary>
        /// Gets or sets something.
        /// </summary>
        /// <value>Something.</value>
        public int Something
        {
            get { return _something; }
            set { _something = value; }
        }

        /// <summary>
        /// Gets the generic property.
        /// </summary>
        /// <value>The generic property.</value>
        public IList<string> GenericProperty
        {
            get { return new List<string>();}
        }

        /// <summary>
        /// Gets an indexed string
        /// </summary>
        /// <param name="indexedParameter">Index</param>
        public string this[int indexedParameter]
        {
            get { return "a value"; }
        }

        public Queue Queue
        {
            get { return _queue; }
            set { _queue = value; }
        }
    }

    public class Queue
    {
        private string _test;

        public string Test
        {
            get { return _test; }
            set { _test = value; }
        }
    }

}
#endif