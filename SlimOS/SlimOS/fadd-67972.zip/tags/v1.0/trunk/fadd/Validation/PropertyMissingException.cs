using System;

namespace Fadd.Validation
{
    /// <summary>
    /// thrown when the specified property is not found in the specified class.
    /// </summary>
    public class MissingPropertyException : ArgumentException
    {
        private string _propertyName;
        private string _className;

        /// <summary>
        /// Initializes a new instance of the <see cref="MissingPropertyException"/> class.
        /// </summary>
        /// <param name="className">Name of the class.</param>
        /// <param name="propertyName">Name of the property.</param>
        public MissingPropertyException(string className, string propertyName)
        {
            _className = className;
            _propertyName = propertyName;
        }
    }
}
