using System;
using Fadd.Globalization;

#if TEST
using Xunit;
#endif

namespace Fadd.Validation
{
    /// <summary>
    /// Specifies a max length.
    /// </summary>
    /// <remarks>
    /// On a string it specified maximum number of letters, while on int it specifies the max number.
    /// </remarks>
    /// <para>
    /// Language file items:
    /// <list type="table">
    ///     <listheader>
    ///         <term>ItemName</term>
    ///         <description>Language text</description>
    ///     </listheader>
    ///     <item>
    ///         <term>AlphaNumeric</term>
    ///         <description>'{0}' may only contain alpha numeric letters.</description>
    ///     </item>
    /// </list>
    /// </para>
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Property | AttributeTargets.Parameter)]
    public class ValidateMinAttribute : ValidateAttribute
    {
        private readonly object _value;

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateMaxAttribute"/> class.
        /// </summary>
        /// <param name="value">minimum length. should match the type being validated, with the exception of string
        /// where the type should be int.</param>
        public ValidateMinAttribute(object value)
        {
            _value = value;
        }

        /// <summary>
        /// Minimum length
        /// </summary>
        public object Value
        {
            get { return _value; }
        }


        /// <summary>
        /// Validate value
        /// </summary>
        /// <param name="context">Can be used to send a context object to the validation class. Useful if you provide your own validation classes which need to get information from your application. <seealso cref="BeforeValidationEventArgs"/></param>
        /// <param name="value">value to validate</param>
        /// <returns>
        /// true if value passed the validation; otherwise false.
        /// </returns>
        public override bool Validate(object context, object value)
        {
            if (IsEmpty(value))
                return true;

            if (value is string)
            {
                string s = (string)value;
                return s.Length >= (int)_value;
            }

            IComparable comparable = value as IComparable;
            if (comparable != null)
                return comparable.CompareTo(_value) >= 0;


            throw new NotSupportedException(GetType() + " do not support " + value.GetType());
        }

        /// <summary>
        /// Localize error if validation failed.
        /// </summary>
        /// <param name="fieldName">Localized field name.</param>
        /// <param name="validationLanguage">Language node with all validation translations.</param>
        /// <returns>A localized error message if the validation failed; otherwise null.</returns>
        /// <example>
        /// <code>
        /// attribute.Localize("FirstName", "'{0}' is required"); 
        /// // will return "'{0}' is required" if the validation failed, else null.
        /// </code>
        /// </example>
        public override string Format(string fieldName, ILanguageNode validationLanguage)
        {
            return string.Format(validationLanguage["Min"], fieldName);
        }

        /// <summary>
        /// Determines if the validation class support the specified type.
        /// </summary>
        /// <param name="type">Property/Value type.</param>
        /// <returns>true if the type is supported.</returns>
        public override bool SupportsType(Type type)
        {
            return type.GetInterface("IComparable", false) != null;
        }

#if TEST
        [Fact]
        private static void TestValidate()
        {
            ValidateMinAttribute attribute = new ValidateMinAttribute(10);
            Assert.False(attribute.Validate(null, 1));
            Assert.False(attribute.Validate(null, 6));
            Assert.False(attribute.Validate(null, "Tjena"));
            Assert.True(attribute.Validate(null, 11));
            Assert.True(attribute.Validate(null, "Hejsan alla barn!"));

            attribute = new ValidateMinAttribute(10.0);
            Assert.False(attribute.Validate(null, 6.0));
            Assert.True(attribute.Validate(null, 10.1));
        
        }
#endif

    }
}
