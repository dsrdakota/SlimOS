using System;
using Fadd.Globalization;
#if TEST
using Xunit;
#endif

namespace Fadd.Validation
{
    /// <summary>
    /// Input may only be letters and digits, foreign chars (for instance ���) etc are included.
    /// </summary>
    /// <para>
    /// Language file items:
    /// <list type="table">
    ///     <listheader>
    ///         <term>ItemName</term>
    ///         <description>Language text</description>
    ///     </listheader>
    ///     <item>
    ///         <term>LettersAndDigits</term>
    ///         <description>'{0}' may only contain letters and digits.</description>
    ///     </item>
    ///     <item>
    ///         <term>LettersAndDigitsExtra</term>
    ///         <description>'{0}' may only contain letters. digits and '{1}'.</description>
    ///     </item>
    /// </list>
    /// </para>
    public class ValidateLettersAndDigitsAttribute : ValidateAttribute
    {
        private readonly string _extraCharacters;

        /// <summary>
        /// Foreign characters (letters used for instance in the Swedish language)
        /// </summary>
        public const string ForeignCharacters = "���������������������������������������������";

        /// <summary>
        /// Foreign characters (letters used for instance in the Swedish language) and space, dot and comma.
        /// </summary>
        public const string ForeignCharactersSDC = "��������������������������������������������� .,";

        /// <summary>
        /// Space, dot and comma.
        /// </summary>
        public const string SDC = " .,";

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateLettersAndDigitsAttribute"/> class.
        /// </summary>
        public ValidateLettersAndDigitsAttribute() : this(string.Empty)
        {
            _extraCharacters = ForeignCharacters;
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateLettersAndDigitsAttribute"/> class.
        /// </summary>
        /// <param name="extraCharacters">The extra characters.</param>
        public ValidateLettersAndDigitsAttribute(string extraCharacters)
        {
            Check.Require(extraCharacters, "extraCharacters");
            _extraCharacters = extraCharacters + ForeignCharacters;
        }

        /// <summary>
        /// Gets the extra characters.
        /// </summary>
        /// <value>The extra characters.</value>
        public string ExtraCharacters
        {
            get { return _extraCharacters; }
        }


        /// <summary>
        /// Validate value
        /// </summary>
        /// <param name="context">Can be used to send a context object to the validation class. Useful if you provide your own validation classes which need to get information from your application. <seealso cref="BeforeValidationEventArgs"/></param>
        /// <param name="value">value to validate</param>
        /// <returns>
        /// true if value passed the validation; otherwise false.
        /// </returns>
        /// <exception cref="NotSupportedException">Only strings are valid for this type.</exception>
        public override bool Validate(object context, object value)
        {
            if (IsEmpty(value))
                return true;

            if (!(value is string))
                throw new NotSupportedException("Only strings are valid for this type.");

            string valueStr = (string) value;
            foreach (char ch in valueStr)
            {
                if (char.IsLetterOrDigit(ch) || _extraCharacters.IndexOf(ch) != -1)
                    continue;

                return false;
            }

            return true;
        }

        /// <summary>
        /// Localize error if validation failed.
        /// </summary>
        /// <param name="fieldName">Localized field name.</param>
        /// <param name="validationLanguage">Language node with all validation translations.</param>
        /// <returns>A localized error message if the validation failed; otherwise null.</returns>
        /// <example>
        /// <code>
        /// attribute.Localize("FirstName", "'{0}' is required"); 
        /// // will return "'{0}' is required" if the validation failed, else null.
        /// </code>
        /// </example>
        public override string Format(string fieldName, ILanguageNode validationLanguage)
        {
            return _extraCharacters != null
                       ? string.Format(validationLanguage["LettersAndDigits"], fieldName)
                       : string.Format(validationLanguage["LettersAndDigitsExtra"], fieldName);
        }

        /// <summary>
        /// Determines if the validation support the specified type.
        /// </summary>
        /// <param name="type">Property/Value type.</param>
        /// <returns>true if type is supported.</returns>
        /// <remarks>
        /// Used when validation objects are generated.
        /// </remarks>
        public override bool SupportsType(Type type)
        {
            return type == typeof (string);
        }

#if TEST
        [Fact]
        private static void Test()
        {
            ValidateLettersAndDigitsAttribute a = new ValidateLettersAndDigitsAttribute();
            Assert.True(a.Validate(null, "1234567890qwertyuiop�asdfghjkl��zxcvbnmQWERTYUIOP�ASDFGHJKL��ZXCVBNM"));
            foreach (char ch in "!\"#�%&/()=?`)�'-.,<>;:_*^|~\\}][{�$�@")
                Assert.False(a.Validate(null, string.Empty + ch), "" + ch);

            a = new ValidateLettersAndDigitsAttribute("#�");
            Assert.True(a.Validate(null, "#djddhhd�"));
            foreach (char ch in "!\"%&/()=?`)�'-.,<>;:_*^|~\\}][{�$�@")
                Assert.False(a.Validate(null, string.Empty + ch), "" + ch);

        }
#endif

    }
}
