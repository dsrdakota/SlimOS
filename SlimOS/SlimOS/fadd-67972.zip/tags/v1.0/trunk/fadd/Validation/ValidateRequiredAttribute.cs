using System;
using Fadd.Globalization;
#if TEST
using Xunit;
#endif

namespace Fadd.Validation
{
    /// <summary>
    /// Checks whether a field have been specified or not.
    /// </summary>
    /// <para>
    /// Language file items:
    /// <list type="table">
    ///     <listheader>
    ///         <term>ItemName</term>
    ///         <description>Language text</description>
    ///     </listheader>
    ///     <item>
    ///         <term>AlphaNumeric</term>
    ///         <description>'{0}' may only contain alpha numeric letters.</description>
    ///     </item>
    /// </list>
    /// </para>
    public class ValidateRequiredAttribute : ValidateAttribute
    {
        private readonly object _emptyValue;

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateRequiredAttribute"/> class.
        /// </summary>
        public ValidateRequiredAttribute()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateRequiredAttribute"/> class.
        /// </summary>
        /// <param name="emptyValue">value is considered to be not specified if the value matches this parameter.</param>
        public ValidateRequiredAttribute(object emptyValue)
        {
            _emptyValue = emptyValue;
        }

        /// <summary>
        /// Validate value
        /// </summary>
        /// <param name="context">Can be used to send a context object to the validation class. Useful if you provide your own validation classes which need to get information from your application. <seealso cref="BeforeValidationEventArgs"/></param>
        /// <param name="value">value to validate</param>
        /// <returns>
        /// true if value passed the validation; otherwise false.
        /// </returns>
        public override bool Validate(object context, object value)
        {
            return !IsEmpty(value, _emptyValue);
        }

        /// <summary>
        /// Determines if the validation support the specified type.
        /// </summary>
        /// <param name="type">Property/Value type.</param>
        /// <returns>true if type is supported.</returns>
        /// <remarks>
        /// Used when validation objects are generated.
        /// </remarks>
        public override bool SupportsType(Type type)
        {
            return true;
        }

#if TEST
        [Fact]
        private static void TestValidate()
        {
            ValidateRequiredAttribute attribute = new ValidateRequiredAttribute(5);
            Assert.True(attribute.Validate(null, 1));
            Assert.False(attribute.Validate(null, 5));
            Assert.False(attribute.Validate(null, null));

            attribute = new ValidateRequiredAttribute(true);
            Assert.True(attribute.Validate(null, 1));
            Assert.False(attribute.Validate(null, 0.0));
            Assert.False(attribute.Validate(null, null));
            Assert.False(attribute.Validate(null, 0));


            attribute = new ValidateRequiredAttribute(true);
            Assert.True(attribute.Validate(null, "hej"));
            attribute = new ValidateRequiredAttribute("hej");
            Assert.False(attribute.Validate(null, "hej"));
        }
#endif

        /// <summary>
        /// Localize error if validation failed.
        /// </summary>
        /// <param name="fieldName">Localized field name.</param>
        /// <param name="validationLanguage">Language node with all validation translations.</param>
        /// <returns>A localized error message if the validation failed; otherwise null.</returns>
        /// <example>
        /// <code>
        /// attribute.Localize("FirstName", "'{0}' is required"); 
        /// // will return "'{0}' is required" if the validation failed, else null.
        /// </code>
        /// </example>
        public override string Format(string fieldName, ILanguageNode validationLanguage)
        {
            return string.Format(validationLanguage["Required"], fieldName);
        }
    }
}
