namespace Fadd.Validation
{
    /// <summary>
    /// An validation error.
    /// </summary>
    public class ValidationError
    {
        private readonly string _name;
        private readonly ValidateAttribute _attribute;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name">Property/Argument that validation failed for.</param>
        /// <param name="attribute">Kind of validation that failed.</param>
        public ValidationError(string name, ValidateAttribute attribute)
        {
            Check.NotEmpty(name, "name");
            Check.Require(attribute, "attribute");
            _name = name;
            _attribute = attribute;
        }

        /// <summary>
        /// Property/Argument that validation failed for
        /// </summary>
        public string Name
        {
            get { return _name; }
        }

        /// <summary>
        /// Kind of validation that failed
        /// </summary>
        public ValidateAttribute Attribute
        {
            get { return _attribute; }
        }
    }
}
