using Fadd.Globalization;
#if TEST
using Xunit;
#endif

namespace Fadd.Validation
{
    /// <summary>
    /// Validates that a string only contains letter, digits and any of: <![CDATA['"\<>|-_.:,;'^~�'*!#�%&/()=?`�+}][{�$��@�� ]]>
    /// </summary>
    /// <remarks>
    /// <para>
    /// Language file items:
    /// <list type="table">
    ///     <listheader>
    ///         <term>ItemName</term>
    ///         <description>Language text</description>
    ///     </listheader>
    ///     <item>
    ///         <term>AlphaNumeric</term>
    ///         <description>'{0}' may only contain alpha numeric letters.</description>
    ///     </item>
    /// </list>
    /// </para>
    /// </remarks>
    public class ValidateAlphaNumericAttribute : ValidateLettersAndDigitsAttribute
    {
        private const string ValidChars = "'\"\\<>|-_.:,;'^~�'*!#�%&/()=?`�+}][{�$��@�� ";
        private const string Message = "'{0}' may only contain alpha numeric letters.";

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateAlphaNumericAttribute"/> class.
        /// </summary>
        public ValidateAlphaNumericAttribute()
            : this(ValidChars)
        {
            
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateAlphaNumericAttribute"/> class.
        /// </summary>
        /// <param name="extraCharacters">The extra characters.</param>
        public ValidateAlphaNumericAttribute(string extraCharacters)
            : base(extraCharacters + ValidChars)
        {
        }

        /// <summary>
        /// Localize error if validation failed.
        /// </summary>
        /// <param name="fieldName">Localized field name.</param>
        /// <param name="validationLanguage">Language node with all validation translations.</param>
        /// <returns>A localized error message if the validation failed; otherwise null.</returns>
        /// <example>
        /// <code>
        /// attribute.Localize("FirstName", "'{0}' is required"); 
        /// // will return "'{0}' is required" if the validation failed, else null.
        /// </code>
        /// </example>
        public override string Format(string fieldName, ILanguageNode validationLanguage)
        {
            string format = validationLanguage == null ? Message : validationLanguage["AlphaNumeric"];
            return string.Format(format, fieldName);
        }

#if TEST
        [Fact]
        private static void Test()
        {
            ValidateAlphaNumericAttribute v = new ValidateAlphaNumericAttribute("\x5");
            Assert.True(v.Validate(null, "Hello�%&/ \x5"));
            Assert.False(v.Validate(null, "\x6"));

            v = new ValidateAlphaNumericAttribute();
            Assert.True(v.Validate(null, "Hello�%&/ "));
            Assert.False(v.Validate(null, "\x6"));

            MemLanguageNode node = new MemLanguageNode(1033, "hej");
            node.Add("AlphaNumeric", 1033, "{0}!");
            Assert.Equal("Hej!", v.Format("Hej", node));
            Assert.Equal(string.Format(Message, "Hej"), v.Format("Hej", null));
        }
#endif
    }
}
