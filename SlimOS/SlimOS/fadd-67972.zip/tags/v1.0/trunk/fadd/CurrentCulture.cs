﻿using System.Threading;

namespace Fadd
{
	/// <summary>
	/// Class to provide transparent retrieval of LCID for silverlight and normal .Net projects
	/// </summary>
	public static class CurrentCulture
	{
		/// <summary>
		/// Gets the LCID for the current thread
		/// </summary>
		public static int LCID
		{
			get
			{
				// The preprocessor below allows us to have another implementation for the method if its compiled for silverlight
#if SILVERLIGHT
				// Add more cultures in the format below
				//if(Thread.CurrentThread.CurrentCulture.Name == "")
				//	return theLcidForThatLanguage;

				// Default to swedish
				return 1053;
#else
				return Thread.CurrentThread.CurrentCulture.LCID;
#endif
			}
		}
	}
}
