namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// ORDER BY SQL Clause.
    /// </summary>
    public class OrderBy : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.OrderBy; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>" ORDER BY "</returns>
        public override string ToString()
        {
            return " ORDER BY ";
        }
    }
}
