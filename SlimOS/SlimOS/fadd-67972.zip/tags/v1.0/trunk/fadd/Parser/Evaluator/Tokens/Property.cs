namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// A property name
    /// </summary>
    public class Property : Token
    {
        private readonly string _name;

        /// <summary>
        /// Initializes a new instance of the <see cref="Property"/> class.
        /// </summary>
        /// <param name="name">Name of property.</param>
        public Property(string name)
        {
            _name = name;
        }

        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return EvaluatorTokenIds.Property; }
        }

        /// <summary>
        /// Name of property
        /// </summary>
        public string Name
        {
            get { return _name; }
        }

        /// <summary>
        /// Returns name of property
        /// </summary>
        /// <returns>name of property</returns>
        public override string ToString()
        {
            return _name;
        }
    }
}
