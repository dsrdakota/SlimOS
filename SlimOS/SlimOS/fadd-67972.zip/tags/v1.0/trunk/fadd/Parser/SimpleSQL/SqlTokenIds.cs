namespace Fadd.Parser.SimpleSQL
{
    /// <summary>
    /// All tokens used during parsing
    /// </summary>
    static class SqlTokenIds
    {
        public const int Context = 14;
        public const int Property = 1;

        /// <summary>
        /// AND
        /// </summary>
        public const int And = 2;

        /// <summary>
        /// OR
        /// </summary>
        public const int Or = 3;

        /// <summary>
        /// IN ( XXX )
        /// </summary>
        public const int In = 4;

        /// <summary>
        /// (
        /// </summary>
        public const int StartNesting = 5;

        /// <summary>
        /// )
        /// </summary>
        public const int EndNesting = 6;

        public const int LessThan = 7;
        public const int LessOrEqual = 8;
        public const int Equal = 9;
        public const int NotEqual = 10;
        public const int MoreThan = 11;
        public const int MoreOrEqual = 12;
        public const int PropertyValue = 13;
        public const int Select = 14;
        public const int Where = 15;
        public const int GroupBy = 16;
        public const int Having = 17;
        public const int OrderBy = 18;
        public const int OrderByProperty = 19;
        public const int From = 20;
        public const int Class = 21;
        public const int Comma = 22;
        public const int Like = 23;
        public const int Insert = 24;
        public const int Delete = 25;
        public const int Update = 26;
        public const int Set = 27;
        public const int Bitwise = 28;
        public const int Count = 29;
    }
}
