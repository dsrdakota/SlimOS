namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// LIKE keyword
    /// </summary>
    public class Like : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.Like; }
        }

        /// <summary>
        /// Conditional string
        /// </summary>
        /// <returns>" LIKE "</returns>
        public override string ToString()
        {
            return " LIKE ";
        }
    }
}
