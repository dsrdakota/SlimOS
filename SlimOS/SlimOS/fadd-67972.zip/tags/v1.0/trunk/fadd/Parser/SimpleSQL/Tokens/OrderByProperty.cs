namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// Name of the property to sort by, and if the sort is ascending/descending.
    /// </summary>
    public class OrderByProperty : Token
    {
        private Property _property;
        private string _name;
        private bool _ascending;

        /// <summary>
        /// Initializes a new instance of the <see cref="OrderByProperty"/> class.
        /// </summary>
        /// <param name="name">Name of the property.</param>
        /// <param name="ascending">if set to <c>true</c> sort is ascending.</param>
        public OrderByProperty(string name, bool ascending)
        {
            Check.NotEmpty(name, "name");

            Name = name;
            _ascending = ascending;
        }

        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.OrderByProperty; }
        }

        /// <summary>
        /// Property that the order by is for
        /// </summary>
        public Property Property
        {
            get { return _property; }
            set { _property = value; }
        }

        /// <summary>
        /// Ascending or Descending sort
        /// </summary>
        public bool Ascending
        {
            get { return _ascending; }
            set { _ascending = value; }
        }

        /// <summary>
        /// Name of the property.
        /// </summary>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>Order by property</returns>
        public override string ToString()
        {
            if (Ascending)
                return " " + Name;
            return " " + Name + " DESC";
        }
    }
}
