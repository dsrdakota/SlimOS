namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// >
    /// </summary>
    class MoreThan : Token, IConditional
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return EvaluatorTokenIds.MoreThan; }
        }

        public override string ToString()
        {
            return " > ";
        }
    }
}
