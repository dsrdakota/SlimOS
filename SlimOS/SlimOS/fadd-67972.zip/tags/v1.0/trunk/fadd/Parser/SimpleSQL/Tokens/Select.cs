namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// SELECT clause
    /// </summary>
    public class Select : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.Select; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>"SELECT "</returns>
        public override string ToString()
        {
            return "SELECT ";
        }
    }
}
