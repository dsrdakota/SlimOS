using Fadd.Parser;
using Fadd.Parser.SimpleSQL;

namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// Not equal condition
    /// </summary>
    public class NotEqual : Token, IConditional
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.NotEqual; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>" &lt;&gt; "</returns>
        public override string ToString()
        {
            return " <> ";
        }
    }
}
