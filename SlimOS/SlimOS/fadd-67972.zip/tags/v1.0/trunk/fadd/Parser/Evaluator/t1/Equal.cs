namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// =
    /// </summary>
    public class Equal : Token, IConditional
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return EvaluatorTokenIds.Equal; }
        }

        public override string ToString()
        {
            return " == ";
        }
    }
}
