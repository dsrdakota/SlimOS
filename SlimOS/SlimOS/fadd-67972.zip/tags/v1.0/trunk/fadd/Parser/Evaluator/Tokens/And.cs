namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// <![CDATA[&&]]>
    /// </summary>
    public class And : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return EvaluatorTokenIds.And; }
        }

		/// <summary>
		/// Returns &amp;&amp;.
		/// </summary>
		/// <returns>" &amp;&amp; "</returns>
        public override string ToString()
        {
            return " && ";
        }
    }
}
