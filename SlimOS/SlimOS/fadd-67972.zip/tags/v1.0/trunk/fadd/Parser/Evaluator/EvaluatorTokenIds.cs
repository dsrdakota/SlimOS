namespace Fadd.Parser.Evaluator
{
    /// <summary>
    /// All tokens used during parsing
    /// </summary>
    static class EvaluatorTokenIds
    {
        public const int Context = 14;
        public const int Property = 1;

        /// <summary>
        /// AND
        /// </summary>
        public const int And = 2;

        /// <summary>
        /// OR
        /// </summary>
        public const int Or = 3;

        /// <summary>
        /// IN ( XXX )
        /// </summary>
        public const int In = 4;

        /// <summary>
        /// (
        /// </summary>
        public const int StartNesting = 5;

        /// <summary>
        /// )
        /// </summary>
        public const int EndNesting = 6;

        public const int LessThan = 7;
        public const int LessOrEqual = 8;
        public const int Equal = 9;
        public const int NotEqual = 10;
        public const int MoreThan = 11;
        public const int MoreOrEqual = 12;
        public const int PropertyValue = 13;
    }
}
