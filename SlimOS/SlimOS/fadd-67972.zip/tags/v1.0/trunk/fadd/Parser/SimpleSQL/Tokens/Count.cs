namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// COUNT(*) SQL clause
    /// </summary>
    public class Count : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.Count; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>" COUNT(*) "</returns>
        public override string ToString()
        {
            return " COUNT(*) ";
        }
    }
}
