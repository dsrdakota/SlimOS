namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// A IN clause.
    /// </summary>
    public class In : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        public override int TokenIdentifier
        {
            get { return EvaluatorTokenIds.In; }
        }
    }
}
