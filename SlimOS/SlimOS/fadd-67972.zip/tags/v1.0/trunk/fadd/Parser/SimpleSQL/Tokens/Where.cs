using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// WHERE clause
    /// </summary>
    public class Where : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.Where; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>" WHERE "</returns>
        public override string ToString()
        {
            return " WHERE ";
        }
    }
}
