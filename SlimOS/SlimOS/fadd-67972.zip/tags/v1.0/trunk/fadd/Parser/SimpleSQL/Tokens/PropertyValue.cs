namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// Contains a value in a condition.
    /// </summary>
    public class PropertyValue : Token, IConditional
    {
        private readonly Property _property;
        private string _name;

        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyValue"/> class.
        /// </summary>
        /// <param name="property">Property that this value belongs to.</param>
        public PropertyValue(Property property)
        {
            _property = property;
        }

        /// <summary>
        /// Identifier for this token.
        /// </summary>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.PropertyValue; }
        }

        /// <summary>
        /// Property that this token belongs to.
        /// </summary>
        public Property Property
        {
            get { return _property; }
        }

        /// <summary>
        /// Name of the parameter.
        /// </summary>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }


        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>@[propertyName]</returns>
        public override string ToString()
        {
            return _name ?? "@" + (_property == null ? "unknownParameter" : _property.Name);
        }
    }
}
