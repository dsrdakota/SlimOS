namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// OR condition ("||" in C#)
    /// </summary>
    public class Or : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return EvaluatorTokenIds.Or; }
        }

		/// <summary>
		/// OR condition as string
		/// </summary>
		/// <returns>" || "</returns>
        public override string ToString()
        {
            return " || ";
        }
    }
}
