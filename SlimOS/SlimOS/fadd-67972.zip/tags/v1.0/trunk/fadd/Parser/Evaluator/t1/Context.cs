namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// We are getting into a sub context (nested conditions)
    /// </summary>
    public class Context : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return EvaluatorTokenIds.Context; }
        }
    }
}
