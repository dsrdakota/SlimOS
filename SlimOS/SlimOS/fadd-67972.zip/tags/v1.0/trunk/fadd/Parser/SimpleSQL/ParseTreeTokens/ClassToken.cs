using Fadd.Parser.SimpleSQL.Tokens;

namespace Fadd.Parser.SimpleSQL.ParseTreeTokens
{
    class ClassToken : ParseTreeToken
    {
        /// <summary>
        /// Check if the current position is the start of this token
        /// </summary>
        /// <returns>true if our token is the next one.</returns>
        public override bool Match(Tokenizer tokenizer, ParseTree tree)
        {
            return tokenizer.Peek() != ',';
        }

        /// <summary>
        /// Parses the data in the specified <see cref="Tokenizer"/>.
        /// </summary>
        /// <param name="tokenizer">The <see cref="Tokenizer"/> containing the data to parse.</param>
        /// <param name="tree"><see cref="ParseTree"/> that is being built..</param>
        /// <returns>true if more tokens can be parsed on the current leaf; false if we should continue to next leaf (parse no more children).</returns>
        public override bool Parse(Tokenizer tokenizer, ParseTree tree)
        {
            tokenizer.Ignore(Parser.WhiteSpaces);

            string className = string.Empty;
            while (!tokenizer.PeekEOF && !char.IsWhiteSpace(tokenizer.Peek()) && tokenizer.Peek() != ',')
                className += tokenizer.Read();

            //todo: add support for alias and "as [alias]"

            tree.Add(new Class(className));
            return true;            
        }
    }
}
