using Fadd.Parser;
using Fadd.Parser.SimpleSQL;

namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// OR condition ("||" in C#)
    /// </summary>
    public class Or : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.Or; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>" OR "</returns>
        public override string ToString()
        {
            return " OR ";
        }
    }
}
