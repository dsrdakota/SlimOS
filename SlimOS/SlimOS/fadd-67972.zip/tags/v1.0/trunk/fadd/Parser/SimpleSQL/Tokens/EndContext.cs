namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// End of context.
    /// </summary>
    public class EndContext : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.Context; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>(</returns>
        public override string ToString()
        {
            return ")";
        }
    }
}
