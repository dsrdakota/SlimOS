namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// A property name
    /// </summary>
    public class Property : Token
    {
        private string _name;

        /// <summary>
        /// Initializes a new instance of the <see cref="Property"/> class.
        /// </summary>
        /// <param name="name">Name of property.</param>
        public Property(string name)
        {
            Check.NotEmpty(name, "name");
            _name = name;
        }

        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.Property; }
        }

        /// <summary>
        /// Name of property
        /// </summary>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>column name</returns>
        public override string ToString()
        {
            return _name;
        }
    }
}
