using Fadd.Parser;
using Fadd.Parser.SimpleSQL;

namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// A IN clause.
    /// </summary>
    public class In : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.In; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>" IN"</returns>
        public override string ToString()
        {
            return " IN";
        }
    }
}
