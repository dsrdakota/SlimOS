namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// Used to identify conditions (used by Property to see it the text is a property or something else)
    /// </summary>
    public interface IConditional
    {
    }
}