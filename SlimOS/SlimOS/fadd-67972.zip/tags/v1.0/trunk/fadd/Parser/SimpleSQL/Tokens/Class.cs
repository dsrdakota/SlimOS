namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// Class/Table name
    /// </summary>
    public class Class : Token
    {
        private string _name;

        /// <summary>
        /// Initializes a new instance of the <see cref="Class"/> class.
        /// </summary>
        /// <param name="name">Name of class.</param>
        public Class(string name)
        {
            Check.NotEmpty(name, "name");
            _name = name;
        }

        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.Class; }
        }

        /// <summary>
        /// Name of class
        /// </summary>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        /// <summary>
        /// Returns SQL name
        /// </summary>
        /// <returns>Table name</returns>
        public override string ToString()
        {
            return Name;
        }
    }
}
