using Fadd.Parser.Evaluator.Tokens;

namespace Fadd.Parser.Evaluator.ParseTreeTokens
{
    /// <summary>
    /// Parse >=
    /// </summary>
    class MoreThanToken : ParseTreeToken
    {
        /// <summary>
        /// Check if the current position is the start of this token
        /// </summary>
        /// <returns>true if our token is the next one.</returns>
        public override bool Match(Tokenizer tokenizer, ParseTree tree)
        {
            return tokenizer.Peek(Parser.WhiteSpaces) == '>' && tokenizer.Peek(Parser.WhiteSpaces, 1) != '=';
        }

        /// <summary>
        /// Parses the data in the specified <see cref="Tokenizer"/>.
        /// </summary>
        /// <param name="tokenizer">The <see cref="Tokenizer"/> containing the data to parse.</param>
        /// <param name="tree"><see cref="ParseTree"/> that is being built..</param>
        /// <returns>true if more tokens can be parsed on the current leaf; false if we should continue to next leaf (parse no more children).</returns>
        public override bool Parse(Tokenizer tokenizer, ParseTree tree)
        {
            tokenizer.Ignore(Parser.WhiteSpaces);
            tokenizer.Read();
            tree.Add(new MoreThan());
            return true;
        }
    }
}
