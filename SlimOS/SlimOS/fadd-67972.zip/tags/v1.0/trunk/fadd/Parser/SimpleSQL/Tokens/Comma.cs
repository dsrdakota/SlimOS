namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// Represents a comma
    /// </summary>
    public class Comma : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.Comma; }
        }

        /// <summary>
        /// Conditional string
        /// </summary>
        /// <returns>", "</returns>
        public override string ToString()
        {
            return ", ";
        }
    }
}
