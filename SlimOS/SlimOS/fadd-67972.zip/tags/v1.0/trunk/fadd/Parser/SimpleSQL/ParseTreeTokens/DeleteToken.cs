using Fadd.Parser.SimpleSQL.Tokens;

namespace Fadd.Parser.SimpleSQL.ParseTreeTokens
{
    class DeleteToken : FromToken
    {
        public override bool Match(Tokenizer tokenizer, ParseTree tree)
        {
            return tokenizer.LookAhead(11, Parser.WhiteSpaces) == "DELETE FROM";
        }

        public override bool Parse(Tokenizer tokenizer, ParseTree tree)
        {
            tokenizer.Ignore(Parser.WhiteSpaces);
            tokenizer.Read(11);
            tree.Add(new Delete());
            return true;
        }
    }
}