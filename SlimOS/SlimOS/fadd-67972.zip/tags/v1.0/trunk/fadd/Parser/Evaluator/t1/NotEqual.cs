namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// Not equal condition
    /// </summary>
    public class NotEqual : Token, IConditional
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return EvaluatorTokenIds.NotEqual; }
        }

        public override string ToString()
        {
            return " != ";
        }
    }
}
