namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// Star *
    /// </summary>
    public class Star : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        public override int TokenIdentifier
        {
            get { return 9999; }
        }

		/// <summary>
		/// SQL Star 
		/// </summary>
		/// <returns>" * "</returns>
        public override string ToString()
        {
            return " * ";
        }
    }
}
