namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// We are getting into a sub context (nested conditions)
    /// </summary>
    public class Context : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.Context; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>(</returns>
        public override string ToString()
        {
            return "(";
        }
    }
}
