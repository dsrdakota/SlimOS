namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// Operator used for bitwise operations
    /// </summary>
    public class BitwiseOperator : Token
    {
        private readonly char _token;

        /// <summary>
        /// Initializes a new instance of the <see cref="BitwiseOperator"/> class.
        /// </summary>
        /// <param name="token">Bitwise char.</param>
        public BitwiseOperator(char token)
        {
            _token = token;
        }

        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.Bitwise; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>The token wrapped with spaces</returns>
        public override string ToString()
        {
            return ' ' + _token.ToString() + ' ';
        }
    }
}
