namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// &&
    /// </summary>
    public class And : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return EvaluatorTokenIds.And; }
        }

        public override string ToString()
        {
            return " && ";
        }
    }
}
