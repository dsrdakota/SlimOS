namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// Contains a value in a condition.
    /// </summary>
    public class PropertyValue : Token, IConditional
    {
        private readonly Property _property;

        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyValue"/> class.
        /// </summary>
        /// <param name="property">Property that this value belongs to.</param>
        public PropertyValue(Property property)
        {
            _property = property;
        }

        /// <summary>
        /// Identifier for this token.
        /// </summary>
        public override int TokenIdentifier
        {
            get { return EvaluatorTokenIds.PropertyValue; }
        }

        /// <summary>
        /// Property that this token belongs to.
        /// </summary>
        public Property Property
        {
            get { return _property; }
        }

		/// <summary>
		/// Question mark as string
		/// </summary>
		/// <returns>"?"</returns>
        public override string ToString()
        {
            return "?";
        }
    }
}
