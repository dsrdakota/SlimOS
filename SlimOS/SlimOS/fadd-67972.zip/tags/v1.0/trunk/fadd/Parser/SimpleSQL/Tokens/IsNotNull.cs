﻿namespace Fadd.Parser.SimpleSQL.Tokens
{
	/// <summary>
	/// Corresponds to "IS NOT NULL".
	/// </summary>
	public class IsNotNull : Token
	{
		/// <summary>
		/// Used to determine the kind of this token
		/// </summary>
		public override int TokenIdentifier
		{
			get { return -1; }
		}

		/// <summary>
		/// " IS NOT NULL"
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			return " IS NOT NULL";
		}
	}
}
