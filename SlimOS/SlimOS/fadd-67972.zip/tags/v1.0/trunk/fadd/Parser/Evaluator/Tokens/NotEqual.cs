namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// Not equal condition
    /// </summary>
    public class NotEqual : Token, IConditional
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return EvaluatorTokenIds.NotEqual; }
        }

        /// <summary>
        /// Condition string
        /// </summary>
        /// <returns>" != "</returns>
        public override string ToString()
        {
            return " != ";
        }
    }
}
