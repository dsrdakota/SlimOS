using Fadd.Parser.SimpleSQL.Tokens;

namespace Fadd.Parser.SimpleSQL.ParseTreeTokens
{
    class OrderByPropertyToken : ParseTreeToken
    {
        /// <summary>
        /// Check if the current position is the start of this token
        /// </summary>
        /// <returns>true if our token is the next one.</returns>
        public override bool Match(Tokenizer tokenizer, ParseTree tree)
        {
            return tree.Current is OrderBy;
        }

        /// <summary>
        /// Parses the data in the specified <see cref="Tokenizer"/>.
        /// </summary>
        /// <param name="tokenizer">The <see cref="Tokenizer"/> containing the data to parse.</param>
        /// <param name="tree"><see cref="ParseTree"/> that is being built..</param>
        /// <returns>true if more tokens can be parsed on the current leaf; false if we should continue to next leaf (parse no more children).</returns>
        public override bool Parse(Tokenizer tokenizer, ParseTree tree)
        {
            tokenizer.Ignore(Parser.WhiteSpaces);

            string propertyName = string.Empty;
            while (!tokenizer.PeekEOF && !char.IsWhiteSpace(tokenizer.Peek()) && tokenizer.Peek() != ',')
                propertyName += tokenizer.Read();

            bool ascending = true;

            // check if ASC or DESC is specified.
            if (!tokenizer.PeekEOF && string.Compare(tokenizer.LookAhead(4, Parser.WhiteSpaces), "DESC", true) == 0)
            {
                tokenizer.Ignore(Parser.WhiteSpaces);
                tokenizer.Read(4);
                ascending = false;
            }
            else if (!tokenizer.PeekEOF && string.Compare(tokenizer.LookAhead(3, Parser.WhiteSpaces), "ASC", true) == 0)
            {
                tokenizer.Ignore(Parser.WhiteSpaces);
                tokenizer.Read(3);
            }

            tree.Add(new OrderByProperty(propertyName, ascending));
            return true;
        }
    }
}
