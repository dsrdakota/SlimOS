using Fadd.Parser.SimpleSQL.Tokens;

namespace Fadd.Parser.SimpleSQL.ParseTreeTokens
{
    class BitwiseToken : ParseTreeToken
    {
        /// <summary>
        /// Check if the current position is the start of this token
        /// </summary>
        /// <param name="tokenizer"></param>
        /// <param name="tree"></param>
        /// <returns>true if our token is the next one.</returns>
        public override bool Match(Tokenizer tokenizer, ParseTree tree)
        {
            return tokenizer.Peek(Parser.WhiteSpaces) == '&';
        }

        public override bool Parse(Tokenizer tokenizer, ParseTree tree)
        {
            tokenizer.Ignore(Parser.WhiteSpaces);
            string token = tokenizer.Read(1);
            tree.Add(new BitwiseOperator(token[0]));
            return true;
        }
    }
}
