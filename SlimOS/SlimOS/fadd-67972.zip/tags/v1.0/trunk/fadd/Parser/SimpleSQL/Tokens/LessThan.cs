using Fadd.Parser;
using Fadd.Parser.SimpleSQL;

namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// <![CDATA[
    /// <
    /// ]]>
    /// </summary>
    public class LessThan : Token, IConditional
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        /// <value></value>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.LessThan; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>" &lt; "</returns>
        public override string ToString()
        {
            return " < ";
        }
    }

}
