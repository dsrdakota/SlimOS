namespace Fadd.Parser.SimpleSQL.Tokens
{
    /// <summary>
    /// FROM SQL clause
    /// </summary>
    public class From : Token
    {
        /// <summary>
        /// Used to determine the kind of this token
        /// </summary>
        public override int TokenIdentifier
        {
            get { return SqlTokenIds.From; }
        }

        /// <summary>
        /// Returns SQL
        /// </summary>
        /// <returns>" FROM "</returns>
        public override string ToString()
        {
            return " FROM ";
        }
    }
}
