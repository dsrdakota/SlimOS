using Fadd.Parser.Evaluator.ParseTreeTokens;

namespace Fadd.Parser.Evaluator.Tokens
{
    /// <summary>
    /// Parse 'AND'
    /// </summary>
    public class AndToken : Token
    {
        /// <summary>
        /// Check if the current position is the start of this token
        /// </summary>
        /// <returns>true if our token is the next one.</returns>
        public override bool Match(Tokenizer tokenizer, ParseTree tree)
        {
            if (tokenizer.Peek(Parser.WhiteSpaces) != 'A')
                return false;

            return tokenizer.LookAhead(3, Parser.WhiteSpaces) == "AND";
        }

        /// <summary>
        /// Parses the data in the specified <see cref="Tokenizer"/>.
        /// </summary>
        /// <param name="tokenizer">The <see cref="Tokenizer"/> containing the data to parse.</param>
        /// <param name="tree"><see cref="ParseTree"/> that is being built..</param>
        /// <returns>true if more tokens can be parsed on the current leaf; false if we should continue to next leaf (parse no more children).</returns>
        public override bool Parse(Tokenizer tokenizer, ParseTree tree)
        {
            tokenizer.Ignore(" \t");
            tokenizer.Read(3);
            tree.Add(new And());
            return true;
        }
    }
}
