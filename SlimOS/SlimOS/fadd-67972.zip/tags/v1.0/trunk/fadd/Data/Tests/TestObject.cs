#if TEST
using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Data.Tests
{
    public class TestObject
    {
        private string _userName;
        private string _lastName;

        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }
    }
}
#endif