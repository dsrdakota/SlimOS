using System;
using System.Collections;
using System.Collections.Generic;

namespace Fadd.Data.Mappings
{
    /// <summary>
    /// Contains a mapping between a database table and a .Net class.
    /// </summary>
    public interface IMapping
    {
        /// <summary>
        /// Gets table name.
        /// </summary>
        string TableName { get; }

        /// <summary>
        /// Gets class type
        /// </summary>
        Type Type { get; }

        /// <summary>
        /// Gets all mapped properties
        /// </summary>
        IEnumerable<PropertyMapping> Properties { get; }

        /// <summary>
        /// Gets all primary keys
        /// </summary>
        IList<PropertyMapping> PrimaryKeys { get; }

        /// <summary>
        /// Gets column name from a property name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        string GetColumnName(string name);

        /// <summary>
        /// Gets current primary key.
        /// </summary>
        /// <returns>The primary key if exactly ONE is defined; otherwise null.</returns>
        PropertyMapping GetPrimaryKey();
    }


}
