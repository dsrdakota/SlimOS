using System.Collections.Generic;
using Fadd.Data.Mappings;

namespace Fadd.Data
{
    /// <summary>
    /// Contains a compiled SQL statements.
    /// </summary>
    /// <remarks>
    /// "Compiled" means that we've converted the statement from ObjectSQL
    /// to real SQL with table and column names.
    /// </remarks>
    public class CompiledStatement
    {
        private readonly IList<string> _properties;
        private readonly IList<string> _arguments;
        private readonly string _sql;
        private readonly IMapping _mapping;

        /// <summary>
        /// Initializes a new instance of the <see cref="CompiledStatement"/> class.
        /// </summary>
        /// <param name="mapping">Mapping between columns and properties</param>
        /// <param name="sql">SQL statement.</param>
        /// <param name="properties">Properties that have been selected. null if no properties have been specified.</param>
        /// <param name="arguments">Arguments used in the SQL statement..</param>
        public CompiledStatement(IMapping mapping, string sql, IList<string> properties, IList<string> arguments)
        {
            Check.NotEmpty(sql, "sql");
            Check.Require(arguments, "arguments");
            Check.Require(mapping, "mapping");

            _sql = sql;
            _arguments = arguments;
            _mapping = mapping;
            _properties = properties;
        }
        /// <summary>
        /// Gets properties that are used as arguments to the statement.
        /// </summary>
        public IList<string> Arguments
        {
            get { return _arguments; }
        }

        /// <summary>
        /// Gets SQL statement.
        /// </summary>
        public string Sql
        {
            get { return _sql; }
        }

        /// <summary>
        /// Gets mappings between columns and properties.
        /// </summary>
        public IMapping Mapping
        {
            get { return _mapping; }
        }

        /// <summary>
        /// Gets properties that have been selected. 
        /// </summary>
        /// <remarks>
        /// null if no properties have been specified.
        /// </remarks>
        public IList<string> Properties
        {
            get { return _properties; }
        }

		/// <summary>
		/// Create a new statement with specialized SQL.
		/// </summary>
		/// <param name="sql">SQL string</param>
		/// <returns>New statement.</returns>
		public CompiledStatement CreateWrapper(string sql)
		{
			return new CompiledStatement(_mapping, sql, _properties, _arguments);
		}
    }
}
