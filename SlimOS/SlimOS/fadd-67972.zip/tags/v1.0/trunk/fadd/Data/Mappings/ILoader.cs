namespace Fadd.Data.Mappings
{
    /// <summary>
    /// Provides a mapping between properties and columns in a table.
    /// </summary>
    public interface ILoader
    {
		/// <summary>
		/// Get a mapping between a table and a class.
		/// </summary>
		/// <param name="className">Name of class, may not be full name</param>
		/// <returns><see cref="IMapping"/> if found; otherwise null.</returns>
        IMapping GetMapping(string className);
    }
}
