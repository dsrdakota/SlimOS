namespace Fadd.Data.Mappings
{
    /// <summary>
    /// Mappings for properties.
    /// </summary>
    public class PropertyMapping
    {
        private string _columnName;
        private string _propertyName;
        private bool _primaryKey;
        private string _generator;

        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyMapping"/> class.
        /// </summary>
        /// <param name="propertyName">Name of the class property.</param>
        /// <param name="columnName">Name of the database column.</param>
        public PropertyMapping(string propertyName, string columnName)
        {
            Check.NotEmpty(propertyName, "propertyName");
            Check.NotEmpty(columnName, "columnName");

            _propertyName = propertyName;
            _columnName = columnName;
        }

        /// <summary>
        /// Gets or sets name in table
        /// </summary>
        public string ColumnName
        {
            get { return _columnName; }
            set { _columnName = value; }
        }

        /// <summary>
        /// Gets or sets name in class.
        /// </summary>
        public string PropertyName
        {
            get { return _propertyName; }
            set { _propertyName = value; }
        }

        /// <summary>
        /// Gets or sets whether this property is part of the primary key
        /// </summary>
        public bool IsPrimaryKey
        {
            get { return _primaryKey; }
            set { _primaryKey = value; }
        }

        /// <summary>
        /// Gets or sets how the value is generated.
        /// </summary>
        /// <remarks>
        /// <list type="table">
        /// <item>
        /// <term>sequence</term>
        /// <description>Looks for a sequence named "[tableName]_id_seq"</description>
        /// </item>
        /// <item>
        /// <term>autoincrement</term>
        /// <description>Uses database specific code to fetch value after insert.
        /// <para>ONLY VALID FOR PRIMARY KEYS</para>
        /// </description>
        /// </item>
        /// <item>
        /// <term>guid</term>
        /// <description>generate a globally unique identifier.</description>
        /// </item>
        /// <item>
        /// <term>any other value</term>
        /// <description>specifies a sequence/generator name</description>
        /// </item>
        /// </list>
        /// </remarks>
        public string Generator
        {
            get { return _generator; }
            set { _generator = value; }
        }
    }
}
