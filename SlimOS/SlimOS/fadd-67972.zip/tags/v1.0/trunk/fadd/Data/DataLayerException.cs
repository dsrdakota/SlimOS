using System;
using System.Data.Common;

namespace Fadd.Data
{
    /// <summary>
    /// Main exception in the data layer.
    /// </summary>
    public class DataLayerException : Exception
    {
        private readonly string _sql;

        /// <summary>
        /// Initializes a new instance of the <see cref="DataLayerException"/> class.
        /// </summary>
        /// <param name="msg">Error message.</param>
        /// <param name="innerException">Inner exception.</param>
        internal DataLayerException(string msg, DbException innerException)
            : base(msg, innerException)
        {
            
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DataLayerException"/> class.
        /// </summary>
        /// <param name="msg">Error message.</param>
        internal DataLayerException(string msg)
            : base(msg)
        {

        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DataLayerException"/> class.
        /// </summary>
        /// <param name="sql">SQL query that failed</param>
        /// <param name="msg">Error message.</param>
        public DataLayerException(string sql, string msg) : base(msg)
        {
            _sql = sql;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DataLayerException"/> class.
        /// </summary>
        /// <param name="sql">SQL query that failed</param>
        /// <param name="msg">Error message.</param>
        /// <param name="innerException">Inner exception.</param>
        public DataLayerException(string sql, string msg, DbException innerException)
            : base(msg, innerException)
        {
            _sql = sql;
        }

        /// <summary>
        /// SQL query that failed.
        /// </summary>
        public string Sql
        {
            get { return _sql; }
        }
    }
}
