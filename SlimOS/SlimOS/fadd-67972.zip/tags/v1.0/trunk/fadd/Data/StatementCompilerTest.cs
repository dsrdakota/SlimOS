#if TEST
using Fadd.Data.Mappings;
using Fadd.Data.Tests;
using Xunit;

namespace Fadd.Data
{
    /// <summary>
    /// Test for <see cref="StatementCompiler"/>.
    /// </summary>
    public class StatementCompilerTest
    {
        private readonly StatementCompiler _compiler;
        private readonly Provider _providers = new Provider();

        /// <summary>
        /// Initializes a new instance of the <see cref="StatementCompilerTest"/> class.
        /// </summary>
        public StatementCompilerTest()
        {
            _providers = new Provider();
            _compiler = new StatementCompiler(_providers, false);

            Mapping mapping = new Mapping(typeof(TestObject), "test_object");
            mapping.Add("UserName", "user_name");
            mapping.Add("LastName", "last_name");
            _providers.AddMapping(mapping);
        }

        [Fact]
        private void TestSimpleSelect()
        {
            CompiledStatement statement = _compiler.CompileWrapper("SELECT UserName, LastName FROM TestObject");
            Assert.Equal("SELECT user_name, last_name FROM test_object", statement.Sql);
        }

        [Fact]
        private void TestSimpleWhere()
        {
            CompiledStatement statement = _compiler.CompileWrapper("SELECT UserName, LastName FROM TestObject WHERE LastName LIKE ?");
            Assert.Equal("SELECT user_name, last_name FROM test_object WHERE last_name LIKE @param0", statement.Sql);
        }


    }
}
#endif