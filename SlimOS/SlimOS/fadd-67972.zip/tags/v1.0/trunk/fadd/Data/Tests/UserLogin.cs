using System;

namespace Fadd.Data.Tests
{
    class UserLogin
    {
        private int _userId;
        private string _password;
        private string _email;
        private int _loginAttempts;
        private string _passwordResetGuid;
        private DateTime _lastLoginAt;
        private string _payPalEmail;

        public int UserId
        {
            get { return _userId; }
            set { _userId = value; }
        }

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }

        public int LoginAttempts
        {
            get { return _loginAttempts; }
            set { _loginAttempts = value; }
        }

        public string PasswordResetGuid
        {
            get { return _passwordResetGuid; }
            set { _passwordResetGuid = value; }
        }

        public DateTime LastLoginAt
        {
            get { return _lastLoginAt; }
            set { _lastLoginAt = value; }
        }

        public string PayPalEmail
        {
            get { return _payPalEmail; }
            set { _payPalEmail = value; }
        }
    }
}