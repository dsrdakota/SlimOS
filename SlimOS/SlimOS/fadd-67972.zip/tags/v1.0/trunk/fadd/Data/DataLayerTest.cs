#if TEST
using System;
using System.Collections.Generic;
using Fadd.Data.ConnectionHelpers;
using Fadd.Data.Mappings;
using Fadd.Tests;
using Xunit;

namespace Fadd.Data
{
    /// <summary>
    /// Tests for <see cref="DataLayer"/>
    /// </summary>
    public class DataLayerTest
    {
        private DataLayer _dataLayer;

        /// <summary>
        /// Initializes a new instance of the <see cref="DataLayerTest"/> class.
        /// </summary>
        public DataLayerTest()
        {
            SqlServerHelper config =
                new SqlServerHelper(
                    "Server=localhost\\SQLEXPRESS;Database=FaddTest;User ID=FaddTest;Password=TestFadd;Trusted_Connection=False;");
            _dataLayer = new DataLayer(config);
            _dataLayer.MappingProviders.Add(new MirrorLoader(typeof (User).Assembly, "autoincrement"));

        }

        [Fact]
        private void TestSave()
        {
            User user = new User();
            user.CreatedAt = DateTime.Now;
            user.FirstName = "Arne";
            user.UserName = "smurf";
            _dataLayer.Save(user);
            Assert.NotEqual(0, user.Id);
        }

        [Fact]
        private void TestSaveUpdate()
        {
            User user = new User();
            user.CreatedAt = DateTime.Now;
            user.FirstName = "Arne";
            user.UserName = "smurf";
            _dataLayer.Save(user);
            Assert.NotEqual(0, user.Id);
            int id = user.Id;
            _dataLayer.Save(user);
            Assert.Equal(id, user.Id);
        }

        [Fact]
        private void TestFetch()
        {
            User user = _dataLayer.GetById<User>(1);
            Assert.Null(user);
        }

        [Fact]
        private void FetchCollection()
        {
            IList<User> users = _dataLayer.Find<User>();
            Assert.NotEqual(0, users.Count);
        }

        [Fact]
        private void FetchCollectionWithConditions()
        {
            IList<User> users = _dataLayer.Find<User>("FirstName = ?", "Arne");
            Assert.NotEqual(0, users.Count);
        }

        [Fact]
        private void FetchCollectionBitWise()
        {
            IList<User> users = _dataLayer.Find<User>("(Id & ?) = ?", 4, 4);
        }
        [Fact]
        private void FetchCollectionWithStatement()
        {
            IList<User> users = _dataLayer.Find<User>(new Statement("FirstName = ?", "Arne"));
            Assert.NotEqual(0, users.Count);
        }

        [Fact]
        private void RemoveItems()
        {
            IList<User> users = _dataLayer.Find<User>("FirstName = ?", "Arne");
            Assert.NotEqual(0, users.Count);
            _dataLayer.RemoveById<User>(users[0].Id);
        }

        [Fact]
        private void Remove()
        {
            _dataLayer.Remove<User>("FirstName = ?", "Arne");
        }

        [Fact]
        private void TransactionCommit()
        {
            using (ITransaction trans = _dataLayer.CreateTransaction())
            {
                trans.Commit();
            }
        }

        [Fact]
        private void TransactionRollback()
        {
            using (ITransaction trans = _dataLayer.CreateTransaction())
            {
            }
        }

    }
}
#endif