﻿using System;

namespace Fadd.Data.Mappings
{
	/// <summary>
	/// SQL92 column types.
	/// </summary>
	public enum ColumnType
	{
		/// <summary>
		/// One bit
		/// </summary>
		Bit,

		/// <summary>
		/// Short string
		/// </summary>
		String,

		/// <summary>
		/// floating point
		/// </summary>
		Double,

		/// <summary>
		/// Int column
		/// </summary>
		Integer,

		/// <summary>
		/// DateTime / Timestamp
		/// </summary>
		DateTime,

		/// <summary>
		/// Date only
		/// </summary>
		Date,

		/// <summary>
		/// Time only
		/// </summary>
		Time,

		/// <summary>
		/// Bool, int(1)
		/// </summary>
		Boolean,

		/// <summary>
		/// Long string
		/// </summary>
		Text
	}

	/// <summary>
	/// Common operations for columns
	/// </summary>
	public static class ColumnHelper
	{
		/// <summary>
		/// Convert a column type to a .Net type
		/// </summary>
		/// <param name="type">column type to convert</param>
		/// <returns></returns>
		public static Type ToType(ColumnType type)
		{
			switch (type)
			{
				case ColumnType.Bit:
					return typeof(byte);
				case ColumnType.Boolean:
					return typeof(bool);
				case ColumnType.Date:
					return typeof(DateTime);
				case ColumnType.DateTime:
					return typeof(DateTime);
				case ColumnType.Integer:
					return typeof(int);
				case ColumnType.String:
					return typeof(string);
				case ColumnType.Text:
					return typeof(string);
				case ColumnType.Time:
					return typeof(DateTime);
				case ColumnType.Double:
					return typeof(Double);
				default:
					return typeof(object);
			}
		}
	}
}
