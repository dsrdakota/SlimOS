using System;

namespace Fadd.Data
{
    /// <summary>
    /// Database connection configuration
    /// </summary>
    public class ConnectionConfiguration
    {
        private string _driverName;
        private string _connectionString;
        private Type _connectionType;

        /// <summary>
        /// Assembly qualified name of the .Net driver to use.
        /// </summary>
        public string DriverName
        {
            get { return _driverName; }
            set
            {
                _driverName = value;
                _connectionType = Type.GetType(_driverName, true, true);
            }
        }

        /// <summary>
        /// Connection string
        /// </summary>
        public string ConnectionString
        {
            get { return _connectionString; }
            set { _connectionString = value; }
        }

        /// <summary>
        /// Connection type.
        /// </summary>
        internal Type ConnectionType
        {
            get { return _connectionType; }
        }
    }
}
