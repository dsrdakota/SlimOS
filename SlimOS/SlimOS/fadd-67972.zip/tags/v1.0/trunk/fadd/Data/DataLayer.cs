using System.Collections.Generic;
using System.Data;

namespace Fadd.Data
{
    /// <summary>
    /// Main class in the data access layer.
    /// </summary>
    public class DataLayer : DataLayerImp, IDataLayer
    {
        private readonly IConnectionHelper _connectionHelper;

        /// <summary>
        /// Initializes a new instance of the <see cref="DataLayer"/> class.
        /// </summary>
        /// <param name="connectionHelper">The connection helper.</param>
        public DataLayer(IConnectionHelper connectionHelper) : base(connectionHelper)
        {
            Check.Require(connectionHelper, "connectionHelper");
            _connectionHelper = connectionHelper;
        }

    	/// <summary>
    	/// Determines if we are a transaction.
    	/// </summary>
    	public override bool IsTransaction
    	{
    		get { return false; }
    	}

    	/// <summary>
        /// Creates a connection, we use this method instead of the one in
        /// the connection helper to be able to use transactions (with a single connection).
        /// </summary>
        /// <returns>A database connection.</returns>
        protected override IDbConnection CreateConnection()
        {
            return _connectionHelper.CreateConnection();
        }

        /// <summary>
        /// Create a command.
        /// </summary>
        /// <returns></returns>
        protected override IDbCommand CreateCommand(IDbConnection connection)
        {
            return connection.CreateCommand();
        }

        /// <summary>
        /// Creates a new transaction.
        /// </summary>
        /// <param name="level">On of the <see cref="IsolationLevel"/>s.</param>
        /// <returns>An object representing the new transaction.</returns>
        /// <remarks>
        /// Once the transaction has completed, you must explicitly commit or roll back the transaction by using the Commit or Rollback methods.
        /// </remarks>
        public ITransaction CreateTransaction(IsolationLevel level)
        {
			return new Transaction(this, level);
        }

        /// <summary>
        /// Creates a new transaction.
        /// </summary>
        /// <returns>An object representing the new transaction.</returns>
        /// <remarks>
        /// Once the transaction has completed, you must explicitly commit or roll back the transaction by using the Commit or Rollback methods.
        /// </remarks>
        public ITransaction CreateTransaction()
        {
            return new Transaction(this);
        }


    }
}