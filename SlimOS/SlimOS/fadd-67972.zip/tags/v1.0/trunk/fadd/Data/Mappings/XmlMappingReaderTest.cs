using System.IO;
using System.Text;
using System.Xml;
using Fadd.Data.Tests;
using Xunit;

namespace Fadd.Data.Mappings
{
    /// <summary>
    /// Tests for <see cref="XmlMappingReader"/>.
    /// </summary>
    public class XmlMappingReaderTest
    {
        private const string Test1 =
            @"<?xml version=""1.0"" encoding=""utf-8"" ?>
<class name=""RecordUnion.Core.Users.UserLogin, RecordUnion.Core"" table=""record_union"">
    <id name=""UserId"" column=""UserId"" type=""integer""/>
    <property name=""Email"" column=""Email"" type=""string""/>
    <property name=""Password"" column=""Password"" type=""string""/>
    <property name=""LoginAttempts"" column=""LoginAttempts"" type=""integer""/>
    <property name=""PasswordResetGuid"" column=""PasswordResetGuid"" type=""string""/>
    <property name=""LastLoginAt"" column=""LastLoginAt"" type=""datetime""/>
    <property name=""PayPalEmail"" column=""PayPalEmail"" type=""datetime""/>
</class>
";

        [Fact]
        private void TestDecoding()
        {
            Stream stream = new MemoryStream(Encoding.UTF8.GetBytes(Test1));
            XmlTextReader reader = new XmlTextReader(stream);
            XmlMappingReader mappingReader = new XmlMappingReader(reader, typeof(UserLogin));
            IMapping mapping = mappingReader.Read();

            //TODO: Validate mapping so that all properties have been added.
        }

        [Fact]
        private void MappingWithPropertyThatDoNotExist()
        {
            
        }

        [Fact]
        private void MappingWithInvalidType()
        {
            
        }
    }
}
