using System;
using System.Data.Common;

namespace Fadd.Data.Mappings
{
    /// <summary>
    /// Throw during mapping exceptions.
    /// </summary>
    public class MappingException : DataLayerException
    {
        private readonly Type _mappingType;

        /// <summary>
        /// Initializes a new instance of the <see cref="MappingException"/> class.
        /// </summary>
        /// <param name="msg">Error message.</param>
        /// <param name="mappingType">Type that the mapping failed for.</param>
        public MappingException(Type mappingType, string msg) : base(msg)
        {
            _mappingType = mappingType;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MappingException"/> class.
        /// </summary>
        /// <param name="msg">Error message.</param>
        /// <param name="innerException">Inner exception.</param>
        /// <param name="mappingType">Type that the mapping failed for.</param>
        public MappingException(Type mappingType, string msg, DbException innerException)
            : base(msg, innerException)
        {
            _mappingType = mappingType;
        }

        /// <summary>
        /// Type that the mapping failed for.
        /// </summary>
        public Type MappingType
        {
            get { return _mappingType; }
        }
    }
}
