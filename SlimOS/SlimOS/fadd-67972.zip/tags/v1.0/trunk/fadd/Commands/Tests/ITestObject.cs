#if DEBUG

namespace Fadd.Commands.Tests
{
    /// <summary>
    /// 
    /// </summary>
    public interface ITestObject
    {
        /// <summary>
        /// Tests it.
        /// </summary>
        /// <param name="myArg">My arg.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        string TestIt(string myArg, int value);

		/// <summary>
		/// Tests it.
		/// </summary>
		/// <param name="myArg">My arg.</param>
		/// <param name="value">The value.</param>
		/// <returns></returns>
		string TestIt(string myArg, bool value);


        /// <summary>
        /// Does the this.
        /// </summary>
        void DoThis();

		/// <summary>
		/// Modify the id of the testobject
		/// </summary>
		int Id { get; set; }
    }
}
#endif