using System;
using System.Reflection;

namespace Fadd.Commands
{
    /// <summary>
    /// Command sent by a TypeProxy
    /// </summary>
    public class ObjectProxyCommand : Command
    {
        private readonly Type _type;
        private readonly MethodInfo _method;
        private readonly object[] _args;
        private object _returnValue;
        private Exception _exception;

        /// <summary>
        /// Initializes a new instance of the <see cref="ObjectProxyCommand"/> class.
        /// </summary>
        /// <param name="type">Type of object to execute method on.</param>
        /// <param name="method">Method to call.</param>
        /// <param name="arguments">Argumens that should be passed to the method.</param>
        public ObjectProxyCommand(Type type, MethodInfo method, object[] arguments)
        {
            Check.Require(type, "type");
            Check.Require(method, "method");

            _type = type;
            _method = method;
            _args = arguments;
        }

        /// <summary>
        /// Return value from method call.
        /// </summary>
        public object ReturnValue
        {
            get { return _returnValue; }
            set { _returnValue = value; }
        }

        /// <summary>
        /// Type of object to execute method on.
        /// </summary>
        public Type Type
        {
            get { return _type; }
        }

        /// <summary>
        /// Method to call.
        /// </summary>
        public MethodInfo Method
        {
            get { return _method; }
        }

        /// <summary>
        /// Argumens that should be passed to the method call.
        /// </summary>
        public object[] Args
        {
            get { return _args; }
        }

        /// <summary>
        /// Exception thrown during method call
        /// </summary>
        public Exception Exception
        {
            get { return _exception; }
            set { _exception = value; }
        }
    }
}
