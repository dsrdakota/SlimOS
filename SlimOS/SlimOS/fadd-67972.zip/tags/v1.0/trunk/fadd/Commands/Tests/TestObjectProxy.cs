using System;
using System.Reflection;
using Xunit;

namespace Fadd.Commands.Tests
{
    public class TestObjectProxy : TestObject
    {
        private Type _realType = typeof (TestObject);
        private Type _myType = typeof (TestObjectProxy);
        private ICommandDispatcher _dispatcher;
        private MethodInfo _ExecuteString;
        private MethodInfo _DoThis;


        public TestObjectProxy(ICommandDispatcher dispatcher)
        {
            _dispatcher = dispatcher;
            _ExecuteString = _realType.GetMethod("Execute");
            _DoThis = _realType.GetMethod("DoThis");
        }


        public new String Execute(System.String arg0)
        {
            ObjectProxyCommand cmd = new ObjectProxyCommand(_realType, _ExecuteString, new object[] {arg0});
            _dispatcher.Invoke(this, cmd);
            if (!cmd.IsHandled)
                throw new NotImplementedException("Fadd.Commands.Tests.TestObject.Execute have not been implemented.");

            return (String) cmd.ReturnValue;
        }

        public new void DoThis()
        {
            ObjectProxyCommand cmd = new ObjectProxyCommand(_realType, _DoThis, null);

            _dispatcher.Invoke(this, cmd);
            if (!cmd.IsHandled)
                throw new NotImplementedException("Fadd.Commands.Tests.TestObject.DoThis have not been implemented.");
        }


        public new Type GetType()
        {
            return _realType;
        }

        public Type GetMyType()
        {
            return _myType;
        }

        [Fact]
        static void TestThis()
        {
            TestObjectProxy proxy = new TestObjectProxy(new CommandManager());
            TestObject obj = proxy;
            obj.DoThis();
            ((TestObject)proxy).DoThis();
        }
    }
}