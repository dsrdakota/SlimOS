#if TEST
using System;
using System.Threading;
using Fadd.Commands;
using Fadd.Commands.Tests;
using Xunit;
#pragma warning disable 1591

namespace Fadd.Commands.Tests
{
    public class CommandManagerTester
    {
        CommandManager light;
        private bool _myCmd;
        private bool _handleMyCmd;
        private bool _attrCmd;
        private bool _handleAttrCmd;
        private bool _ifaceCmd;
        private bool _handleIfaceCmd;
        private bool _derCmd;
        private bool _handleDerCmd;
        private bool _asyncCompleted;
        private bool _unhandled;
        private bool _handleUnhandled;

        public CommandManagerTester()
        {
            light = new CommandManager();
            light.Add(typeof(MyCommand), OnMyCommand);
            light.Add(typeof(MyAttr), OnMyAttr);
            light.Add(typeof(myFace), OnInterfaceCmd);
            light.Add(typeof(DerivedCmd), OnDerivedCmd);
            Reset();
        }

        public void Reset()
        {
            _myCmd = false;
            _handleMyCmd = _handleAttrCmd = _handleIfaceCmd = _handleDerCmd = true;
            _attrCmd = false;
            _ifaceCmd = false;
            _unhandled = false;
            _derCmd = false;
            _handleUnhandled = true;
        }

        [Fact]
        public void TestCommand()
        {
            MyCommand cmd = new MyCommand("myName");
            Assert.True(light.Invoke(cmd));
            Assert.True(_myCmd);
        }

        [Fact]
        public void TestCommand2()
        {
            MyCommand cmd = new MyCommand("myName");
            _handleMyCmd = false;
            Assert.False(light.Invoke(cmd));
            Assert.False(_myCmd);
        }

        [Fact]
        public void TestAttr()
        {
            MyAttrCommand cmd = new MyAttrCommand("myName");
            Assert.True(light.Invoke(cmd));
            Assert.True(_attrCmd);
        }

        [Fact]
        public void TestAttr2()
        {
            MyAttrCommand cmd = new MyAttrCommand("myName");
            _handleAttrCmd = false;
            Assert.False(light.Invoke(cmd));
            Assert.False(_attrCmd);
        }

        [Fact]
        public void TestInterface()
        {
            MyFaceCmd cmd = new MyFaceCmd("myName");
            Assert.True(light.Invoke(cmd), "invoke");
            Assert.True(_ifaceCmd, "ifaceCmd");
        }

        [Fact]
        public void TestInterface2()
        {
            MyFaceCmd cmd = new MyFaceCmd("myName");
            _handleIfaceCmd = false;
            Assert.False(light.Invoke(cmd));
            Assert.False(_ifaceCmd);
        }



        [Fact]
        public void TestSubClass()
        {
            DerivedCmd cmd = new DerivedCmd("myName");
            Assert.True(light.Invoke(cmd), "invoke");
            Assert.True(_derCmd, "_derCmd");
        }

        [Fact]
        public void TestSubClass2()
        {
            DerivedCmd cmd = new DerivedCmd("myName");
            _handleDerCmd = false;
            _handleMyCmd = false;
            Assert.False(light.Invoke(cmd), "Invoke");
            Assert.False(_derCmd, "_derCmd");
            Assert.False(_myCmd, "_myCmd");
        }

        [Fact]
        public void TestSubClass3()
        {
            DerivedCmd cmd = new DerivedCmd("myName");
            _handleDerCmd = false;
            Assert.True(light.Invoke(cmd), "Invoke");
            Assert.False(_derCmd, "_derCmd");
            Assert.True(_myCmd, "_myCmd");
        }

        [Fact]
        public void TestSubClass4()
        {
            DerivedCmd cmd = new DerivedCmd("myName");
            _handleMyCmd = false;
            Assert.True(light.Invoke(cmd), "Invoke");
            Assert.True(_derCmd, "_derCmd");
            Assert.False(_myCmd, "_myCmd");
        }

        [Fact]
        public void TestAdd()
        {
            Assert.Throws(typeof(ArgumentException), delegate { light.Add(typeof (MyCommand), OnMyCommand); });
        }

        [Fact]
        public void TestRemoveAndAdd()
        {
            light.Remove(typeof(MyCommand), OnMyCommand);
            Assert.False(light.Invoke(new MyCommand("test")), "invokeAfterRemove");
            Assert.False(_myCmd, "handledAfterRemove");
            light.Add(typeof(MyCommand), OnMyCommand);
            Assert.True(light.Invoke(new MyCommand("test")), "invokeAfterAdd");
            Assert.True(_myCmd, "handlerAfterAdd");
        }

        public void TestBloated()
        {
            Assert.True(light.Invoke(new AllTypes("name")));
            Assert.True(_ifaceCmd);
            Assert.True(_myCmd);
            Assert.True(_attrCmd);
            Assert.True(_derCmd);

            // test again, this time everyting should be mapped and done.
            Reset();
            Assert.True(light.Invoke(new AllTypes("name")));
            Assert.True(_ifaceCmd);
            Assert.True(_myCmd);
            Assert.True(_attrCmd);
            Assert.True(_derCmd);
        }

        public void TestAsync()
        {
            light.BeginInvoke(new MyCommand("completes"), OnCompleted, null);
            Thread.Sleep(100);
            Assert.True(_asyncCompleted);
            Assert.True(_myCmd);
        }

        public void TestAsync2()
        {
            IAsyncResult res = light.BeginInvoke(new MyCommand("completes"), OnCompleted, null);
            light.EndInvoke(res);
            Assert.True(_asyncCompleted);
            Assert.True(_myCmd);

        }

        private void OnCompleted(IAsyncResult ar)
        {
            _asyncCompleted = true;
        }

        public void TestUnknownCommand()
        {
            Assert.False(light.Invoke(new UnknownCommand()));
        }

        public void TestUnknownCommand2()
        {
            light.Unhandled += OnUnhandledCommand;
            bool res = light.Invoke(new UnknownCommand());
            Assert.True(res);
            Assert.True(_unhandled);
        }

        public void TestUnknownCommand3()
        {
            light.Unhandled += OnUnhandledCommand;
            _handleUnhandled = false;
            bool res = light.Invoke(new UnknownCommand());
            Assert.False(res);
            Assert.False(_unhandled);
        }

        public void TestUnknownCommandAsync1()
        {
            light.Unhandled += OnUnhandledCommand;
            UnknownCommand cmd = new UnknownCommand();
            IAsyncResult res = light.BeginInvoke(cmd, OnCompleted, null);
            Assert.Null(res);
            Assert.True(cmd.IsHandled);
            Assert.True(_unhandled);
        }

        public void TestUnknownCommandAsync2()
        {
            light.Unhandled += OnUnhandledCommand;
            _handleUnhandled = false;
            UnknownCommand cmd = new UnknownCommand();
            IAsyncResult res = light.BeginInvoke(cmd, OnCompleted, null);
            Assert.Null(res);
            Assert.False(cmd.IsHandled);
            Assert.False(_unhandled);
        }

        public void TestUnknownCommandAsync3()
        {
            light.Unhandled += OnUnhandledCommand;
            _handleMyCmd = false;
            _handleUnhandled = false;
            MyCommand cmd = new MyCommand("test");
            IAsyncResult res = light.BeginInvoke(cmd, OnCompleted, null);
            Assert.NotNull(res);
            Assert.Same(light.EndInvoke(res), cmd);
            Assert.False(cmd.IsHandled);
            Assert.False(_myCmd);
        }

        private bool OnUnhandledCommand(object source, CommandEventArgs args)
        {
            if (!_handleUnhandled)
                return false;

            _unhandled = true;
            return true;
        }

        private bool OnMyAttr(object source, CommandEventArgs args)
        {
            if (!_handleAttrCmd)
                return false;

            _attrCmd = true;
            return true;
        }

        private bool OnInterfaceCmd(object source, CommandEventArgs args)
        {
            if (!_handleIfaceCmd)
                return false;

            _ifaceCmd = true;
            return true;
        }

        private bool OnDerivedCmd(object source, CommandEventArgs args)
        {
            if (!_handleDerCmd)
                return false;

            _derCmd = true;
            return true;
        }

        private bool OnMyCommand(object source, CommandEventArgs args)
        {
            if (!_handleMyCmd)
                return false;

            _myCmd = true;
            return true;
        }
    }
}

#endif