using System;

namespace Fadd.Commands
{
    /// <summary>
    /// This delegate is invoked when a command is about to behing invoked or added to the dispatcher.
    /// <para>
    /// Throw <see cref="InvalidOperationException"/> if Type may not be handled/invoked.
    /// </para>
    /// </summary>
    /// <param name="source">dispatcher that is being used.</param>
    /// <param name="args">arguments with info</param>
    public delegate void FilterHandler(object source, FilterEventArgs args);


    /// <summary>
    /// Arguments for <see cref="FilterHandler"/>.
    /// </summary>
    public class FilterEventArgs : EventArgs
    {
        private readonly Type _type;

        /// <summary>
        /// Initializes a new instance of the <see cref="FilterEventArgs"/> class.
        /// </summary>
        /// <param name="type">Type of command (if Invoke is called) or Type to handle (if Add is called).</param>
        public FilterEventArgs(Type type)
        {
            if (type == null)
                throw new ArgumentNullException("type");

            _type = type;
        }

        /// <summary>
        /// Type of command (if Invoke is called) or Type to handle (if Add is called).
        /// </summary>
        public Type Type
        {
            get { return _type; }
        }
    }
}
