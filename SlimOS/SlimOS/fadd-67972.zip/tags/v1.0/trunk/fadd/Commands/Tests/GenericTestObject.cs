#if DEBUG
using System;
using System.Collections.Generic;

namespace Fadd.Commands.Tests
{
	/// <summary>
	/// Test object using generic types
	/// </summary>
	/// <typeparam name="T">The first value to use the type of</typeparam>
	/// <typeparam name="K">The second value to use the type of</typeparam>
	public class GenericTestObject<T, K> : ITestObject
	{
		/// <summary>
		/// Tests it.
		/// </summary>
		/// <param name="myArg">String format</param>
		/// <param name="value">A value to use in the string</param>
		/// <returns>string.Format(myArg, value, typeof(T), typeof(K))</returns>
		public virtual string TestIt(string myArg, int value)
		{
			return string.Format(myArg, value, typeof(T), typeof(K));
		}

		/// <summary>
		/// Tests it.
		/// </summary>
		/// <param name="myArg">String format</param>
		/// <param name="value">A value to use in the string</param>
		/// <returns>string.Format(myArg, value, typeof(T), typeof(K))</returns>
		public string TestIt(string myArg, bool value)
		{
			return TestIt(myArg, value ? 1 : 0);
		}

		/// <summary>
		/// Retrieves a dictionary using the two specified types with some random arguments in
		/// </summary>
		public virtual Dictionary<Q, P> RetrieveGenericDictionary<Q, P>(EventHandler<EventArgs> handler) where P : struct where Q : struct
		{
			Dictionary<Q, P> dict = new Dictionary<Q, P>();
			dict.Add(new Q(), new P());
			return dict;
		}

		/// <summary>
		/// Does the this.
		/// </summary>
		public virtual void DoThis()
		{
			throw new InvalidOperationException("We failed :(");
		}

		/// <summary>
		/// Modify the id of the testobject
		/// </summary>		
		public int Id
		{
			get { throw new System.NotImplementedException(); }
			set { throw new System.NotImplementedException(); }
		}
	}
}
#endif