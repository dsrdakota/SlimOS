using System;
using System.Collections.Generic;

namespace Fadd.Commands.Net
{
#if DEBUG
    #region TestCommand
#pragma warning disable 1591
    /// <summary>
    /// Used to test inner classes.
    /// </summary>
    [Serializable]
    public class TestCommand : Command, IRemote
    {
        private List<string> _myList = new List<string>();
        private string _userName;

        internal TestCommand(string userName)
        {
            _userName = userName;
        }
        public List<string> MyList
        {
            get { return _myList; }
        }

        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        #region Implementation of IRemote

        /// <summary>
        /// Copy all stuff that have been modified by the command handler.
        /// </summary>
        /// <param name="from">Command to copy reply from.</param>
        public void CopyReply(Command from)
        {
            _myList = ((TestCommand) from)._myList;
        }

        #endregion
    }
#pragma warning restore 1591
#endregion
#endif
}
