#if DEBUG
using System;

namespace Fadd.Commands.Tests
{
    /// <summary>
    /// 
    /// </summary>
    public class TestObject : ITestObject
    {

        /// <summary>
        /// Tests it.
        /// </summary>
        /// <param name="myArg">My arg.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
		virtual public string TestIt(string myArg, int value)
        {
            return value + "hihi";
        }

		/// <summary>
		/// Tests it.
		/// </summary>
		/// <param name="myArg">My arg.</param>
		/// <param name="value">The value.</param>
		/// <returns></returns>
		virtual public string TestIt(string myArg, bool value)
		{
			return TestIt(myArg, value ? 1 : 0);
		}

        /// <summary>
        /// Does the this.
        /// </summary>
        public virtual void DoThis()
        {
            throw new InvalidOperationException("We failed :(");
        }

		/// <summary>
		/// Modify the id of the testobject
		/// </summary>
    	public int Id
    	{
    		get { throw new System.NotImplementedException(); }
    		set { throw new System.NotImplementedException(); }
    	}
    }
}
#endif