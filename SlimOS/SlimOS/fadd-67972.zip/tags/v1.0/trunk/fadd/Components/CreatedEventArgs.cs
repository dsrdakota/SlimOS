using System;
using System.Collections.Generic;

namespace Fadd.Components
{
    /// <summary>
    /// Arguments for <see cref="ComponentFactory.Created"/>.
    /// </summary>
    public class CreatedEventArgs : EventArgs
    {
        private readonly Type _interfaceType;
        private readonly object _instance;
        private readonly CreateMode _createMode;
        private readonly Stack<Type> _dependencyStack;

        /// <summary>
        /// Initializes a new instance of the <see cref="CreatedEventArgs"/> class.
        /// </summary>
        /// <param name="interfaceType">Type of the interface used to request instance.</param>
        /// <param name="instance">Instance being returned when <see cref="InterfaceType"/> is being requested..</param>
        /// <param name="createMode">How the component was created</param>
        /// <param name="dependencyStack">Current dependency stack</param>
        public CreatedEventArgs(Type interfaceType, object instance, CreateMode createMode, Stack<Type> dependencyStack)
        {
            _interfaceType = interfaceType;
            _dependencyStack = dependencyStack;
            _createMode = createMode;
            _instance = instance;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreatedEventArgs"/> class.
        /// </summary>
        /// <param name="interfaceType">Type of the interface used to request instance.</param>
        /// <param name="instance">Instance being returned when <see cref="InterfaceType"/> is being requested..</param>
        /// <param name="createMode">How the component was created</param>
        public CreatedEventArgs(Type interfaceType, object instance, CreateMode createMode)
        {
            _interfaceType = interfaceType;
            _dependencyStack = null;
            _createMode = createMode;
            _instance = instance;
        }

        /// <summary>
        /// Type of the interface used to request instance
        /// </summary>
        public Type InterfaceType
        {
            get { return _interfaceType; }
        }

        /// <summary>
        /// Instance being returned when <see cref="InterfaceType"/> is being requested.
        /// </summary>
        public object Instance
        {
            get { return _instance; }
        }

        /// <summary>
        /// How the component was created.
        /// </summary>
        public CreateMode CreateMode
        {
            get { return _createMode; }
        }

        /// <summary>
        /// An hiearchy to where the component is created.
        /// </summary>
        /// <remarks>
        /// null if an instance was added.
        /// </remarks>
        public Stack<Type> DependencyStack
        {
            get { return _dependencyStack; }
        }
    }

    /// <summary>
    /// How the component was created.
    /// </summary>
    public enum CreateMode
    {
        /// <summary>
        /// an instance was added.
        /// </summary>
        InstanceAdded,

        /// <summary>
        /// Created normally
        /// </summary>
        Created
    }
}
