using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Components.Test
{
    class ExtensionMgr : IExtensionMgr
    {
        public ExtensionMgr(IUserMgr userMgr)
        {
            
        }
    }
}
