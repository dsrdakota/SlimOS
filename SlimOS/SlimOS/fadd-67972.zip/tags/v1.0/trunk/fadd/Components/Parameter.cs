namespace Fadd.Components
{
    /// <summary>
    /// A parameter to a component constructor.
    /// </summary>
    public class Parameter
    {
        private readonly object _value;
        private readonly string _name;

        /// <summary>
        /// Initializes a new instance of the <see cref="Parameter"/> class.
        /// </summary>
        /// <param name="name">name of constructor parameter.</param>
        /// <param name="value">parameter value.</param>
        public Parameter(string name, object value)
        {
            Check.NotEmpty(name, "name");

            _name = name;
            _value = value;
        }

        /// <summary>
        /// parameter value
        /// </summary>
        public object Value
        {
            get { return _value; }
        }

        /// <summary>
        /// name of constructor parameter.
        /// </summary>
        public string Name
        {
            get { return _name; }
        }
    }
}
