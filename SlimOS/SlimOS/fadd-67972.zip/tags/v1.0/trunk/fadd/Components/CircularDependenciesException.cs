using System;
using System.Collections.Generic;

namespace Fadd.Components
{
    /// <summary>
    /// Thrown when components are dependent of each other and therefore cannot be created.
    /// </summary>
    public class CircularDependenciesException : Exception
    {
        private readonly Stack<Type> _types;
        private readonly string _message;

        /// <summary>
        /// Initializes a new instance of the <see cref="CircularDependenciesException"/> class.
        /// </summary>
        /// <param name="types">The types.</param>
        public CircularDependenciesException(Stack<Type> types)
        {
            _types = types;
            _message = string.Empty;
            foreach (Type type in DependencyStack)
                _message += type.FullName + " -> ";
            _message = "Circular dependencies: " + _message.Substring(0, _message.Length - 4);
        }

        /// <summary>
        /// Gets a message that describes the current exception.
        /// </summary>
        /// <value></value>
        /// <returns>
        /// The error message that explains the reason for the exception, or an empty string("").
        /// </returns>
        public override string Message
        {
            get
            {
                return _message;
            }
        }

        /// <summary>
        /// Dependency stack (contains path for the circular dependencies).
        /// </summary>
        public Stack<Type> DependencyStack
        {
            get { return _types; }
        }
    }
}
