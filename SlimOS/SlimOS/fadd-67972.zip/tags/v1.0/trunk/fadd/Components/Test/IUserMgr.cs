using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Components.Test
{
    interface IUserMgr
    {
    }
}
