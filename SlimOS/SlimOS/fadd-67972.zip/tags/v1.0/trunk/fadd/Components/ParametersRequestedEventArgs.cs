using System;
using System.Collections.Generic;

namespace Fadd.Components
{
    /// <summary>
    /// Used to retreive parameters.
    /// </summary>
    public class ParametersRequestedEventArgs : EventArgs
    {
        private readonly Type _instanceType;
        private readonly Type _interfaceType;
        private readonly Dictionary<string, object> _parameters = new Dictionary<string, object>();

        /// <summary>
        /// Initializes a new instance of the <see cref="ParametersRequestedEventArgs"/> class.
        /// </summary>
        /// <param name="interfaceType">Interface used to fetch the component.</param>
        /// <param name="instanceType">Type used to create the component (the type that we need constructor parameters for).</param>
        public ParametersRequestedEventArgs(Type interfaceType, Type instanceType)
        {
            _interfaceType = interfaceType;
            _instanceType = instanceType;
        }

        /// <summary>
        /// Type used to create the component (the type that we need constructor parameters for).
        /// </summary>
        public Type InstanceType
        {
            get { return _instanceType; }
        }


        /// <summary>
        /// Interface used to fetch the component
        /// </summary>
        public Type InterfaceType
        {
            get { return _interfaceType; }
        }

        /// <summary>
        /// Constructor parameters.
        /// </summary>
        public Dictionary<string, object> Parameters
        {
            get { return _parameters; }
        }
    }
}
