using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Components.Test
{
    class Cyclic1 : ICyclic1
    {
        public Cyclic1(ICyclic2 cyclic)
        {
            
        }
    }
}
