using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Components.Test
{
    /// <summary>
    /// Tests both cascaded creation (since extensionmgr needs to create usermgr) and extra parameters.
    /// </summary>
    class Mixed : IMixed
    {
        public Mixed(IExtensionMgr mgr, string userName, int age)
        {
            
        }
    }
}
