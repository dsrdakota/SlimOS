using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Components.Test
{
    class Cyclic2 : ICyclic2
    {
        public Cyclic2(ICyclic1 cyclic)
        {

        }
    }
}
