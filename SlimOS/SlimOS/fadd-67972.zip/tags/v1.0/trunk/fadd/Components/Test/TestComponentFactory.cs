#if TEST
using System.Collections.Generic;
using Xunit;

namespace Fadd.Components.Test
{
    /// <summary>
    /// Used for testing purposes.
    /// </summary>
    public class TestComponentFactory
    {
        private readonly ComponentFactory _factory;

        /// <summary>
        /// Initializes a new instance of the <see cref="TestComponentFactory"/> class.
        /// </summary>
        public TestComponentFactory()
        {
            _factory = new ComponentFactory();
        }

        [Fact]
        private void TestSimpleComponent()
        {
            _factory.Add<IUserMgr, UserManager>();
            Assert.NotNull(_factory.Get<IUserMgr>());
        }

        [Fact]
        private void TestDependetComponent()
        {
            _factory.Add<IExtensionMgr, ExtensionMgr>();
            _factory.Add<IUserMgr, UserManager>();
            Assert.NotNull(_factory.Get<IExtensionMgr>()); // will also create the user manager.
            Assert.True(_factory.IsCreated(typeof(IUserMgr)));
            Assert.NotNull(_factory.Get<IUserMgr>());
        }

        [Fact]
        private void TestCyclicDepndencies()
        {
            _factory.Add<ICyclic1, Cyclic1>();
            _factory.Add<ICyclic2, Cyclic2>();
            Assert.Throws(typeof(CircularDependenciesException), delegate { _factory.Get<ICyclic1>(); });
            Assert.Throws(typeof(CircularDependenciesException), delegate { _factory.Get<ICyclic2>(); });
        }

        [Fact]
        private void TestCustom()
        {
            _factory.Add<CustomComponent, CustomComponent>();
            Assert.Throws(typeof(MissingConstructorException), delegate { _factory.Get<CustomComponent>(); });
        }

        [Fact]
        private void TestCustom2()
        {
            _factory.Add<CustomComponent, CustomComponent>(new Parameter("config", "test"));
            Assert.NotNull(_factory.Get<CustomComponent>());
        }

        [Fact]
        private void TestCustomInvalidParameter()
        {
            _factory.Add<CustomComponent, CustomComponent>(new Parameter("config", 1));
            Assert.Throws(typeof(MissingConstructorException), delegate { _factory.Get<CustomComponent>(); });
        }

        [Fact]
        private void TestLoadAllCyclic()
        {
            _factory.Add<ICyclic1, Cyclic1>();
            _factory.Add<ICyclic2, Cyclic2>();
            Assert.Throws(typeof (CircularDependenciesException), delegate { _factory.CreateAll(); });

            try
            {
                _factory.CreateAll();
            }
            catch (CircularDependenciesException err)
            {
                Assert.Equal(2, err.DependencyStack.Count);
            }
        }

        [Fact]
        private void TestNestedAndMixedParameters()
        {
            _factory.Add<IUserMgr, UserManager>();
            _factory.Add<IExtensionMgr, ExtensionMgr>();
            _factory.Add<IMixed, Mixed>(new Parameter("userName", "userName"), new Parameter("age", 10));
            Assert.NotNull(_factory.Get<IMixed>());
        }

        [Fact]
        private void TestAll()
        {
            _factory.Add<IUserMgr, UserManager>();
            _factory.Add<ICyclic1, Cyclic1>();
            _factory.Add<ICyclic2, Cyclic2>();
            _factory.Add<IExtensionMgr, ExtensionMgr>();
            Assert.Throws(typeof (CircularDependenciesException), delegate { _factory.Get<ICyclic1>(); });
            Assert.Throws(typeof (CircularDependenciesException), delegate { _factory.Get<ICyclic2>(); });

            Assert.NotNull(_factory.Get<IUserMgr>());
            Assert.NotNull(_factory.Get<IExtensionMgr>());

        }
    }
}
#endif