using System;
using System.Collections.Generic;

namespace Fadd.Components
{
    /// <summary>
    /// thrown when components can't be loaded.
    /// </summary>
    public class LoadFailedException : Exception
    {
        private readonly Dictionary<Type, Type> _loadedComponents;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoadFailedException"/> class.
        /// </summary>
        /// <param name="notLoadedComponents">The not loaded components.</param>
        public LoadFailedException(Dictionary<Type, Type> notLoadedComponents)
        {
            _loadedComponents = notLoadedComponents;
        }

		/// <summary>
		/// Initializes a new instance of the <see cref="LoadFailedException"/> class.
		/// </summary>
		public LoadFailedException(Type interfaceType, Type instanceType)
		{
			_loadedComponents = new Dictionary<Type, Type> {{interfaceType, instanceType}};
		}

        /// <summary>
        /// Gets a message that describes the current exception.
        /// </summary>
        /// <value></value>
        /// <returns>The error message that explains the reason for the exception, or an empty string("").</returns>
        public override string Message
        {
            get
            {
                string message = "Failed to load the following components: " + Environment.NewLine;
                foreach (KeyValuePair<Type, Type> pair in Components)
                    message += pair.Key.FullName + " (" + pair.Value.FullName + ")" + Environment.NewLine;
                return message;
            }
        }

        /// <summary>
        /// Gets the not loaded components.
        /// </summary>
        /// <value>The not loaded components.</value>
        public Dictionary<Type, Type> Components
        {
            get { return _loadedComponents; }
        }
    }
}
