namespace Fadd.Globalization
{
    /// <summary>
    /// Loads and watches language files on disk.
    /// </summary>
    /// <remarks>
    /// Future version can watch different file types, and load them using different loaders.
    /// </remarks>
    public interface ILanguageWatcher
    {
        /// <summary>
        /// Root language node.
        /// </summary>
        LanguageNode RootNode { get; }

        /// <summary>
        /// Load and watch another file on disk.
        /// </summary>
        /// <param name="filename">Relative or absolute path to language file.</param>
        /// <returns>Node that have been loaded.</returns>
        ILanguageNode Add(string filename);
    }
}