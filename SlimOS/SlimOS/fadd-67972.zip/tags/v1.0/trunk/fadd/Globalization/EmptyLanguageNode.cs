using System;

namespace Fadd.Globalization
{

    /// <summary>
    /// This node is returned instead of null.
    /// </summary>
    public class EmptyLanguageNode : LanguageNode
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EmptyLanguageNode"/> class.
        /// </summary>
        /// <param name="defaultLCID">The default LCID.</param>
        public EmptyLanguageNode(int defaultLCID)
            : base(defaultLCID)
        {
        }

        /// <summary>
        /// Add a localized text string.
        /// </summary>
        /// <param name="lcid">locale</param>
        /// <param name="name">Name identifying the string. Used to fetch the string later on.</param>
        /// <param name="text">Localized string</param>        
        public override void Add(string name, int lcid, string text)
        {
            throw new System.NotImplementedException();
        }

		/// <summary>
		/// Sets a localized text string. If the a string with the specified name exists it will be overwritten.
		/// </summary>
		/// <param name="name">Name identifying the string. Used to fetch the string later on.</param>
		/// <param name="lcid">locale</param>
		/// <param name="text">Localized string</param>
		public override void Set(string name, int lcid, string text)
		{
			throw new System.Exception("The method or operation is not implemented.");
		}

        /// <summary>
        /// Adds a sub category
        /// </summary>
        /// <param name="name">Name of the sub category</param>
        /// <exception cref="ArgumentException">If a category with the specified name already exists</exception>
        /// <exception cref="ArgumentNullException">If name is null</exception>
        public override LanguageNode AddChild(string name)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Get a localized text string in the current language.
        /// </summary>
        /// <param name="textName">Phrase to find.</param>
        /// <returns>text if found; [textName] if not.</returns>
        /// <example>
        /// <code>
        /// lang["Name"] // => "Name"
        /// lang["Naem"] // => "[Naem]" since it's missing
        /// </code>
        /// </example>
        public override string this[string textName]
        {
            get { return EmptyValue(textName); }
        }

        /// <summary>
        /// Get a localized text string
        /// </summary>
        /// <param name="lcid"></param>
        /// <param name="textName">Phrase to find.</param>
        /// <returns>text if found; [textName] if not.</returns>
        /// <example>
        /// <code>
        /// lang["Name"] // => "Name"
        /// lang["Naem"] // => "[Naem]" since it's missing
        /// </code>
        /// </example>
        public override string this[string textName, int lcid]
        {
            get { return EmptyValue(textName); }
        }

        /// <summary>
        /// Get a text string in the specified language.
        /// </summary>
        /// <param name="lcid">Language to fetch from.</param>
        /// <param name="textName">name of text to find.</param>
        /// <returns>string if found; otherwise null.</returns>
        public override string GetText(int lcid, string textName)
        {
            return null;
        }

        /// <summary>
        /// Get a text string in the specified language.
        /// </summary>
        /// <param name="lcid">Language to fetch from.</param>
        /// <param name="textName">name of text to find.</param>
        /// <param name="checkPaths">check for paths in <paramref name="textName"/>.</param>
        /// <returns>string if found; otherwise null.</returns>
        public override string GetText(int lcid, string textName, bool checkPaths)
        {
            return null;
        }

        /// <summary>
        /// Number languages
        /// </summary>
        public override int Count
        {
            get { return 0; }
        }

        /// <summary>
        /// Number of translated texts in the specified language
        /// </summary>
        /// <param name="lcid"></param>
        /// <returns></returns>
        public override int GetTextCount(int lcid)
        {
            return 0;
        }

        /// <summary>
        /// Determine if the node contains a text item with the specified name for the specified language
        /// </summary>
        /// <param name="name"></param>
        /// <param name="lcid"></param>
        /// <returns>
        /// True if the node contains a language element with the specified name for the specified language
        /// </returns>
        public override bool Contains(string name, int lcid)
        {
            return false;
        }

        /// <summary>
        /// Determine if a category contains a specific language.
        /// </summary>
        /// <param name="lcid"></param>
        /// <returns></returns>
        public override bool ContainsLanguage(int lcid)
        {
            return false;
        }


        /// <summary>Empties all saved values in the node and its sub nodes</summary>
        public override void ClearHierarchy()
        {
            throw new System.NotImplementedException();
        }
    }
}
