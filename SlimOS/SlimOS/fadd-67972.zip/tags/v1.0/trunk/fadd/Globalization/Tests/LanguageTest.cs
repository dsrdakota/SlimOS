#if TEST
using System.Globalization;
using System.Threading;
using Xunit;
#pragma warning disable 1591

namespace Fadd.Globalization.Tests
{
    public class LanguageTest
    {
        private readonly LanguageNode _languageNode;

        public LanguageTest()
        {
            _languageNode = new MemLanguageNode(CultureInfo.CurrentCulture.LCID, "root");
        }

        [Fact]
        public void TestNoCategory()
        {
            Assert.Null(_languageNode.GetChild("Invalid"));
        }

        [Fact]
        public void TestEmpty()
        {
            Assert.NotNull(_languageNode);
            Assert.Equal("[name]", _languageNode["name"]);
            Assert.Equal("[name]", _languageNode["name", int.MaxValue]);
            Assert.Equal("[name]", _languageNode["name", _languageNode.DefaultLCID]);
        }

        [Fact]
        public void TestNode()
        {
            _languageNode.Add("voodoo", _languageNode.DefaultLCID, "voodooBase");
            ILanguageNode language = _languageNode.AddChild("testNode");
            Assert.Equal("voodooBase", language["voodoo"]);

            ((LanguageNode)language).Add("voodoo", _languageNode.DefaultLCID, "voodooSub");
            Assert.Equal("voodooSub", language["voodoo"]);

            Assert.Equal("[voodoMisspelled]", language["voodoMisspelled"]);
        }

        [Fact]
        public void TestLanguages()
        {
            ILanguageNode language = _languageNode.AddChild("subNode");
            ((LanguageNode)language).Add("language", _languageNode.DefaultLCID, "swedish");
            ((LanguageNode)language).Add("language", 1052, "�nglish");
            ((LanguageNode)language).Add("language", 1051, "tyskish");

            Assert.Equal("swedish", language["language", _languageNode.DefaultLCID]);
            Assert.Equal("�nglish", language["language", 1052]);
            Assert.Equal("tyskish", language["language", 1051]);
            Assert.Equal("[language]", language["language", int.MaxValue]);

            language = ((LanguageNode)language).AddChild("subSubNode");
            Assert.Equal("swedish", language["language"]);
        }

        [Fact]
        public void TestNull()
        {
            Assert.Null(_languageNode.GetChild("Undefined"));
        }

        [Fact]
        public void TestNodes()
        {
            LanguageNode child = _languageNode.AddChild("Presence");
            child.Add("test", Thread.CurrentThread.CurrentCulture.LCID, "hello");

            Assert.Null(_languageNode.GetChild("/Presence/SubCategory"));
            Assert.Null(_languageNode.GetChild("/LineLimiter/FunctionInfo"));
        }
    }
}
#endif