using System;
using System.Collections.Generic;
using System.Collections.Specialized;
#if TEST
using System.Globalization;
using System.Threading;
using Xunit;
#endif

namespace Fadd.Globalization
{
    /// <summary>
    /// Contains translation texts that have been loaded into memory
    /// </summary>
    public class MemLanguageNode : LanguageNode
    {
        /// <summary>
        /// int is LCID, NameValueCollection contains all phrases.
        /// </summary>
        private readonly Dictionary<int, NameValueCollection> _languages = new Dictionary<int, NameValueCollection>();

        /// <summary>Instantiates a LanguageNode that holds the language data in memory</summary>
        /// <param name="defaultLCID">The defualt language code</param>
        /// <param name="name">The name of the node</param>
        public MemLanguageNode(int defaultLCID, string name) : base(defaultLCID)
        {
            Name = name;
        }

        /// <summary>Returns the requested entry using the systems current language</summary>
        /// <param name="textName">Name of the entry to retrieve</param>
        /// <returns>The entry or if not found in the current language, default language or in parent nodes returns [textName]</returns>
        public override string this[string textName]
        {
            get
            {
                int lcId = CurrentCulture.LCID;
                return GetText(lcId, textName, true) ?? GetText(DefaultLCID, textName, true) ?? EmptyValue(textName);
            }
        }
		
        /// <summary>
        /// A requested text entry in the requested language
        /// </summary>
        /// <param name="textName">Name of the entry to retrieve</param>
        /// <param name="lcid">Language code for the language to retrieve the text in</param>
        /// <returns>The entry or if not found in the current language, default language or in parent nodes returns [textName]</returns>
        public override string this[string textName, int lcid]
        {
            get 
            {
                return GetText(lcid, textName, true) ?? EmptyValue(textName);
            }
        }

        /// <summary>
        /// Get a text string in the specified language.
        /// </summary>
        /// <param name="lcid">Language to fetch from.</param>
        /// <param name="textName">name of text to find.</param>
        /// <returns>string if found; otherwise null.</returns>
        public override string GetText(int lcid, string textName)
        {
            return GetText(lcid, textName, true);
        }

        /// <summary>
        /// Get a text string in the specified language.
        /// </summary>
        /// <param name="lcid">Language to fetch from.</param>
        /// <param name="textName">name of text to find.</param>
        /// <param name="checkPaths">check for paths in <paramref name="textName"/>.</param>
        /// <returns>string if found; otherwise null.</returns>
        public override string GetText(int lcid, string textName, bool checkPaths)
        {
            // we've stumbled upon a path.
            if (checkPaths && textName.Contains("/"))
            {
                string text = CheckPaths(lcid, textName);
                if (text != null)
                    return text;
            }

            string textValue;
            // find prompt in current language and node
            NameValueCollection language = GetLanguage(lcid);
            lock (language)
            {
                textValue = language[textName];
                if (textValue != null)
                    return textValue;
            }
            // find prompt in parent (in the current language)
            if (ParentNode != null)
            {
                textValue = ParentNode.GetText(lcid, textName);
                if (textValue != null)
                    return textValue;
            }

            return null;
        }

        /// <summary>
        /// Returns the number of languages in the node
        /// </summary>
        /// <remarks>Returns the number of languages and Not text entries</remarks>
        public override int Count
        {
            get { return _languages.Count; }
        }

        /// <summary>
        /// Adds a text entry to the language node
        /// </summary>
        /// <param name="name">Name of the entry</param>
        /// <param name="lcid">Language of the entry</param>
        /// <param name="text">The text of the entry</param>
        public override void Add(string name, int lcid, string text)
        {
            NameValueCollection language = GetLanguage(lcid);
            lock (language)
            {
				if (language[name] != null)
					throw new InvalidOperationException("Value '" + name + "' already added.");

                language.Add(name, text);
            }
        }

		/// <summary>
		/// Sets a localized text string. If the a string with the specified name exists it will be overwritten.
		/// </summary>
		/// <param name="name">Name identifying the string. Used to fetch the string later on.</param>
		/// <param name="lcid">locale</param>
		/// <param name="text">Localized string</param>
		public override void Set(string name, int lcid, string text)
		{
            GetLanguage(lcid).Set(name, text);
		}

        private NameValueCollection GetLanguage(int lcid)
        {
            NameValueCollection collection;
            if (!_languages.TryGetValue(lcid, out collection))
            {
                collection = new NameValueCollection();
                lock (_languages)
                {
                    if (!_languages.ContainsKey(lcid))
                        _languages.Add(lcid, collection);
                }
            }
            return collection;
        }
        /// <summary>
        /// Adds a sub category
        /// </summary>
        /// <param name="name">Name of the sub category</param>
        /// <exception cref="ArgumentException">If a category with the specified name already exists</exception>
        /// <exception cref="ArgumentNullException">If name is null</exception>
        public override LanguageNode AddChild(string name)
        {
            if (ContainsChild(name))
                throw new ArgumentException("A node with specified name already exists.", "name");
            if(string.IsNullOrEmpty(name))
                throw new ArgumentNullException("name");

            MemLanguageNode node = new MemLanguageNode(DefaultLCID, name);
            node.ParentNode = this;
            Children.Add(name, node);
            return node;
        }

        /// <summary>
        /// Returns number of text entries in the requested language
        /// </summary>
        /// <param name="lcid">The language to examine</param>
        public override int GetTextCount(int lcid)
        {
            lock (_languages)
            {
                return _languages.ContainsKey(lcid) ? _languages[lcid].Count : 0;
            }
        }

        /// <summary>
        /// Determine if the node contains a text item with the specified name for the specified language
        /// </summary>
        /// <param name="name"></param>
        /// <param name="lcid"></param>
        /// <returns>
        /// True if the node contains a language element with the specified name for the specified language
        /// </returns>
        public override bool Contains(string name, int lcid)
        {
            if(!_languages.ContainsKey(lcid))
                return false;

            return _languages[lcid][name] != null;
        }

        /// <summary>
        /// Determine if a category contains a specific language.
        /// </summary>
        /// <param name="lcid"></param>
        /// <returns></returns>
        public override bool ContainsLanguage(int lcid)
        {
            lock (_languages)
                return _languages.ContainsKey(lcid);
        }

        /// <summary>Empties all saved values in the node and its subnodes</summary>
        public override void ClearHierarchy()
        {
            _languages.Clear();
            foreach (KeyValuePair<string, ILanguageNode> child in Children)
                child.Value.ClearHierarchy();
        }

#if TEST
		 private static MemLanguageNode BuildTestData()
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo(1033);
            MemLanguageNode node = new MemLanguageNode(1033, "root");
            node.Add("hello", 1033, "Hello World");
            node.Add("hello", 1053, "Tjena v�rlden!");
            node.Add("override", 1033, "No way!");

            MemLanguageNode users = (MemLanguageNode)node.AddChild("users");
            users.Add("override", 1033, "overridden!");
            users.Add("FirstName", 1033, "Jonas");

            MemLanguageNode form = (MemLanguageNode)users.AddChild("form");
            form.Add("Text", 1033, "Some text");
            return form;
        }

        [Fact]
        private static void TestCategories()
        {
            MemLanguageNode form = BuildTestData();
            Assert.Equal("overridden!", form["override"]);
            Assert.Equal("Some text", form["Text"]);
            Assert.Equal("Some text", form["text"]);

            Assert.Equal("No way!", form["/override"]);
            Assert.Equal("overridden!", form["../override"]);
            Assert.Equal("Some text", form["../form/Text"]);
            Assert.Equal("Some text", form["/users/form/Text"]);
            Assert.Equal("Hello World", form["/users/hello"]);
            
        }

        [Fact]
        private static void TestNodes()
        {
            MemLanguageNode form = BuildTestData();
            MemLanguageNode users = (MemLanguageNode)form.ParentNode;

            Assert.Equal<ILanguageNode>(users, form.GetChild("../../users"));
            Assert.Equal<ILanguageNode>(users, form.GetChild(".."));
            Assert.Equal<ILanguageNode>(users, form.GetChild("/users"));
            Assert.Equal<ILanguageNode>(form, form.GetChild("/users/form"));
            Assert.Equal<ILanguageNode>(form, users.GetChild("form"));
            
        }
#endif
	}
}