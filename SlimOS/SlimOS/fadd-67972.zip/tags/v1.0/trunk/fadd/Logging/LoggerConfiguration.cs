using System.IO;
using System.Xml;

namespace Fadd.Logging
{
    /// <summary>
    /// Default implementation of <see cref="ILoggerConfiguration"/>.
    /// </summary>
    public class LoggerConfiguration : ILoggerConfiguration
    {
        private string _name;

        private LogLevel _minLevel;

        private LogLevel _maxLevel;

        private int _stackFrameCount = 3;

        private int _stackFrameStart = 4;

        private ILogFormatter _formatter;

        /// <summary>
        /// Name of this logging configuration.
        /// </summary>
        /// <remarks>
        /// Used in the configuration files (section loggers) to map a logger to a log.
        /// </remarks>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        /// <summary>
        /// The lowest level that can be written to all logs that have this <see cref="ILogger"/> attached.
        /// </summary>
        public LogLevel MinLevel
        {
            get { return _minLevel; }
            set { _minLevel = value; }
        }

        /// <summary>
        /// The max level that can be written to all logs that has this l<see cref="ILogger"/>ogger attached.
        /// </summary>
        public LogLevel MaxLevel
        {
            get { return _maxLevel; }
            set { _maxLevel = value; }
        }

        /// <summary>
        /// Number of stack frames to include in the logging
        /// </summary>
        public int StackFrameCount
        {
            get { return _stackFrameCount; }
            set { _stackFrameCount = value; }
        }

        /// <summary>
        /// Which stack frame to start with.
        /// </summary>
        /// <remarks>To skip all logging frames, specify 5 as start.</remarks>
        public int StackFrameStart
        {
            get { return _stackFrameStart; }
            set { _stackFrameStart = value; }
        }

        /// <summary>
        /// Formatter used to transform logging information into text (or binary formats).
        /// </summary>
        public ILogFormatter Formatter
        {
            get { return _formatter; }
            set { _formatter = value; }
        }

		/// <summary>
		/// Load a configuration from an xml stream
		/// </summary>
		/// <param name="stream">Xml stream to read from</param>
    	public void Deserialize(Stream stream)
    	{
    		throw new System.NotImplementedException();
    	}

		/// <summary>
		/// Write configuration into a XML stream.
		/// </summary>
		/// <param name="stream">Xml stream to write to</param>
    	public void Serialize(Stream stream)
    	{
    		throw new System.NotImplementedException();
    	}
    }
}
