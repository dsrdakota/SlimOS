using System;

namespace Fadd.Logging
{
    /// <summary>
    /// A logger is used to write log entries to a specific source, it can for instance be to the console
    /// (<see cref="ConsoleLogger"/>) or to a text file (<see cref="TextFileLogger"/>).
    /// </summary>
    public interface ILogger
    {
        /// <summary>
        /// Gets the configuration used for the logger
        /// </summary>
        /// <remarks>
        /// Can be null in case the logger lacks a configuration.
        /// </remarks>
        ILoggerConfiguration LoggerConfiguration {get;}

        /// <summary>
        /// Very detailed log messages, potentially of a high frequency and volume
        /// </summary>
        /// <param name="message">message written to the log.</param>
        void Trace(string message);

        /// <summary>
        /// Very detailed log messages, potentially of a high frequency and volume
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        void Trace(string message, Exception exception);

        /// <summary>
        /// Less detailed and/or less frequent debugging messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        void Debug(string message);

        /// <summary>
        /// Less detailed and/or less frequent debugging messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        void Debug(string message, Exception exception);

        /// <summary>
        /// Informational messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        void Info(string message);

        /// <summary>
        /// Informational messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        void Info(string message, Exception exception);

        /// <summary>
        /// Warnings which don't appear to the user of the application
        /// </summary>
        /// <param name="message">message written to the log.</param>
        void Warning(string message);

        /// <summary>
        /// Warnings which don't appear to the user of the application
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        void Warning(string message, Exception exception);

        /// <summary>
        /// Error messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        void Error(string message);

        /// <summary>
        /// Error messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        void Error(string message, Exception exception);

        /// <summary>
        /// Fatal error messages. After a fatal error, the application usually terminates. 
        /// </summary>
        /// <param name="message">message written to the log.</param>
        void Fatal(string message);

        /// <summary>
        /// Fatal error messages. After a fatal error, the application usually terminates. 
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        void Fatal(string message, Exception exception);
    }
}
