using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Logging
{
    /// <summary>
    /// Used to format log entries.
    /// </summary>
    public interface ILogFormatter
    {
        /// <summary>
        /// Format a long message
        /// </summary>
        /// <param name="logLevel">Importance of the current message.</param>
        /// <param name="message">Message being written</param>
        /// <param name="exception">Exception, or null</param>
        /// <param name="methodNames">Method names from the call stack.</param>
        /// <returns>Formatted log entry.</returns>
        string Format(LogLevel logLevel, string message, Exception exception, string[] methodNames);
        
    }
}
