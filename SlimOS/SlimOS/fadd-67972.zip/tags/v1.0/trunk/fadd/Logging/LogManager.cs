namespace Fadd.Logging
{
	#region NullLogProvider

	/// <summary>
	/// Temporary class (before transaction where <see cref="ILogProvider"/>'s will be removed) to disable logging totally
	/// </summary>
	public class NullLogProvider : ILogProvider
	{
		private readonly static NullLogger _nullLogger = new NullLogger();

		/// <summary>Returns a <see cref="NullLogger"/></summary>
		public ILogger GetLogger(string name)
		{
			return _nullLogger;
		}

		/// <summary>Returns a <see cref="NullLogger"/></summary>
		public ILogger GetCurrentClassLogger()
		{
			return _nullLogger;
		}
	}

	#endregion

	/// <summary>
    /// Manager that provides logs to the classes.
    /// </summary>
    public static class LogManager
    {
        private static ILogProvider _provider;

        /// <summary>
        /// Logger that is logging to nothing.
        /// </summary>
        public static readonly NullLogger NullLogger = new NullLogger();

        /// <summary>
        /// Gets the logger.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns>A <see cref="ILogger"/>.</returns>
        public static ILogger GetLogger(string name)
        {
        	return _provider == null ? NullLogger : _provider.GetLogger(name);
        }

		/// <summary>
        /// Get logger for the current class.
        /// </summary>
        /// <returns>A <see cref="ILogger"/>.</returns>
        public static ILogger GetCurrentClassLogger()
		{
			return _provider == null ? NullLogger : _provider.GetCurrentClassLogger();
		}

		/// <summary>
        /// Set the provider used to get loggers.
        /// </summary>
        /// <param name="provider"></param>
        public static void SetProvider(ILogProvider provider)
        {
            _provider = provider;
        }
    }
}
