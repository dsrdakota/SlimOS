namespace Fadd.Logging
{
    /// <summary>
    /// Provides different logger implementations.
    /// </summary>
    public interface ILogProvider
    {
        /// <summary>
        /// Get a logger with the specified name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        ILogger GetLogger(string name);

        /// <summary>
        /// Get logger for current class.
        /// </summary>
        /// <returns></returns>
        ILogger GetCurrentClassLogger();
    }
}
