﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Logging
{
	public class NamespaceMapping
	{
		private string _namespace;
	}
}
