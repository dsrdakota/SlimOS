using System;
using System.Diagnostics;
using System.Reflection;
using Xunit;

namespace Fadd.Logging
{
    /// <summary>
    /// Contains all configuration settings for the logs and provide the
    /// requested loggers to the <see cref="LogManager"/> when a log is requested.
    /// </summary>
    public class LogProvider : ILogProvider
    {
        
        /// <summary>
        /// Get a logger with the specified name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public ILogger GetLogger(string name)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Get logger for current class.
        /// </summary>
        /// <returns></returns>
        public ILogger GetCurrentClassLogger()
        {
			StackTrace trace = new StackTrace();
			StackFrame[] allFrames = trace.GetFrames();
			if (allFrames == null || allFrames.Length == 0)
				return null;

        	Type classType = allFrames[1].GetMethod().ReflectedType;


        	return null;
        }

		[Fact]
		private void TestGetCurrentClassLogger()
		{
			LogProvider provider = new LogProvider();
			ILogger logger = provider.GetCurrentClassLogger();
		}
    }
}
