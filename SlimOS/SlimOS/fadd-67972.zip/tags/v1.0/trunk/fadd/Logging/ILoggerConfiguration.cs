using System.IO;

namespace Fadd.Logging
{
    /// <summary>
    /// This class contains the general configuration for <see cref="ILogger"/>, while each logger has it's
    /// own specific configuration on top of this interface.
    /// </summary>
    public interface ILoggerConfiguration
    {
        /// <summary>
        /// Name of this logging configuration.
        /// </summary>
        /// <remarks>
        /// Used in the configuration files (section loggers) to map a logger to a log.
        /// </remarks>
        string Name{ get; set;}

        /// <summary>
        /// The lowest level that can be written to all logs that have this <see cref="ILogger"/> attached.
        /// </summary>
        LogLevel MinLevel { get; set;}

        /// <summary>
        /// The max level that can be written to all logs that has this l<see cref="ILogger"/>ogger attached.
        /// </summary>
        LogLevel MaxLevel { get; set;}

        /// <summary>
        /// Number of stack frames to include in the logging
        /// </summary>
        int StackFrameCount { get; set; }

        /// <summary>
        /// Which stack frame to start with.
        /// </summary>
        /// <remarks>To skip all logging frames, specify 5 as start.</remarks>
        int StackFrameStart { get; set; }

        /// <summary>
        /// Formatter used to transform logging information into text (or binary formats).
        /// </summary>
        ILogFormatter Formatter {
            get;
            set;}

        /// <summary>
        /// Load a configuration from an XML stream
        /// </summary>
        /// <param name="stream">XML stream to read from</param>
        void Deserialize(Stream stream);

        /// <summary>
        /// Write configuration into a XML stream.
        /// </summary>
		/// <param name="stream">XML stream to write to</param>
		void Serialize(Stream stream);
    }

    /// <summary>
    /// Log levels
    /// </summary>
    public enum LogLevel
    {
		/// <summary>
		/// Very detailed logs useful when trying to find bugs.
		/// </summary>
        Trace,

		/// <summary>
		/// Information such as state changes etc.
		/// </summary>
        Info,

		/// <summary>
		/// Information useful during debugging
		/// </summary>
        Debug,

		/// <summary>
		/// Something did go as expected, but it's nothing serious and
		/// executing can continue without any problems.
		/// </summary>
        Warning,

		/// <summary>
		/// Something went wrong, but we can handle it, alhtough the execution
		/// cannot continue as expected.
		/// </summary>
        Error,

		/// <summary>
		/// Something went wrong and we can't really handle it.
		/// </summary>
        Fatal
    }
}
