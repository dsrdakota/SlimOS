using System;

namespace Fadd.Logging
{
    /// <summary>
    /// How logs should be displayed in the console.
    /// </summary>
    public class ConsoleConfiguration : LoggerConfiguration
    {
        private ConsoleColor _debugColor = ConsoleColor.Gray;
        private ConsoleColor _errorColor = ConsoleColor.Magenta;
        private ConsoleColor _fatalColor = ConsoleColor.Red;
        private ConsoleColor _infoColor = ConsoleColor.Green;
        private ConsoleColor _traceColor = ConsoleColor.DarkGray;
        private ConsoleColor _warningColor = ConsoleColor.Yellow;

        /// <summary>
        /// Color on trace messages.
        /// </summary>
        public ConsoleColor TraceColor
        {
            get { return _traceColor; }
            set { _traceColor = value; }
        }

        /// <summary>
        /// Debug color
        /// </summary>
        public ConsoleColor DebugColor
        {
            get { return _debugColor; }
            set { _debugColor = value; }
        }

        /// <summary>
        /// Fatal color
        /// </summary>
        public ConsoleColor FatalColor
        {
            get { return _fatalColor; }
            set { _fatalColor = value; }
        }

        /// <summary>
        /// Color on errors
        /// </summary>
        public ConsoleColor ErrorColor
        {
            get { return _errorColor; }
            set { _errorColor = value; }
        }

        /// <summary>
        /// Color on warnings
        /// </summary>
        public ConsoleColor WarningColor
        {
            get { return _warningColor; }
            set { _warningColor = value; }
        }

        /// <summary>
        /// Color on info messages
        /// </summary>
        public ConsoleColor InfoColor
        {
            get { return _infoColor; }
            set { _infoColor = value; }
        }

    }
}
