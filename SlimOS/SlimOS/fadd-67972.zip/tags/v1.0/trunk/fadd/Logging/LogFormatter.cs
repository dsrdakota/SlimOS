using System;
using System.Threading;

namespace Fadd.Logging
{
    /// <summary>
    /// Used to format log output.
    /// </summary>
    public class LogFormatter
    {
        /// <summary>
        /// Format a long message
        /// </summary>
        /// <param name="logLevel">Importance of the current message.</param>
        /// <param name="message">Message being written</param>
        /// <param name="exception">Exception, or null</param>
        /// <param name="methodNames">Method names from the call stack.</param>
        /// <returns>Formatted log entry.</returns>
        public string Format(LogLevel logLevel, string message, Exception exception, string[] methodNames)
        {
        	string msg =
        		DateTime.Now.ToString("hh:mm:ss") +
                " | " + logLevel.ToString().PadRight(7, ' ') +
        		" | " + Thread.CurrentThread.ManagedThreadId.ToString("0000") +
        		" | " + string.Join(">", methodNames) +
        		" | " + message.Replace("\r\n", "\r\n\t");
			if (exception != null)
				msg += "\r\n\t" + exception.ToString().Replace("\r\n", "\r\n\t");

        	return msg;
        }

		/// <summary>
		/// Format a long message
		/// </summary>
		/// <param name="message">Message being written</param>
		/// <param name="exception">Exception, or null</param>
		/// <param name="methodNames">Method names from the call stack.</param>
		/// <returns>Formatted log entry.</returns>
		public string Format(string message, Exception exception, string[] methodNames)
		{
			string msg =
				DateTime.Now.ToString("hh:mm:ss") +
				" | " + Thread.CurrentThread.ManagedThreadId.ToString("0000") +
				" | " + string.Join(">", methodNames) +
				" | " + message.Replace("\r\n", "\r\n\t");
			if (exception != null)
				msg += "\r\n\t" + exception.ToString().Replace("\r\n", "\r\n\t");

			return msg;
		}
    }
}
