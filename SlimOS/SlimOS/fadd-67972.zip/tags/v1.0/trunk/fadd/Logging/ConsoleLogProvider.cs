namespace Fadd.Logging
{
    /// <summary>
    /// Temporary class to get logging during development.
    /// </summary>
    public class ConsoleLogProvider : ILogProvider
    {
        private readonly ConsoleLogger _logger = new ConsoleLogger(new LogFormatter(), new LoggerConfiguration());

        /// <summary>
        /// Get a logger with the specified name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public ILogger GetLogger(string name)
        {
            return _logger;
        }

        /// <summary>
        /// Get logger for current class.
        /// </summary>
        /// <returns></returns>
        public ILogger GetCurrentClassLogger()
        {
            return _logger;
        }
    }
}
