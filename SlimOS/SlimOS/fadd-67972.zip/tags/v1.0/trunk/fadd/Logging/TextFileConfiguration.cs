﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Logging
{
	class TextFileConfiguration : LoggerConfiguration
	{
	}
}
