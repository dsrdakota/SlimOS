using System;
using System.Collections.Generic;
using System.Text;

namespace Fadd.Logging
{
    /// <summary>
    /// Logger that doesnt log at all.
    /// (Used in classes that got log member var but no logger. 
    /// the option would have been a lot of if statements).
    /// </summary>
    public class NullLogger : ILogger
    {
        /// <summary>
        /// Gets the configuration used for the logger
        /// </summary>
        /// <value></value>
        public ILoggerConfiguration LoggerConfiguration
        {
            get { return null; }
        }

        /// <summary>
        /// Very detailed log messages, potentially of a high frequency and volume
        /// </summary>
        /// <param name="message">message written to the log.</param>
        public void Trace(string message)
        {
        }

        /// <summary>
        /// Very detailed log messages, potentially of a high frequency and volume
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        public void Trace(string message, Exception exception)
        {
        }

        /// <summary>
        /// Less detailed and/or less frequent debugging messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        public void Debug(string message)
        {
        }

        /// <summary>
        /// Less detailed and/or less frequent debugging messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        public void Debug(string message, Exception exception)
        {
        }

        /// <summary>
        /// Informational messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        public void Info(string message)
        {
        }

        /// <summary>
        /// Informational messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        public void Info(string message, Exception exception)
        {
        }

        /// <summary>
        /// Warnings which don't appear to the user of the application
        /// </summary>
        /// <param name="message">message written to the log.</param>
        public void Warning(string message)
        {
        }

        /// <summary>
        /// Warnings which don't appear to the user of the application
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        public void Warning(string message, Exception exception)
        {
        }

        /// <summary>
        /// Error messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        public void Error(string message)
        {
        }

        /// <summary>
        /// Error messages
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        public void Error(string message, Exception exception)
        {
        }

        /// <summary>
        /// Fatal error messages. After a fatal error, the application usually terminates. 
        /// </summary>
        /// <param name="message">message written to the log.</param>
        public void Fatal(string message)
        {
        }

        /// <summary>
        /// Fatal error messages. After a fatal error, the application usually terminates. 
        /// </summary>
        /// <param name="message">message written to the log.</param>
        /// <param name="exception">an exception.</param>
        public void Fatal(string message, Exception exception)
        {
        }
    }
}
