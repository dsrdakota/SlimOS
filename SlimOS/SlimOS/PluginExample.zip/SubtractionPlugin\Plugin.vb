﻿Imports System.Windows.Forms
Imports PluginAPI

Public Class Plugin
    Implements Iplugin


    ReadOnly Public Property Name() As String Implements IPlugin.Name
        Get
            Return "Subtraction"
        End Get
    End Property

    ReadOnly Public Property ActionName() As String Implements IPlugin.ActionName
        Get
            Return "Subtract Values"
        End Get
    End Property

    Public Sub Calculate (ByVal value1 As Integer, ByVal value2 As Integer) Implements IPlugin.Calculate
        Dim result As Integer = value1 - value2
        messagebox.show ("The result is " + result.ToString)
    End Sub
End Class
